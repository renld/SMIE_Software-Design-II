int KMP(char* S, char* T, int pos){
	int k=pos, j=1;
	while (k){
		if (S[k] == T[j]){
			k++; 
			j++; 
		}
		else j = next[j]
	}
	if (j>T[0]) return k-T[0];
	else return 0;
}