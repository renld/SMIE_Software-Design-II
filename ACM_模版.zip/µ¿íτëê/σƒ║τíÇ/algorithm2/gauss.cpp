#include<iostream>
#include<cmath>
using namespace std;

int main(){
	float a[10][10],b[10],d=0,t=0,sum=0;
	int k=1,l=0,i=0,j=0,m,n;
	cout<<"���뷽����������"<<endl;
	cin>>n;
	cout<<"���뷽����δ֪����"<<endl;
	cin>>m;
	cout<<"���뷽�������ϵ����"<<endl;
	
	for(int ii=1;ii<=n;ii++){
		cout<<"�� "<<ii<<" ������"<<endl;
		for(int jj=1;jj<=m;jj++)cin>>a[ii][jj];
			cin>>b[ii];
	}
	
	while(k<=n){
		d=a[k][k];
		l=k;
		for(i=k+1;i<=n;i++){
			if(fabs(a[i][k])>fabs(d)){
				d=a[i][k];
				l=i;
			}
		}
		   
		if(l!=k){
			for(j=k;j<=n;j++){
				t=a[l][j];a[l][j]=a[k][j];a[k][j]=t;
			}
			t=b[k];b[k]=b[l];b[l]=t;
		}
		for(j=k+1;j<=n;j++){
			a[k][j]=a[k][j]/a[k][k];
		}
		b[k]=b[k]/a[k][k];
		for(i=k+1;i<=n;i++){
			for(j=k+1;j<=n;j++){
				a[i][j]=a[i][j]-a[i][k]*a[k][j];
			}
			j=1;
			b[i]=b[i]-a[i][k]*b[k];
		}
		k++;
	}
	for(i=n-1;i>=1;i--){
		sum=0;
		for(j=i+1;j<=n;j++){
			sum=sum+a[i][j]*b[j];
		}
		b[i]=b[i]-sum;
	}
	cout<<endl<<endl<<"�����:"<<endl;
	for(int loop=1;loop<=n;loop++){
		cout<<"x"<<loop<<"="<<b[loop]<<endl;
	}
	return 0;
}

