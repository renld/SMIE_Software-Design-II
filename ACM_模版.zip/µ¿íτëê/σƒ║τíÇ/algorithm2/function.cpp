#include <iostream>
#include <cstring>
#include <list>
#include <climits>
#include <cstdio>
#include <cstdlib>

using namespace std;

class node{
public:
	int c;
	int v;
	node(){
		c=0;
		v=0;
	}
	node(int a,int b){
		c=a;
		v=b;
	}
	friend node& operator+(node &a,node &b){
		static node temp;
		temp.c=a.c+b.c;
		temp.v=a.v+b.v;
		return temp;
	}
	friend node& operator-(node &a,node &b){
		static node temp;
		temp.c=a.c-b.c;
		temp.v=a.v-b.v;
		return temp;
	}
	friend node& operator*(node &a,node &b){
		static node temp;
		temp.c=a.c*b.c;
		temp.v=a.c*b.v+a.v*b.c;
		return temp;
	}
	friend node& operator/(node &a,node &b){
		static node temp;
		return temp;
	}
};

node ERROR;

class Cal{
public:
	node getAns(char str[]){
		
		int relation[7][7]={
		//	 + - * / ( ) #
			{3,3,2,2,2,3,3},//+
			{3,3,2,2,2,3,3},//-
			{3,3,3,3,2,3,3},//*
			{3,3,3,3,2,3,3},///
			{2,2,2,2,2,1,0},//(
			{3,3,3,3,0,3,3},//)
			{2,2,2,2,2,0,1} //#
		};// 3:> 2:< 1:=
		int len=strlen(str);
		str[len++]='#';
		list<node>  OPND;
		list<char> OPTR;
		OPTR.push_front('#');
		int i=0;
		while(str[i]!='#'||OPTR.front()!='#'){
			if(type(str[i])==2){
				node NUM;
				sscanf(str+i,"%d",&NUM.c);
				while(type(str[i])==2) i++;
				OPND.push_front(NUM);
			}
			else if(type(str[i])==3){
				node var;
				var.v=1;
				OPND.push_front(var);
				i++;
			}
			else if(type(str[i])==1){
				switch(relation[turnInt(OPTR.front())][turnInt(str[i])]){
					case 0:
						return ERROR;
					case 2://<
						OPTR.push_front(str[i]);
						i++;
						break;
					case 1://=
						OPTR.pop_front();
						i++;
						break;
					case 3://>
						char theta=OPTR.front();	OPTR.pop_front();
						node b=OPND.front();		OPND.pop_front();
						node a=OPND.front();		OPND.pop_front();
						OPND.push_front(Operate(a,theta,b));
						break;
				}
			}
			else i++;
		}
		return OPND.front();
	}
	
	node Operate(node A,char theta,node B){
		switch(theta){
			case  '+':return A+B;
			case  '-':return A-B;
			case  '*':return A*B;
			case  '/':return A/B;
		}
		return ERROR;
	}
	
	int turnInt(char c){
		switch (c){
			case '+':	return 0;
			case '-':	return 1;
			case '*':	return 2;
			case '/':	return 3;
			case '(':	return 4;
			case ')':	return 5;
			case '#':	return 6;
		}
	}
	 
	int type(char s){
		if(s>='0'&&s<='9') return 2;
		else if(s=='+'||s=='-'||s=='*'||s=='/'||s=='('||s==')'||s=='#')	return 1;
		else if(s=='x') return 3;
		else return 0;
	}
};

int main(){
	Cal cal;
	char str[200];
	char c1[200];
	char c2[200];
	int r=1;
	while(cin.getline(str,200)){
		int len=strlen(str);
		int i,j;
		for(i=0;i<len;i++){
			c1[i]=str[i];
			if(str[i]=='='){
				c1[i]='\0';
				break;
			}
		}
		for(j=i+1;j<=len;j++){
			c2[j-i-1]=str[j];
		}
		node ans1=cal.getAns(c1);
		node ans2=cal.getAns(c2);
		
		//cout<<ans1.c<<" "<<ans1.v<<endl;
		//cout<<ans2.c<<" "<<ans2.v<<endl;
		
		double p=ans2.c-ans1.c;
		double q=ans1.v-ans2.v;
		if(r!=1) cout<<endl;
		cout<<"Equation #"<<r++<<endl;
		if(q==0 && p==0){
			cout<<"Infinitely many solutions."<<endl;
		}
		else if(q==0){
			cout<<"No solution."<<endl;
		}
		else{
			cout<<"x = ";
			printf("%.6f\n",p/q);
		}
	}
	return 0;
}
