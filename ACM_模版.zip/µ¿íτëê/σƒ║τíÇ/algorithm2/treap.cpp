#include <iostream>
#include <cstdlib>

using namespace std;

//Key中的内容可能更复杂，比如字符串等。
struct Key{
    int value;

    bool operator < (const Key& other) const {
        return value < other.value;
    }
};

struct TNode {
    Key key;
    TNode* lch;//right child
    TNode* rch;//left child
    TNode* prnt;//parent
    int cnt;//Number of nodes in the subtree whose root is this node.
    int prio;//priority
};

class Treap {
private:
    TNode* m_root;

    //This node represents the NULL pointer, pointed by the children pointers
    //of the leaf nodes and the parent pointer of the root. Its only useful
    //field is "cnt" which is 0 (The node count of an empty subtree is
    //certainly zero).
    TNode* m_null;

    //Fix the tree to be a heap (each parent has a higher priority than its
    //children have). So while the given node has a lower priority than its
    //parent has, it is bubbled up by the leftRotate or rightRotate operation.
    void insertFixup(TNode* node) {
        while (node->prnt != NULL && node->prio > node->prnt->prio) {
            if (node == node->prnt->lch) {
                rightRotate(node->prnt);
            }
            else {
                leftRotate(node->prnt);
            }
        }
    }

    //把一个节点向左下方移一格，并让他原来的右子节点代替它的位置。
    void leftRotate(TNode* node) {
        TNode* right = node->rch;
        node->rch = right->lch;
        node->cnt -= (right->rch == NULL? 0: right->rch->cnt) + 1;
        if (node->rch != NULL) {
            node->rch->prnt = node;
        }
        right->prnt = node->prnt;
        if (right->prnt == NULL) {
            m_root = right;
        }
        else if (node == node->prnt->lch) {
            node->prnt->lch = right;
        }
        else {
            node->prnt->rch = right;
        }
        right->lch = node;
        right->cnt += (node->lch == NULL? 0: node->lch->cnt) + 1;
        node->prnt = right;
    }

    //把一个节点向右下方移一格，并让他原来的左子节点代替它的位置。
    void rightRotate(TNode* node) {
        TNode* left = node->lch;
        node->lch = left->rch;
        node->cnt -= (left->lch == NULL? 0: left->lch->cnt) + 1;
        if (node->lch != NULL) {
            node->lch->prnt = node;
        }
        left->prnt = node->prnt;
        if (left->prnt == NULL) {
            m_root = left;
        }
        else if (node == node->prnt->lch) {
            node->prnt->lch = left;
        }
        else {
            node->prnt->rch = left;
        }
        left->rch = node;
        left->cnt += (node->rch == NULL? 0: node->rch->cnt) + 1;
        node->prnt = left;
    }

    //Return the node with the maximum key in a subtree.
    TNode* max(TNode* root) const {
        TNode* result = root;
        while (result->rch != NULL) {
            result = result->rch;
        }
        return result;
    }

    //Return the node with the minimum key in a subtree.
    TNode* min(TNode* root) const {
        TNode* result = root;
        while (result->lch != NULL) {
            result = result->lch;
        }
        return result;
    }

public:
    Treap() {
        m_root = NULL;
    }

    ~Treap() {
        clear();
    }

    //Return the pointer to the (i + 1)th element in the sequence represented
    //by this tree. If is not in the range [0, size() - 1], return NULL.
    TNode* atIndex(int i) const {
        TNode* p = m_root;
        if (i < 0 || i >= size()) {
            p = NULL;
        }
        else {
            int lCnt = p->lch == NULL? 0: p->lch->cnt;
            while (i != lCnt) {
                if (i < lCnt) {
                    p = p->lch;
                }
                else {
                    i -= lCnt + 1;
                    p = p->rch;
                }
                lCnt = p->lch == NULL? 0: p->lch->cnt;
            }
        }
        return p;
    }

    void clear() {
        TNode* p = m_root;
        while (p != NULL) {
            if (p->lch != NULL) {
                p = p->lch;
            }
            else if (p->rch != NULL) {
                p = p->rch;
            }
            else {
                TNode* temp = p;
                p = p->prnt;
                if (temp == p->lch) {
                    p->lch = NULL;
                }
                else {
                    p->rch = NULL;
                }
                delete temp;
            }
        }
        m_root = NULL;
    }

    void del(TNode* node) {
        while (node->cnt > 1) {//Bubble down the node until it is a leaf.
            if (node->lch == NULL
                || node->lch != NULL && node->rch != NULL
                   && node->rch->prio > node->lch->prio) {
                leftRotate(node);
            }
            else {
                rightRotate(node);
            }
        }
        if (node == m_root) {
            m_root = NULL;
        }
        else if (node == node->prnt->lch) {
            node->prnt->lch = NULL;
        }
        else {
            node->prnt->rch = NULL;
        }
        for (TNode* p = node->prnt; p != NULL; p = p->prnt) {
            p->cnt--;
        }
        delete node;
    }

    //Return the index of the key (contained in the given node) in the sequence
    //represented by this tree.
    int indexOf(TNode* node) const {
        int lCnt = node->lch == NULL ? 0: node->lch->cnt;
        int i = lCnt;
        while (node->prnt != NULL) {
            TNode* temp = node;
            node = node->prnt;
            if (temp == node->rch) {
                lCnt = node->lch == NULL ? 0: node->lch->cnt;
                i += lCnt + 1;
            }
        }
        return i;
    }

    void insert(const Key& key) {
        TNode* node = new TNode;
        node->key = key;
        node->cnt = 1;
        node->lch = NULL;
        node->rch = NULL;
        node->prio = rand();

        TNode* p = m_root;
        TNode* leaf = NULL;
        while (p != NULL) {
            leaf = p;
            leaf->cnt++;
            if (node->key < p->key) {
                p = p->lch;
            }
            else {
                p = p->rch;
            }
        }
        node->prnt = leaf;
        if (leaf == NULL) {//An empty tree.
            m_root = node;
        }
        else if (node->key < leaf->key) {
            leaf->lch = node;
        }
        else {
            leaf->rch = node;
        }
        insertFixup(node);//Fix the tree to keep the balance.
    }

    //一个节点在中序遍列中的下一个节点。
    TNode* next(TNode* node) const {
        TNode* p;
        if (node->rch != NULL) {
            p = min(node->rch);
        }
        else {
            p = node->prnt;
            while (p != NULL && node == p->rch) {
                node = p;
                p = p->prnt;
            }
        }
        return p;
    }

    TNode* search(const Key& key) const {
        TNode* p = m_root;
        while (p != NULL) {
            if (key < p->key) {
                p = p->lch;
            }
            else if (p->key < key) {
                p = p->rch;
            }
            else break;
        }
        return p;
    }

    //把树中节点的值放进一个数组。
    void toArray(int* array) const {
        TNode* p = min(m_root);
        int i = 0;
        while (p != NULL) {
            array[i] = p->key.value;
            i++;
            p = next(p);
        }
    }

    //一个节点在中序遍列中的前一个节点。
    TNode* pre(TNode* node) const {
        TNode* p;
        if (node->lch != NULL) {
            p = max(node->lch);
        }
        else {
            p = node->prnt;
            while (p != NULL && node == p->lch) {
                node = p;
                p = p->prnt;
            }
        }
        return p;
    }

    void print(const TNode* root) const {
        if (root != NULL) {
            cout << root << " key: " << root->key.value;
            cout << " lch: " << root->lch << " rch: " << root->rch;
            cout << " cnt: " << root->cnt;
            cout << " priority: " << root->prio << endl;
            print(root->lch);
            print(root->rch);
        }
    }

    int size() const {
        return m_root != NULL? m_root->cnt: 0;
    }

    TNode* root() const {
        return m_root;
    }
};

int main() {
    Treap treap;
    char ins;
    int value;
    Key key;
    TNode* p;
    while (cin >> ins) {
        switch(ins) {
            case 'i':
                cin >> value;
                key.value = value;
                treap.insert(key);
                break;

            case 'd':
                cin >> value;
                key.value = value;
                p = treap.search(key);
                treap.del(p);
                break;

            case 'p':
                treap.print(treap.root());
                break;

            case 's':
                cin >> value;
                key.value = value;
                p = treap.search(key);
                cout << p << endl;
                break;

            case 'l':
                cin >> value;
                p = treap.atIndex(value);
                cout << p << endl;
                break;

            case 'x':
                cin >> value;
                key.value = value;
                p = treap.search(key);
                cout << treap.indexOf(p) << endl;
                break;

            case 'n':
                p = treap.atIndex(0);
                while(p != NULL) {
                    cout << p->key.value << " ";
                    p = treap.next(p);
                }
                cout << endl;
                break;

            case 'm':
                p = treap.atIndex(treap.size() - 1);
                while(p != NULL) {
                    cout << p->key.value << " ";
                    p = treap.pre(p);
                }
                cout << endl;
                break;
        }
    }
    return 0;
}
