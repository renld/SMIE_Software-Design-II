#include <cstdio>
#include <cstring>
using namespace std;

const int maxn=65536,maxf=17;
int v1[maxn][maxf];//v1[n][f]表示s[n..n+2^f)中的最大值
int v2[maxn][maxf];//v2[n][f]表示s[n..n+2^f)中的最大值
int N,Q;

inline int max(int a,int b){return a>b?a:b;} 
inline int min(int a,int b){return a<b?a:b;} 

int main(){
	freopen("lineupg.in","r",stdin);
	freopen("lineupg.out","w",stdout);

	scanf("%d%d",&N,&Q);
	for(int i=0;i<N;++i){
		scanf("%d",&v1[i][0]);
		v2[i][0]=v1[i][0];
	}
	for(int f=1,s=1;s<N;++f){
		for(int n=0;;++n){
			if(n+s>=N)break;
			v1[n][f]=max(v1[n][f-1],v1[n+s][f-1]);
			v2[n][f]=min(v2[n][f-1],v2[n+s][f-1]);
		}
		s=1<<f;
	}
	for(int i=0;i<Q;++i){
		int a,b;
		scanf("%d%d",&a,&b);
		--a;
		int d=b-a;
		int f;
		for(f=0;(1<<f) <= d; ++f);
		--f;
		printf("%d\n",max(v1[a][f],v1[b-(1<<f)][f])-min(v2[a][f],v2[b-(1<<f)][f]));
	}
}
