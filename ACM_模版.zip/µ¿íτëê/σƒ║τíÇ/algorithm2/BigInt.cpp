/////////////////////////////////////////////////////////////////////
//Big Integer
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <sstream>
#include <cstring>
#include <string>

using namespace std;

const int INT_LEN = 3000;

//A big integer which is 0 defaultly.
class BigInt {
    friend ostream& operator << (ostream& os, const BigInt& big);
    
private:
    typedef char Digit;
    typedef long long Num;
    
    Digit m_digit[INT_LEN];
    int m_len;
    
    //Compare m_digit with another array of digits.
    //Returns -1 if this number is lower than the other;
    //         0 if this number equals the other;
    //         1 if this number is greater than the other;
    int cmpWithArray(const Digit* digit, int len) const {
        int result = 0;
        if (m_len > len) {
            result = 1;
        }
        else if(m_len < len) {
            result=-1;
        }
        else{
            for (int i = m_len - 1; i >= 0 && result == 0; i--) {
                if (m_digit[i] > digit[i]) {
                    result = 1;
                }
                else if (m_digit[i] < digit[i]) {
                    result = -1;
                }
            }
        }
        return result;
    }
    
    //Convert an interger into an array of digit. The fisrt digit of the
    //array is the lowest digit of the given interger. So 123 is converted
    //into {3, 2, 1}.
    int int2Array(Num num, Digit* array) {
        int len = 1;
        array[0] = num % 10;
        num /= 10;
        while(num > 0) {
            array[len] = num % 10;
            len++;
            num /= 10;
        }
        return len;
    }
    
    //This function is the const version of "int2Array()". The texts of these
    //two functions are identical.
    int int2Array(Num num, Digit* array) const {
        int len = 1;
        array[0] = num % 10;
        num /= 10;
        while(num > 0) {
            array[len] = num % 10;
            len++;
            num /= 10;
        }
        return len;
    }
    
public:
    BigInt(int i = 0) {
        *this = i;
    }
    
    BigInt(Num i) {
        *this = i;
    }
    
    BigInt(const char* str) {
        *this = str;
    }
    
    void operator = (int i) {
        *this = (Num)i;
    }
    
    void operator = (Num value) {
        memset(m_digit, 0, sizeof(m_digit));
        m_len = int2Array(value, m_digit);
    }
    
    void operator = (const char* str) {
        m_len = strlen(str);
        memset(m_digit, 0, sizeof(m_digit));
        for(int i = 0; i < m_len; i++) {
            m_digit[i] = str[m_len - 1 - i] - '0';
        }
    }
    
    void operator += (const BigInt& add) {
        Digit carry = 0;
        for (int i = 0;i < m_len || i < add.m_len || carry > 0; i++) {
            if (i < m_len) {
                carry += m_digit[i];
            }
            if (i < add.m_len) {
                carry += add.m_digit[i];
            }
            m_digit[i] = carry % 10;
            carry /= 10;
            if (i >= m_len) {
                m_len = i + 1;
            }
        }
    }
    
    void operator += (Num add) {
        Num carry = add;
        for (int i = 0; carry > 0; i++) {
            if (i < m_len) {
                carry += (Num)m_digit[i];
            }
            m_digit[i] = (Digit)(carry % 10);
            carry /= 10;
            if (i >= m_len) {
                m_len = i + 1;
            }
        }
    }
    
    //Only for subtractor not greater than this number.
    void operator -= (const BigInt& sub) {
        int newLen = 1;
        Digit borrow = 0;
        for (int i = 0; i < m_len || borrow > 0; i++) {
            Digit dec = borrow;
            if (i < sub.m_len) {
                dec += sub.m_digit[i];
            }
            if (m_digit[i] < dec) {
                m_digit[i] = m_digit[i] + 10 - dec;
                borrow = 1;
            }
            else {
                m_digit[i] -= dec;
                borrow = 0;
            }
            if (m_digit[i] != 0) {
                newLen = i + 1;
            }
        }
        m_len = newLen;
    }
    
    //Only for subtractor not greater than this number.
    void operator -= (Num sub) {
        int newLen = 0;
        Num dec = sub;
        for (int i = 0; i < m_len; i++) {
            Num borrow = 0;
            if ((Num)m_digit[i] < dec) {
                borrow = 10;
                while (borrow + (Num)m_digit[i] < dec) {
                    borrow *= 10;
                }
            }
            Num temp = borrow + (Num)m_digit[i] - dec;
            dec = borrow / 10 - temp / 10;
            m_digit[i] = (Digit)(temp % 10);
            if (m_digit[i] > 0) {
                newLen = i + 1;
            }
        }
        m_len = newLen;
        if (m_len == 0) {
            m_len = 1;
            m_digit[0] = 0;
        }
    }
    
    void operator *= (const BigInt& mul) {
        Digit result[INT_LEN];
        memset(result, 0, sizeof(result));
        int newLen = 1;
        for (int otherInd = 0; otherInd < mul.m_len; otherInd++) {
            Digit carry = (Digit)0;
            int resultInd = otherInd;
            for (int selfInd = 0; selfInd < m_len; selfInd++) {
                result[resultInd] += mul.m_digit[otherInd] * m_digit[selfInd]
                        + carry;
                carry = result[resultInd] / 10;
                result[resultInd] = result[resultInd] % 10;
                if (resultInd >= newLen
                        && (result[resultInd] != 0 || carry != 0)
                        ) {
                    newLen = resultInd + 1;
                }
                resultInd++;
            }
            while (carry > 0) {
                result[resultInd] += carry;
                if (resultInd >= newLen) {
                    newLen = resultInd + 1;
                }
                carry /= 10;
            }
        }
        m_len = newLen;
        for (int i = 0; i < m_len; i++) {
            m_digit[i] = result[i];
        }
    }
    
    void operator *= (Num mul) {
        if (mul == 0) {
            memset(m_digit, 0, sizeof(m_digit));
            m_len = 1;
        }
        else {
            Num carry = 0;
            for (int i = 0; i < m_len; i++) {
                carry += (Num)m_digit[i] * mul;
                m_digit[i] = (Digit)(carry % 10);
                carry /= 10;
            }
            while (carry > 0) {
                m_digit[m_len] = (Digit)(carry % 10);
                m_len++;
                carry /= 10;
            }
        }
    }
    
    //If can not divide exactly, just reserve the integer part.
    void operator /= (const BigInt& div) {
        BigInt low = 0;
        BigInt high = *this;
        BigInt mid, temp;
        while (low.compare(high) < 0) {
            mid = low;
            mid += high;
            mid += 1;
            mid /= 2;
            temp = mid;
            temp *= div;
            if (temp.compare(*this) > 0) {
                high = mid;
                high -= 1;
            }
            else {
                low = mid;
            }
        }
        *this = low;
    }
    
    //If can not divide exactly, just reserve the integer part.
    void operator /= (Num divide) {
        Num carry = 0;
        int newLen = 0;
        for (int i = m_len - 1; i >= 0; i--) {
            Num temp = carry + m_digit[i];
            m_digit[i] = (Digit)(temp / divide);
            carry = (temp % divide) * 10;
            if (m_digit[i] != 0 && newLen == 0) {
                newLen = i + 1;
            }
        }
        if (newLen > 0) {
            m_len = newLen;
        }
        else {
            *this = 0;
        }
    }
    
    int compare(const BigInt& other) const {
        return cmpWithArray(other.m_digit, other.m_len);
    }
    
    int compare(Num other) const {
        Digit digit[21];
        int len = int2Array(other, digit);
        return cmpWithArray(digit, len);
    }
    
    void print() const {
        for(int i = m_len - 1; i >= 0; i--) {
            cout << (char)('0' + m_digit[i]);
        }
        cout << endl;
    }
    
    void toStr(char* str) const {
        for (int i = m_len - 1, j = 0; i >= 0; i--, j++) {
            str[j] = (char)('0' + m_digit[i]);
        }
        str[m_len] = '\0';
    }
};

ostream& operator << (ostream& os, const BigInt& big) {
    for(int i = big.m_len - 1; i >= 0; i--) {
        os << (char)('0' + big.m_digit[i]);
    }
    return os;
}

//Test suites. You can choose to type the parts which you want to use.
int main(){
    BigInt a, b, c, d;
    BigInt zero = 0;
    
    zero.compare(100);
    
    //Test add small integer.
    a = 0;
    a += 987654321987654321LL;
    a += 987654321;
    a += 0;
    cout << a << endl;//correct: 987654322975308642
    
    //Test add big integer.
    a = "0";
    b = "987654321987654321";
    a += b;
    b = 987654321;
    a += b;
    a += zero;
    cout << a << endl;//correct: 987654322975308642
    
    //Test subtract small integer.
    a = "123456789123456789";
    a -= 23456789000000000LL;//9 zeros;
    a -= 123456789;
    a -= 0;
    a -= 100000000000000000LL;//17 zeros;
    cout << a << endl;//correct: 0
    
    //Test subtract big integer.
    a = "123456789123456789";
    b = 123456789000000000LL;//9 zeros;
    a -= b;
    b = 123456789;
    a -= zero;
    a -= b;
    cout << a << endl;//correct: 0
    
    //Test multiply small integer.
    a = "987654321";
    a *= 123456789;
    a *= 123456789123456789LL;
    cout << a << " ";
    a *= 0;
    cout << a << " ";
    a = 0;
    a *= 123456789;
    cout << a << endl;//correct: 15053411126540858750378688638891241 0 0
    
    //Test multiply big integer.
    a = "987654321";
    b = 123456789;
    a *= b;
    cout << a << " ";
    a *= zero;
    cout << a << " ";
    a = 0;
    a *= b;
    cout << a << endl;//correct: 121932631112635269 0 0
    
    //Test divide small integer.
    a = "987654321987654321987654321";
    a /= 123456789;
    a /= 8000000080900000744LL;
    cout << a << " ";
    a = 123;
    a /= 123456789;
    cout << a << " ";
    a = 0;
    a /= 123456789;
    cout << a << endl;//correct: 1 0 0
    
    //Test divide big integer.
    a = "987654321987654321987654321";
    b = "123456789123456789";
    a /= b;
    cout << a << " ";
    a = "987654321987654321987654321";
    b = "987654321987654321987654320";
    a /= b;
    cout << a << " ";
    a = "987654321987654321987654321";
    b = "987654321987654321987654321";
    a /= b;
    cout << a << " ";
    a = "987654321987654321987654321";
    b = "987654321987654321987654322";
    a /= b;
    cout << a << " ";
    a = 0;
    b = 123456789123456789LL;
    a /= b;
    cout << a << endl;//correct: 8000000072 1 1 0 0
    
    //Test compare with small integer.
    a = 1;
    cout << a.compare(0) << " " << a.compare(1) << " ";
    cout << a.compare(123456) << endl;
    //correct: 1 0 -1
    
    //Test compare with big integer.
    a = "123456789123456789";
    b = a;
    c = a;
    c -= 1;
    d = a;
    d += 1;
    cout << a.compare(b) << " " << a.compare(c) << " " << a.compare(d) << endl;
    //correct: 0 1 -1
    return 0;
}
