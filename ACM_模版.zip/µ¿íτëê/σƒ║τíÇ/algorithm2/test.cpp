#include <iostream>
#include <list>

using namespace std;

int main(){
	list<int> stack;
	int n;
	for(int i=0;i<5;i++){
		cin>>n;
		stack.push_front(n);
	}
	for(int i=0;i<5;i++){
		cout<<stack.front()<<" ";
		stack.pop_front();
	}
	cin>>n;
	return 0;
}
