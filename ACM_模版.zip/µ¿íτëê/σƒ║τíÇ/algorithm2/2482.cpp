#include <cstdio>
#include <map>
#include <algorithm>
#include <climits>

using namespace std;

const int MAX_STAR = 10000;

/////////////////////////////////////////////////////////////////////
//Segment tree.
/////////////////////////////////////////////////////////////////////
typedef long long BType;

struct TNode {
    BType left;
    BType right;
    int value;
    TNode* prnt;
    TNode* lch;
    TNode* rch;

    TNode (BType l, BType r, int v = 0) {
        left = l;
        right = r;
        value = 0;
        prnt = lch = rch = NULL;
    }
};

class SegTree {
private:
    TNode* m_root;

    //Recursively clear the subtree whose root is "p".
    void clear(TNode* p) {
        if (p != NULL) {
            clear(p->lch);
            clear(p->rch);
            delete p;
        }
    }

    void add(BType p, int v, TNode* root) {
        root->value += v;
        if (root->value == 0) {//Clear the subtree when reaching 0;
            if (root->prnt == NULL) {//It's the root of the whole tree.
                init(root->left, root->right);
            }
            else {
                if (root == root->prnt->lch) {
                    root->prnt->lch = NULL;
                }
                else {
                    root->prnt->rch = NULL;
                }
                clear(root);
            }
        }
        else if (root->left != root->right) {
            BType mid = (root->left + root->right) / 2;
            if (p <= mid) {
                if (root->lch == NULL) {
                    root->lch = new TNode(root->left, mid);
                    root->lch->prnt = root;
                }
                add(p, v, root->lch);
            }
            else {
                if (root->rch == NULL) {
                    root->rch = new TNode(mid + 1, root->right);
                    root->rch->prnt = root;
                }
                add(p, v, root->rch);
            }
        }
    }

    int getValue(BType left, BType right, TNode* p) {
        int result = 0;
        if (p != NULL) {
            if (left == p->left && right == p->right) {
                result = p->value;
            }
            else {
                BType mid = (p->left + p->right) / 2;
                if (left <= mid) {
                    if (right <= mid) {
                        result = getValue(left, right, p->lch);
                    }
                    else {
                        result = getValue(left, mid, p->lch)
                                 + getValue(mid + 1, right, p->rch);
                    }
                }
                else {
                    result = getValue(left, right, p->rch);
                }
            }
        }
        return result;
    }

public:
    SegTree (BType left = 0, BType right = 0) {
        m_root = NULL;
        init(left, right);
    }

    ~SegTree () {
        clear(m_root);
    }

    //Initialize a tree of the rang [left, right].
    void init(BType left, BType right) {
        clear(m_root);
        m_root = new TNode(left, right);
    }

    //Add value "v" at the position "p".
    void add(BType p, int v) {
        //printf("add: %lld %d\n", p, v);
        if (p >= m_root->left && p <= m_root->right) {
            add(p, v, m_root);
        }
    }

    //Get the value in the range [left, right].
    int getValue(BType left, BType right) {
        int result = 0;
        left = m_root->left <= left? left: m_root->left;
        right = m_root->right >= right? right: m_root->right;
        if (left <= right) {
            result = getValue(left, right, m_root);
        }
        return result;
    }
};


struct Star {
    int x;
    int y;
    int light;

    bool operator < (const Star& other) const {
        return x < other.x;
    }
};

SegTree g_tree;
Star g_star[MAX_STAR];
int g_starCnt;
int g_wid, g_hei;
int g_minY, g_maxY;
//g_y[i] == j means these are "j" stars whose y coordinates are "i".
map<int, int> g_y;

void addStar(const Star& s) {
    if (g_y.find(s.y) == g_y.end()) {
        g_y[s.y] = 1;
    }
    else {
        g_y[s.y]++;
    }
    g_tree.add(s.y, s.light);
}

void delStar(const Star& s) {
    g_y[s.y]--;
    if (g_y[s.y] == 0) {
        g_y.erase(s.y);
    }
    g_tree.add(s.y, -s.light);
}

void solve () {
    sort(g_star, g_star + g_starCnt);
    g_tree.init(g_minY, g_maxY);
    g_y.clear();
    int max = 0;
    int addInd = 0;
    int delInd = 0;
    while (addInd < g_starCnt) {
        int left = g_star[delInd].x;
        printf("left: %d\n", left);
        int right = left + g_wid;
        while (addInd < g_starCnt && g_star[addInd].x < right) {
            addStar(g_star[addInd]);
            addInd++;
        }
        for (map<int, int>::iterator i = g_y.begin(); i != g_y.end(); i++) {
            int upper = (i->first <= INT_MAX - g_hei + 1? i->first + g_hei - 1: INT_MAX);
            int light = g_tree.getValue(i->first, upper);
            printf("range: %d -> %d: %d\n", i->first, i->first + g_hei - 1, light);
            max = light > max? light: max;
        }
        do {
            delStar(g_star[delInd]);
            delInd++;
        } while (delInd < g_starCnt
                 && g_star[delInd].x == g_star[delInd - 1].x
                );
    }
    printf("%d\n", max);
}

bool input() {
    bool hasNext = false;
    if (scanf("%d %d %d", &g_starCnt, &g_wid, &g_hei) == 3) {
        hasNext = true;
        g_minY = INT_MAX;
        g_maxY = 0;
        for (int i = 0; i < g_starCnt; i++) {
            scanf("%d %d %d", &g_star[i].x, &g_star[i].y, &g_star[i].light);
            g_minY = g_star[i].y < g_minY? g_star[i].y: g_minY;
            g_maxY = g_star[i].y > g_maxY? g_star[i].y: g_maxY;
        }
    }
    return hasNext;
}

int main() {
    while (input()) {
        solve();
    }
    return 0;
}
