#include <iostream>
#include <cstring>
using namespace std;

class Problem{
private:
	int y,m,d;
	char ans[110][12][31];
	
public:
	Problem(){
		memset(ans,-1,sizeof(ans));
		ans[2001-1900][11-1][4-1]=0;
	}
	bool isleap(int y){
		if(y%400==0) return true;
		if(y%100==0) return false;
		if(y%4==0) return true;
		else return false;
	}
	bool outday(int y,int m,int d){
		if(y>2001) return true;
		if(y==2001){
			if(m>11) return true;
			if(m==11){
				if(d>4) return true;
			}
		}
		return false;
	}
	int getdate(int m,int y){
		if(m==2){
			if(isleap(y)) return 29;
			else return 28;
		}
		else{
			switch(m){
				case 1:
				case 3:
				case 5:
				case 7:
				case 8:
				case 10:
				case 12:return 31;
				case 4:
				case 6:
				case 9:
				case 11:return 30;
			}
		}
	}
	bool nextday(int &y,int &m,int &d){
		bool ans=true;
		if(d==getdate(m,y)){
			d=1;
			m++;
			if(m==13){
				m=1;
				y++;
			}
		}
		else{
			d++;
		}
		if(outday(y,m,d)) ans=false;
		return ans;
	}
	bool nextmonth(int &y,int &m,int &d){
		bool ans=true;
		m++;
		if(m==13){
			m=1;
			y++;
		}
		if(d>getdate(m,y)) ans=false;
		if(outday(y,m,d)) ans=false;
		return ans;
	}
	void Input(){
		cin>>y>>m>>d;
	}
	char getAns(int y,int m,int d){
		if(ans[y-1900][m-1][d-1]!=-1) return ans[y-1900][m-1][d-1];
		else{
			int yy,mm,dd;
			yy=y; mm=m; dd=d;
			bool t1=nextday(yy,mm,dd);
			if(t1){
				char tt1=getAns(yy,mm,dd);
				if(tt1==0){
					ans[y-1900][m-1][d-1]=1;
					return 1;
				}
			}
			yy=y; mm=m; dd=d;
			bool t2=nextmonth(yy,mm,dd);
			if(t2){
				char tt2=getAns(yy,mm,dd);
				if(tt2==0){
					ans[y-1900][m-1][d-1]=1;
					return 1;
				}
			}
			ans[y-1900][m-1][d-1]=0;
			return 0;
		}
	}
	void Print(){
		char ans=getAns(y,m,d);
		if(ans==1)
			cout<<"YES"<<endl;
		else 
			cout<<"NO"<<endl;
	}
};

int main(){
	Problem pro;
	int r;
	cin>>r;
	for(int i=0;i<r;i++){
		pro.Input();
		pro.Print();
	}
	return 0;
}
