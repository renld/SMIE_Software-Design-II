#include <iostream>
#include <queue>
using namespace std;
const int mmm=400000;
bool haveturn;
class state{
public:
	char c[9];
	int last;
	char flag;
	char laststep;
	int hash;
	void setc(char x[]){
		for(int i=0;i<9;i++){
			c[i]=x[i];
		}
	}
	void input(){
		for(int i=0;i<9;i++){
			cin>>c[i];
			if(c[i]=='x'){
				c[i]='9';
			}
		}
	}
	void init(){
		hash=-1;
		last=-1;
		flag=0;
	}
	state turn(int d){
		int i;
		state ans;
		ans.init();
		for(int j=0;j<9;j++){
			ans.c[j]=c[j];
		}
		for(i=0;i<9;i++){
			if(ans.c[i]=='9') break;
		}
		char t;
		switch(d){
			case 0:	if(i<3){haveturn=false;break;}
					else{
						ans.c[i]=ans.c[i-3];
						ans.c[i-3]='9';
						ans.laststep='u';
					}
					break;
			case 1:	if(i%3==2){haveturn=false;break;}
					else{
						ans.c[i]=ans.c[i+1];
						ans.c[i+1]='9';
						ans.laststep='r';
					}
					break;
			case 2:	if(i>5){haveturn=false;break;}
					else{
						ans.c[i]=ans.c[i+3];
						ans.c[i+3]='9';
						ans.laststep='d';
					}
					break;
			case 3: if(i%3==0){haveturn=false;break;}
					else{
						ans.c[i]=ans.c[i-1];
						ans.c[i-1]='9';
						ans.laststep='l';
					}
					break;
		}
		return ans;
	}
	int getHash(){
		if(hash!=-1) return hash;
		bool a[9]={0};
		char s[9]={0};
		int ans=0;
		for(int i=0;i<9;i++){
			int k=c[i]-'0'-1;
			for(int j=0;j<k;j++){
				if(!a[j]) s[k]++;
			}
			a[k]=true;
		}
		int j=1;
		for(int i=1;i<9;i++){
			j*=i;
			ans+=s[i]*j;
		}
		hash=ans;
		return ans;
	}
	void print(){
		cout<<endl;
		cout<<c[0]<<" "<<c[1]<<" "<<c[2]<<endl;
		cout<<c[3]<<" "<<c[4]<<" "<<c[5]<<endl;
		cout<<c[6]<<" "<<c[7]<<" "<<c[8]<<endl;
		cout<<"-----"<<endl;
	}
};
state all[mmm];


int main(){
	for(int i=0;i<mmm;i++){
		all[i].init();
	}
	queue<state> p;
	queue<state> q;
	
	state s;
	s.input();
	s.init();
	s.flag=1;
	all[s.getHash()]=s;
	
	state e;
	char c[]="123456789";
	e.setc(c);
	e.init();
	e.flag=2;
	all[e.getHash()]=e;
	
	while(!p.empty()) p.pop();
	while(!q.empty()) q.pop();
	p.push(s);
	q.push(e);
	char out[10000];
	int cnt=0;
	
	bool find=false;
	while(!p.empty()||!q.empty()){
		//p
		state temp;
		temp=p.front();
		p.pop();
		for(int i=0;i<4;i++){
			haveturn=true;
			state k=temp.turn(i);
			if(!haveturn) continue;
			k.last=temp.hash;
			int po=k.getHash();
			char flag=all[po].flag;
			if(flag==0){
				k.flag=1;
				p.push(k);
				all[po]=k;
			}
			else if(flag==1){
				continue;
			}
			else{//print
				//cout<<"++++++"<<endl;
				while(k.last!=-1){
					out[cnt++]=k.laststep;
					k=all[k.last];
				}
				for(int i=cnt-1;i>=0;i--){
					cout<<out[i];
				}
				k=all[po];
				while(k.last!=-1){
					//k.print();
					switch(k.laststep){
						case 'l':cout<<'r';break;
						case 'r':cout<<'l';break;
						case 'u':cout<<'d';break;
						case 'd':cout<<'u';break;
					}
					k=all[k.last];
				}
				cout<<endl;
				find=true;
				break;
			}
		}
		if(find) break;
		//q
		temp=q.front();
		q.pop();
		for(int i=0;i<4;i++){
			haveturn=true;
			state k=temp.turn(i);
			if(!haveturn) continue;
			k.last=temp.hash;
			int po=k.getHash();
			char flag=all[po].flag;
			if(flag==0){
				k.flag=2;
				q.push(k);
				all[po]=k;
			}
			else if(flag==2){
				continue;
			}
			else{//print
			//cout<<"##########"<<endl;
				state kk=all[po];
				while(kk.last!=-1){
					out[cnt++]=kk.laststep;
					kk=all[kk.last];
				}
				for(int i=cnt-1;i>=0;i--){
					cout<<out[i];
				}
				
				while(k.last!=-1){
					//k.print();
					switch(k.laststep){
						case 'l':cout<<'r';break;
						case 'r':cout<<'l';break;
						case 'u':cout<<'d';break;
						case 'd':cout<<'u';break;
					}
					k=all[k.last];
				}
				cout<<endl;
				find=true;
				break;
			}
		}
		
		if(find) break;
	}
	if(!find){
		cout<<"unsolvable"<<endl;
	}
	
	return 0;
}

