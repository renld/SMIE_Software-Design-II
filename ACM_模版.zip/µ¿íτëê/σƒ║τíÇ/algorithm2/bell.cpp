int main(){
    BigInt x, y, x1, y1, t;
    int a, SN, P, Q;
    int f = -1, N;
    int kase=1;
    while(cin >> N) {
        f = -1;
        SN = (int)sqrt(N);
        P = SN;
        Q = N - P*P;
        x = SN;
        y = 1;
        x1 = 1;
        y1 = 0;
        bool flg = false;
        while(Q*f!=1) {
            if ( Q==0 ) {
                cout<<"No solution!"<<endl;
                flg = true;
                break;
            }
            a = (SN+P)/Q;
            P = a*Q-P;
            Q = (N-P*P)/Q;
            f *= -1;
            t = x;
            x = x*a + x1;
            x1 = t;
            t = y;
            y = y*a + y1;
            y1 = t;
        }
        if ( !flg ) {
            cout<<x<<" "<<y<<endl;
        }
    }
    return 0;
}