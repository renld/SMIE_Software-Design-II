#include <cstdio>
#include <cctype>
#include <cstring>

using namespace std;

const int MAX_WORD = 100;
//Constants representing the type of words.
const int WD_END = 0;
const int WD_NUM = 1;
const int WD_VAR = 2;
const int WD_MARK = 3;

struct Word {
    int type;
    int iValue;//Integer value;
    char cValue;//Character value, if the type is not WD_NUM;
};

class WordStream {
private:
    Word m_word[MAX_WORD];
    int m_wdCnt;
    int m_rdPoint;

    //Return the string length of a positive integer less than 10^9.
    int intLen(int num) {
        int len = 1;
        int times = 10;
        while (num >= times) {
            len++;
            times *= 10;
        }
        return len;
    }

public:
    bool hasNext() {
        return m_rdPoint < m_wdCnt;
    }

    void init(const char* buf) {
        m_wdCnt = 0;
        m_rdPoint = 0;
        int len = strlen(buf);
        int i = 0;
        while (i < len) {
            if (isdigit(buf[i])) {
                m_word[m_wdCnt].type = WD_NUM;
                sscanf(buf + i, "%d", &m_word[m_wdCnt].iValue);
                i += intLen(m_word[m_wdCnt].iValue);
                m_wdCnt++;
            }
            else if (buf[i] != ' ') {
                if (isalpha(buf[i])) {
                    m_word[m_wdCnt].type = WD_VAR;
                }
                else {
                    m_word[m_wdCnt].type = WD_MARK;
                }
                sscanf(buf + i, "%c", &m_word[m_wdCnt].cValue);
                m_wdCnt++;
                i++;
            }
            else {
                i++;
            }
        }
        m_word[m_wdCnt].type = WD_END;
        m_word[m_wdCnt].cValue = '#';
        m_wdCnt++;
    }

    Word next() {
        m_rdPoint++;
        return m_word[m_rdPoint - 1];
    }
};
