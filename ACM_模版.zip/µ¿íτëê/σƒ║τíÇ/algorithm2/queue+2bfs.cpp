#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>

using namespace std;

const int MAXSIZE = 1 << 16;

struct State{
	int count, prev, vis, op;
	int row, col;

	State(){
		count = 0;
		prev = -1;
		vis = 0;
	}
}states[MAXSIZE];

queue<int> q1, q2;

inline int flip(int mask, int row, int col){
	int tmp = mask;
	int i = 4 * row + col;
    tmp = tmp ^ (1 << i);
            
    int p;
            
    p = i - 4;
    while(p >= 0) { tmp = tmp ^ (1 << p); p -= 4; }
    
    p = i + 4;
    while(p < 16) { tmp = tmp ^ (1 << p); p += 4; }
            
    p = i / 4 * 4;
    while(p < i) { tmp = tmp ^ (1 << p); p++; }
            
    p = (i / 4 + 1) * 4 - 1;
    while(p > i) { tmp = tmp ^ (1 << p); p--; }

	return tmp;
}

void print_init_path(int p, const int initState){
	if (p == initState) return;
	print_init_path(states[p].prev, initState);
	printf("%d %d\n", states[p].row + 1, states[p].col + 1);
}

void print_end_path(int p, const int endState){
	if (p == endState) return;
	printf("%d %d\n", states[p].row + 1, states[p].col + 1);
	print_end_path(states[p].prev, endState);
}

void output(int s1, int s2, int r, int c, const int initState, const int endState){
	printf("%d\n", states[s1].count + states[s2].count + 1);
	print_init_path(s1, initState);
	printf("%d %d\n", r + 1, c + 1);
	print_end_path(s2, endState);
}

void solve(int initState)
{
	int row, col, endState = 0;
	if (initState == endState){
		printf("0\n");
		return;
	}
	while (!q1.empty()) q1.pop();
	while (!q2.empty()) q2.pop();
	q1.push(initState);
	q2.push(endState);
	states[initState].prev = initState;
	states[initState].vis = 1;
	states[endState].prev = endState;
	states[endState].vis = -1;
	while (1){
		if (q1.empty() || q2.empty()) break;
		
		// extend q1
		int v1 = q1.front(); q1.pop();
		for (row = 0; row < 4; row++)
			for (col = 0; col < 4; col++){
				int mask = flip(v1, row, col);
				if (states[mask].vis == -1){
					output(v1, mask, row, col, initState, endState);
					return;
				}
				else if (states[mask].vis == 0){
					states[mask].prev = v1;
					states[mask].count = states[v1].count + 1;
					states[mask].row = row;
					states[mask].col = col;
					states[mask].vis = 1;
					q1.push(mask);
				}
			}

		// extend q2
		int v2 = q2.front(); q2.pop();
		for (row = 0; row < 4; row++)
			for (col = 0; col < 4; col++){
				int mask = flip(v2, row, col);
				if (states[mask].vis == 1){
					output(mask, v2, row, col, initState, endState);
					return;
				}
				else if (states[mask].vis == 0){
					states[mask].prev = v2;
					states[mask].count = states[v2].count + 1;
					states[mask].row = row;
					states[mask].col = col;
					states[mask].vis = -1;
					q2.push(mask);
				}
			}
	}
}

int main()
{
	int initState = 0;
	for(int i = 0; i < 16; )
        switch(getchar())
        {
            case '+' : initState |= (1 << i); i++; continue; 
            case '-' : i++; continue; 
        }
	solve(initState);
return 0;
}