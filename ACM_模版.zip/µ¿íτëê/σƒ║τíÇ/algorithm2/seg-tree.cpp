#include <iostream>

using namespace std;

/////////////////////////////////////////////////////////////////////
//Segment tree.
/////////////////////////////////////////////////////////////////////

//Type of the bound. Sometimes it may be too big to use "int" type.
typedef long long BType;

struct TNode {
    BType left;
    BType right;
    int value;
    TNode* prnt;
    TNode* lch;
    TNode* rch;

    TNode (BType l, BType r, int v = 0) {
        left = l;
        right = r;
        value = v;
        prnt = lch = rch = NULL;
    }
};

class SegTree {
private:
    TNode* m_root;

    //Recursively clear the subtree whose root is "p".
    void clear(TNode* p) {
        if (p != NULL) {
            clear(p->lch);
            clear(p->rch);
            delete p;
        }
    }

    void add(BType p, int v, TNode* root) {
        root->value += v;
        if (root->value == 0) {//Clear the subtree when reaching 0;
            if (root->prnt == NULL) {//It's the root of the whole tree.
                init(root->left, root->right);
            }
            else {
                if (root == root->prnt->lch) {
                    root->prnt->lch = NULL;
                }
                else {
                    root->prnt->rch = NULL;
                }
                clear(root);
            }
        }
        else if (root->left != root->right) {
            BType mid = (root->left + root->right) / 2;
            if (p <= mid) {
                if (root->lch == NULL) {
                    root->lch = new TNode(root->left, mid);
                    root->lch->prnt = root;
                }
                add(p, v, root->lch);
            }
            else {
                if (root->rch == NULL) {
                    root->rch = new TNode(mid + 1, root->right);
                    root->rch->prnt = root;
                }
                add(p, v, root->rch);
            }
        }
    }

    int getValue(BType left, BType right, TNode* p) {
        int result = 0;
        if (p != NULL) {
            if (left == p->left && right == p->right) {
                result = p->value;
            }
            else {
                BType mid = (p->left + p->right) / 2;
                if (left <= mid) {
                    if (right <= mid) {
                        result = getValue(left, right, p->lch);
                    }
                    else {
                        result = getValue(left, mid, p->lch)
                                 + getValue(mid + 1, right, p->rch);
                    }
                }
                else {
                    result = getValue(left, right, p->rch);
                }
            }
        }
        return result;
    }

public:
    SegTree (BType left = 0, BType right = 0) {
        m_root = NULL;
        init(left, right);
    }

    ~SegTree () {
        clear(m_root);
    }

    //Initialize a tree of the rang [left, right].
    void init(BType left, BType right) {
        clear(m_root);
        m_root = new TNode(left, right);
    }

    //Add value "v" at the position "p".
    void add(BType p, int v) {
        if (p >= m_root->left && p <= m_root->right) {
            add(p, v, m_root);
        }
    }

    //Get the value in the range [left, right].
    int getValue(BType left, BType right) {
        int result = 0;
        left = m_root->left <= left? left: m_root->left;
        right = m_root->right >= right? right: m_root->right;
        if (left <= right) {
            result = getValue(left, right, m_root);
        }
        return result;
    }
};

//Test suites:
int main() {
    SegTree tree(5, 20);
    int add[8][2] = {{6, 1}, {8, 5}, {16, 2}, {20, 7},
                     {13, 4}, {14, 6}, {10, 2}, {11, 3}};
    int del[4][2] = {{5, 0}, {11, -3}, {14, -5}, {20, -7}};
    int get[9][2] = {{5, 10}, {10, 15}, {15, 20}, {5, 5}, {20, 20}, {5, 20},
                     {0, 100}, {1, 2}, {99, 99}};
    for (int i = 0; i < 8; i++) tree.add(add[i][0], add[i][1]);
    for (int i = 0; i < 9; i++)
        cout << tree.getValue(get[i][0], get[i][1]) << " ";
    for (int i = 0; i < 4; i++) tree.add(del[i][0], del[i][1]);
    for (int i = 0; i < 9; i++)
        cout << tree.getValue(get[i][0], get[i][1]) << " ";
    cout << endl;//Correct: 8 15 9 0 7 30 30 0 0 8 7 2 0 0 15 15 0 0
    return 0;
}
