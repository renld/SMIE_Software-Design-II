//���У�totient����ŷ��������numy����Լ������ ans����uva11064
//ע�⵱n=1ʱ�����
#include <iostream>
#include <cmath>
#include <cstring>
using namespace std;
const int MMM=60000;
class Problem{
private:
	int ans;
	int cnt;
	int N,n;
	int prime[6500];
public:
	void init(){
		bool a[MMM];
		memset(a,0,MMM);
		cnt=0;
		int i;
		bool t=true;
		for(i=2;i<MMM;i++){
			if(!a[i]){
				prime[cnt++] = i;
				//cout<<i<<" ";
				if(t){
					for(int j=i*i;j<MMM;j+=i){
						a[j]=true;
					}
					if(i*i>=MMM) t=false;
				}
			}
		}
		//cout<<endl<<cnt<<endl;
	}
	bool input(){
		if(cin>>N){
			return true;
		}
		return false;
	}
	void solve(){
        n=N;
        int i=0;
		int totient = 1 ;
		while ( i<cnt && prime[i]*prime[i]<=n ) {
			if ( n%prime[i]==0 ) {
				while ( n%prime[i]==0 ){
					n/=prime[i];
					totient*=prime[i];
				}
				totient=totient/prime[i]*(prime[i]-1);
			}
			i++;
		}
		if ( n!=1 ) {
			totient*=(n-1);
		}

		int numy=1;
		i=0;n=N;
		while ( i<cnt && prime[i]*prime[i]<=n ) {
			if ( n%prime[i]==0 ) {
				int temp=1;
				while ( n%prime[i]==0 ){
					n/=prime[i];
					temp++;
				}
				numy*=temp;
			}
			i++;
		}
		if ( n!=1 ) {
			numy*=2;
		}
		//cout<<N<<" "<<totient<<" "<<numy<<" ";
		ans = N-totient-numy+1;
	}
	void print(){
		cout<<ans<<endl;
	}
};
int main(){
	Problem pro;
	pro.init();
	while(pro.input()){
		pro.solve();
		pro.print();
	}
	return 0;
}


