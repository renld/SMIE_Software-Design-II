/////////////////////////////////////////////////////////////////////
//Network represented by both adjacent lists and matrix. Do BFS by
//adjacent lists, and access flows of each edge by matrix.
/////////////////////////////////////////////////////////////////////
#include <cstring>
#include <climits>
#include <list>

using namespace std;

const int MAX_VERTEX = 500;

class Network {
private:
    struct Edge {
        int to;
        int capa;
        int flow;
        int cost;
        Edge* next;
        Edge* rev;

        Edge(int _to, int _capa, int _cost = 0) {
            to = _to;
            capa = _capa;
            cost = _cost;
            flow = 0;
        }
    };

    struct Path {//To store a vertex on an augment path.
        int pre;
        int capa;
        int cost;
        Edge* edge;
    };

    Edge* m_adjList[MAX_VERTEX];
    Edge* m_matrix[MAX_VERTEX][MAX_VERTEX];
    int m_vertexCnt;
    int m_source;
    int m_sink;
    Path m_path[MAX_VERTEX];
    int m_minCost;

    bool findAugment() {
        for (int i = 0; i < m_vertexCnt; i++) {
            m_path[i].pre = -1;
        }
        list<int> que;
        que.push_back(m_source);
        m_path[m_source].pre = m_source;
        m_path[m_source].capa = INT_MAX;

        while (!que.empty() && m_path[m_sink].pre == -1) {
            int from = que.front();
            que.pop_front();
            for (Edge* p = m_adjList[from]; p != NULL; p = p->next) {
                int augment = p->capa - p->flow;
                if (augment > 0 && m_path[p->to].pre == -1) {
                    m_path[p->to].pre = from;
                    m_path[p->to].edge = p;
                    m_path[p->to].capa
                    = m_path[from].capa < augment? m_path[from].capa: augment;
                    que.push_back(p->to);
                }
            }
        }
        return m_path[m_sink].pre != -1;
    }

    //Find an augment path with 1 unit of flow and minimum cost.
    bool findMinCostAugment() {
        for (int i = 0; i < m_vertexCnt; i++) {
            m_path[i].pre = -1;
            m_path[i].cost = INT_MAX;
        }
        m_path[m_source].pre = m_source;
        m_path[m_source].cost = 0;
        list<int> que;
        que.push_back(m_source);

        while (!que.empty()) {
            int from = que.front();
            que.pop_front();
            Edge* edge = m_adjList[from];
            while (edge != NULL) {
                if (edge->capa > edge->flow) {
                   int cost = m_path[from].cost + edge->cost;
                   int to = edge->to;
                   if (cost < m_path[to].cost) {
                       m_path[to].cost = cost;
                       m_path[to].pre = from;
                       m_path[to].edge = edge;
                       if (to != m_sink) {
                           que.push_back(to);
                       }
                   }
                }
                edge = edge->next;
            }
        }
        return m_path[m_sink].pre != -1;
    }

public:
    Network() {
        //Set all the pointers to NULL.
        memset(m_adjList, 0, sizeof(m_adjList));
        memset(m_matrix, 0, sizeof(m_matrix));
        m_vertexCnt = 0;
    }

    ~Network() {
        clear();
    }

    void addEdge(int from, int to, int capa, int revCapa, int cost = 0) {
        if (m_matrix[from][to] == NULL) {
            m_matrix[from][to] = new Edge(to, 0, cost);
            m_matrix[from][to]->next = m_adjList[from];
            m_adjList[from] = m_matrix[from][to];
        }
        m_matrix[from][to]->capa += capa;

        if (m_matrix[to][from] == NULL) {
            m_matrix[to][from] = new Edge(from, 0, -cost);
            m_matrix[to][from]->next = m_adjList[to];
            m_adjList[to] = m_matrix[to][from];
        }
        m_matrix[to][from]->capa += revCapa;

        m_matrix[from][to]->rev = m_matrix[to][from];
        m_matrix[to][from]->rev = m_matrix[from][to];
    }

    void clear() {
        for (int i = 0; i < m_vertexCnt; i++) {
            for (int j = 0; j < m_vertexCnt; j++) {
                delete m_matrix[i][j];
                m_matrix[i][j] = NULL;
            }
        }
        memset(m_adjList, 0, m_vertexCnt * sizeof(Edge*));
    }

    void init(int vertexCnt, int source, int sink) {
        clear();
        m_vertexCnt = vertexCnt;
        m_source = source;
        m_sink = sink;
    }

    int getFlow(int from, int to) const {
        return m_matrix[from][to] != NULL
               ? m_matrix[from][to]->flow: 0;
    }

    int maxFlow() {
        int result = 0;
        while (findAugment()) {
            int flow = m_path[m_sink].capa;
            for (int i = m_sink; i != m_source; i = m_path[i].pre) {
                m_path[i].edge->flow += flow;
                m_path[i].edge->rev->flow = -m_path[i].edge->flow;
            }
            result += flow;
        }
        return result;
    }

    //Before invoking this function, "minCostMaxFlow()" must be invoked.
    int minCost() const {
        return m_minCost;
    }

    int minCostMaxFlow() {
        int result = 0;
        m_minCost = 0;
        while (findMinCostAugment()) {
            for (int i = m_sink; i != m_source; i = m_path[i].pre) {
                m_path[i].edge->flow++;
                m_path[i].edge->rev->flow--;
            }
            result++;
            m_minCost += m_path[m_sink].cost;
        }
        return result;
    }
};

//Test suites.
#include <iostream>

void testMaxFlow() {
    Network network;
    network.init(10, 0, 9);
    int from[] = {0, 0, 0, 4, 5, 6, 7, 8, 1, 1, 1, 3, 3, 3};
    int to[] = {1, 2, 3, 9, 9, 9, 9, 9, 5, 6, 7, 5, 6, 7};
    for (int i = 0; i < 14; i++) {
        network.addEdge(from[i], to[i], 1, 0);
    }
    cout << network.maxFlow() << " ";
    int a[] = {2, 1, 1, 3, 6, 5};
    int b[] = {6, 5, 6, 7, 9, 9};
    for (int i = 0; i < 6; i++) {
        cout << network.getFlow(a[i], b[i]) << " ";
    }
    cout << endl;//Correct output: "2 0 0 1 1 1 0"
}

void testMinCost() {
    Network network;
    network.init(9, 0, 8);
    int from[] = {0, 0, 0, 1, 1, 2, 1, 2, 3, 4, 5, 6, 7};
    int to[]   = {1, 2, 3, 5, 6, 6, 7, 7, 7, 8, 8, 8, 8};
    int x = INT_MAX;
    int capa[] = {3, 2, 4, x, x, x, x, x, x, 3, 2, 4, x};
    int co[] = {0, 0, 0, 6, 3, 6, 10, 10, 10, 0, 0, 0, 0};
    for (int i = 0; i < 13; i++) {
        network.addEdge(from[i], to[i], capa[i], 0, co[i]);
    }
    int flow = network.minCostMaxFlow();
    int cost = network.minCost();
    cout << flow << " " << cost << " ";
    int a[] = {1, 2, 3, 7, 4, 5};
    int b[] = {7, 6, 7, 8, 8, 6};
    for (int i = 0; i < 6; i++) {
        cout << network.getFlow(a[i], b[i]) << " ";
    }
    cout << endl;//Correct output: "9 64 0 2 4 4 0 0".
}

int main() {
    testMaxFlow();
    testMinCost();
    return 0;
}
