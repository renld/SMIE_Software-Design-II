/////////////////////////////////////////////////////////////////////
//Geometry algorithms.
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>

using namespace std;

typedef long double Real;

struct XY;

ostream& operator << (ostream&, const XY&);
Real crsProd(const XY&, const XY&);
Real disLine(const XY&, const XY&, const XY&, const XY&);
Real dotProd(const XY&, const XY&);
Real disSeg(const XY&, const XY&, const XY&, const XY&);
Real dSeg2Line(const XY&, const XY&, const XY&, const XY&);
XY interLine(const XY&, const XY&, const XY&, const XY&);
int interLineCirc(const XY&, const XY&, const XY&, Real, XY*);
int interCircle(const XY&, Real, const XY&, Real, XY*);
bool isLineInter(const XY&, const XY&, const XY&, const XY&);
bool isLineInterSeg(const XY&, const XY&, const XY&, const XY&);
bool isLineInterSeg(const XY&, const XY&, const XY&, const XY&, bool);
bool isSegInter(const XY&, const XY&, const XY&, const XY&);
bool isSegInter(const XY&, const XY&, const XY&, const XY&, bool);
Real triArea(Real, Real, Real);

//A 2-dimensional point or vector.
struct XY {
    Real x;
    Real y;

    XY(Real _x = 0.0, Real _y = 0.0) {
        x = _x;
        y = _y;
    }

    XY operator - (const XY& other) const {
        return XY(x - other.x, y - other.y);
    }

    XY operator + (const XY& other) const {
        return XY(x + other.x, y + other.y);
    }

    XY operator * (Real d) const {
        return XY(x * d, y * d);
    }

    XY operator / (Real d) const {
        return XY(x / d, y / d);
    }

    const bool operator == (const XY& other) const {
        return x == other.x && y == other.y;
    }

    //The distance from this point to line (a, b).
    Real dis2Line(const XY& a, const XY& b) const {
        //Triangle area divided by the base length.
        return fabs(crsProd(a - *this, b - *this)) / (b - a).norm();
    }

    //The shortest distance from this point to segment (a, b).
    Real dis2Seg(const XY& a, const XY& b) const {
        Real result;
        //If it is a obtuse angle...
        if (dotProd(b - a, *this - a) < 0.0) {
            result = (*this - a).norm();
        }
        else if (dotProd(a - b, *this - b) < 0.0) {
            result = (*this - b).norm();
        }
        else {
            result = dis2Line(a, b);
        }
        return result;
    }

    //Whether this point is on the line (a, b).
    bool isOnLine(const XY& a, const XY& b) const {
        return crsProd(a - *this, b - *this) == 0.0;
    }

    //Whether this point is on the segment (a, b).
    bool isOnSeg(const XY& a, const XY& b) const {
        bool isOn = false;
        if (isOnLine(a, b)) {
            Real minX = a.x < b.x? a.x: b.x;
            Real maxX = a.x > b.x? a.x: b.x;
            Real minY = a.y < b.y? a.y: b.y;
            Real maxY = a.y > b.y? a.y: b.y;
            isOn = x >= minX && x <= maxX && y >= minY && y <= maxY;
        }
        return isOn;
    }

    //Square of the length of a vector.
    //Sometimes you just want to compare the lengths of two vectors,
    //so you needn't calculate their square roots.
    Real normSqr() const {
        return x * x + y * y;
    }

    //Length of a vector.
    Real norm() const {
        return sqrt(normSqr());
    }

    //The perpendicular vector of this one.
    XY perp() const {
        return XY(-y, x);
    }

    //Find the symmetric point about line (a, b).
    XY symPoint(const XY& a, const XY& b) {
        XY vecPerp = (b - a).perp();
        XY temp = *this + vecPerp;
        XY inter = interLine(*this, temp, a, b);
        return inter + (inter - *this);
    }
};

//Print a point as "(x, y)" by "cout".
ostream& operator << (ostream& os, const XY& p) {
    os << "(" << p.x << ", " << p.y << ")";
    return os;
}

//Cross product of vector a and b
Real crsProd(const XY& a, const XY& b) {
    return a.x * b.y - b.x * a.y;
}

//Distance between line (a, b) and line (c, d).
//Returns 0.0 if they are not parallel.
Real disLine(const XY& a, const XY& b, const XY& c, const XY& d) {
    Real result = 0.0;
    if (crsProd(b - a, d - c) == 0.0) {
        result = a.dis2Line(c, d);
    }
    return result;
}

//Dot product of vector a and b
Real dotProd(const XY& a, const XY& b) {
    return a.x * b.x + a.y * b.y;
}

//The shortest distance between points in segment (a, b) and segment (c, d).
Real disSeg(const XY& a, const XY& b, const XY& c, const XY& d) {
    Real result = 0.0;
    if (!isSegInter(a, b, c, d)) {
        result = a.dis2Seg(c, d);
        Real dis = b.dis2Seg(c, d);
        result = dis < result? dis: result;
        dis = c.dis2Seg(a, b);
        result = dis < result? dis: result;
        dis = d.dis2Seg(a, b);
        result = dis < result? dis: result;
    }
    return result;
}

//The shortest distance between points in segment (a, b) and line (c, d).
Real dSeg2Line(const XY& a, const XY& b, const XY& c, const XY& d) {
    Real result = 0.0;
    //If they intersect, we need not calculate any more.
    if (!isLineInterSeg(c, d, a, b)) {
        result = a.dis2Line(c, d);
        Real dis = b.dis2Line(c, d);
        result = dis < result? dis: result;
    }
    return result;
}

//Intersection of line (a, b) and line (c, d).
//!!!!!!!!!!Don't input two parallel or overlapped lines!!!!!!!!!!
XY interLine(const XY& a, const XY& b, const XY& c, const XY& d) {
    Real A1 = a.y - b.y;
    Real B1 = b.x - a.x;
    Real C1 = a.x * b.y - b.x * a.y;
    Real A2 = c.y - d . y;
    Real B2 = d.x - c.x;
    Real C2 = c.x * d.y - d.x * c.y;
    if (B1 == 0) {
        return XY(a.x, (A2 * a.x + C2) / -B2);
    }
    else if (B2 == 0) {
        return XY(c.x, (A1 * c.x + C1) / -B1);
    }
    else{
        return XY((B1 * C2 - B2 * C1) / (A1 * B2 - A2 * B1),
                  (C1 * A2 - C2 * A1) / (A1 * B2 - A2 * B1)
                 );
    }
}

//Find the intersection of line (a, b) and circle (center: c, radius: r).
//Stores the intersection to array "output".
//Returns the number of intersections.(There may be 0, 1 or 2 intersections.)
int interLineCirc(const XY& a, const XY& b, const XY& c, Real r,
                  XY* output
                 ) {
    int cnt = 0;
    Real dist = c.dis2Line(a, b);
    if (dist <= r) {
        XY vecAB = (b - a) / (b - a).norm();
        //Vector from center c to line (a,b). The direction doesn't matter.
        XY vecC2L = vecAB.perp();
        XY temp = c + vecC2L;
        //The intersection of line (vecC2L) and line (a,b).
        XY perpInte = interLine(c, temp, a, b);
        if (dist == r) {
            cnt = 1;
            output[0] = perpInte;
        }
        else {
            cnt = 2;
            Real len = sqrt(r * r - dist * dist);
            output[0] = perpInte + vecAB * len;
            output[1] = perpInte - vecAB * len;
        }
    }
    return cnt;
}

//Find the intersections of circle (a, r) and circle (b, R),
//"a" and "b" are centers, "r" and "R" are radii.
//Stores the intersection to array "output".
//Returns the number of intersections.(There may be 0, 1 or 2 intersections.)
int interCircle(const XY& a, Real r, const XY& b, Real R, XY* output) {
    int cnt = 0;
    Real disAB = (b - a).norm();
    if (disAB <= r + R) {
        XY vecAB = (b - a) / disAB;
        //Distance from "a" to the mid-point of two intersecions.
        //Using the cosine theorem: cos = (a^2 + b^2 - c^2) / 2ab.
        Real disA2Mid = (r * r + disAB * disAB - R * R) / (2.0 * disAB);
        XY mid = a + vecAB * disA2Mid;
        Real len = sqrt(r * r - disA2Mid * disA2Mid);
        if (len == 0) {
            cnt = 1;
            output[0] = mid;
        }
        else {
            cnt = 2;
            output[0] = mid + vecAB.perp() * len;
            output[1] = mid - vecAB.perp() * len;
        }
    }
    return cnt;
}

//Whether two lines intersect.
//Parallel or overlapped lines are not intersected.
bool isLineInter(const XY& a, const XY& b, const XY& c, const XY& d) {
    return crsProd(b - a, d - c) != 0.0;
}

bool isLineInterSeg(const XY& a, const XY& b, const XY& c, const XY& d) {
    return isLineInterSeg(a, b, c, d, true);
}

//Whether line (a, b) intersect with segment (c, d). Return false if they
//overlap. The parament "incBound" tells whether it's judged to be intersected
//when the intersection is exactly on point c or d.
bool isLineInterSeg(const XY& a, const XY& b, const XY& c, const XY& d,
                    bool incBound
                   ) {
    Real crs1 = crsProd(c - a, b - a);
    Real crs2 = crsProd(b - a, d - a);
    Real mul = crs1 * crs2;
    return (crs1 != 0.0 || crs2 != 0.0)
           && (mul > 0.0 || incBound && mul == 0.0);
}

bool isSegInter(const XY& a, const XY& b, const XY& c, const XY& d) {
    return isSegInter(a, b, c, d, true);
}

//Whether segment (a, b) intersects with segment (c, d).
//The parament "incBound" tells whether it's judged to be intersected when the
//intersection is exactly on point a, b, c or d.
bool isSegInter(const XY& a, const XY& b, const XY& c, const XY& d,
                bool incBound
               ) {
    return isLineInterSeg(a, b, c, d, incBound)
           && isLineInterSeg(c, d, a, b, incBound);
}

//Use Heron's formula to get the area of a triangle, with it's three edges'
//lengths given.
Real triArea(Real a, Real b, Real c) {
    Real s = (a + b + c) / 2.0;
    return sqrt(s * (s - a) * (s - b) * (s - c));
}

const int MAX_POINT = 100;
const Real MIN_X = -1000.0;

//A polygon whose points must be in counter clockwise order.
class Polygon {
private:
    XY m_point[MAX_POINT];
    int m_pntCnt;

    //A structure helping the polar angle sorting.
    struct Vertex {
        XY point;
        Real polar;
        Real len;
        int indx;

        const bool operator < (const Vertex& other) const {
            return polar > other.polar
                   || polar == other.polar && len < other.len;
        }
    };

    struct TempPoint {//For the function getConvexHullCo().
        Real len;
        int num;

        TempPoint(Real l, int n) {
            len = l;
            num = n;
        }

        bool operator < (const TempPoint& t) const {
            return len < t.len;
        }
    };

    //Find the lowest and leftest point. Return its index in the array.
    int findLowLeft(const XY* pnt, int cnt) {
        int result = 0;
        for (int i = 1; i < cnt; i++) {
            if (pnt[i].y < pnt[result].y
                || pnt[i].y == pnt[result].y && pnt[i].x < pnt[result].x
               ) {
                result = i;
            }
        }
        return result;
    }

public:
    Polygon() {
        clear();
    }

    void add(const XY& p) {
        m_point[m_pntCnt] = p;
        m_pntCnt++;
    }

    void add(const XY* p, int cnt) {
        for (int i = 0; i < cnt; i++) {
            add(p[i]);
        }
    }
    
    Real area() const {
        Real result = 0.0;
        for (int i = 1; i < m_pntCnt - 1; i++) {
            result += crsProd(m_point[i] - m_point[0],
                              m_point[i + 1] - m_point[0]
                             );
        }
        result /= 2.0;
        return result;
    }
    
    //Find convex hull, sorted in counter clockwise order.
    //If there are colinear points on one edge,
    //only the two end points will remain.
    void getConvexHull(const XY* points, int pntCnt) {
        clear();
        bool used[MAX_POINT];
        memset(used, 0, sizeof(used));
        int lowLeft = findLowLeft(points, pntCnt);
        int next = lowLeft;
        do {
            int curr = next;
            add(points[curr]);
            used[curr] = true;
            next = lowLeft;
            for (int i = 0; i < pntCnt; i++) {
                if (!used[i]) {
                    Real crossP  = crsProd(points[i] - points[curr],
                                             points[next] - points[curr]
                                            );
                    if (crossP > 0
                        //Change the precision if you want
                        || fabs(crossP - 0.0) < 0.0000001
                           && (points[i] - points[curr]).normSqr()
                              > (points[next] - points[curr]).normSqr()
                       ) {
                        next = i;
                    }
                }
            }
        } while(next != lowLeft);
    }
    
    //Find convex hull, sorted in counter clockwise order.
    //All colinear points on one edge will remain.
    void getConvexHullCo(const XY* points, int pntCnt) {
        clear();
        bool used[MAX_POINT];
        memset(used, 0, sizeof(used));
        vector<TempPoint> tempP;
        int lowLeft = findLowLeft(points, pntCnt);
        int next = lowLeft;
        do {
            add(points[next]);
            used[next] = true;
            int curr = next;
            next = lowLeft;
            tempP = vector<TempPoint>(1, TempPoint(0.0L, next));
            for (int i = 0; i < pntCnt; i++) {
                if (!used[i]) {
                    Real crossP = crsProd(points[i] - points[curr],
                                          points[next] - points[curr]
                                         );
                    Real len = (points[i] - points[curr]).normSqr();
                    if (crossP > 0L) {
                        next = i;
                        tempP = vector<TempPoint>(1, TempPoint(len, i));
                    }
                    else if (//Change the precision if you want
                             fabs(crossP - 0.0L) < 0.0000001L
                            ) {
                        if (tempP[0].num == lowLeft) {
                            tempP.clear();
                        }
                        next = i;
                        tempP.push_back(TempPoint(len, i));
                    }
                }
            }
            sort(tempP.begin(), tempP.end());
            for (int i = 0; i < tempP.size() - 1; i++) {
                add(points[tempP[i].num]);
                used[tempP[i].num] = true;
            }
            next = tempP[tempP.size() - 1].num;
        } while(next != lowLeft);
    }

    void clear() {
        m_pntCnt = 0;
    }
    
    //Whether a line crosses this polygon. "A line crossing a polygon" means
    //there is at least one point on the line that falls "inside" the polygon.
    //The parameter "incBound" tells whether the "inside" mentioned above
    //includes the situation that a point is right on one edge of the polygon.
    bool isLineCross (const XY& a, const XY& b, bool incBound) {
        bool cross = false;
        XY inter[m_pntCnt];
        int intCnt = 0;
        for (int i = 0; i < m_pntCnt; i++) {
            XY p1 = m_point[i];
            XY p2 = m_point[(i + 1) % m_pntCnt];
            if (isLineInterSeg(a, b, p1, p2)) {
                if (incBound) {
                    cross = true;
                    break;
                }
                inter[intCnt] = interLine(a, b, p1, p2);
                intCnt++;
            }
        }
        if (!incBound) {
            for (int i = 0; i < intCnt; i++) {
                for (int j = i + 1; j < intCnt; j++) {
                    XY mid = (inter[i] + inter[j]) / 2.0;
                    if (isPointIn(mid, false)) {
                        cross = true;
                        break;
                    }
                }
            }
        }
        return cross;
    }

    bool isPointIn(const XY& point) const {
        return isPointIn(point, true);
    }

    //Whether a point is inside this polygon. The parameter "incBound" tells
    //whether the point is judged to be inside when it falls on one of the
    //edges of the polygon.
    bool isPointIn(const XY& point, bool incBound) const {
        XY leftFaraway(MIN_X - 10.0, point.y);
        int crossCnt = 0;
        for (int i = 0; i < m_pntCnt; i++) {
            XY p1 = m_point[i];
            XY p2 = m_point[(i + 1) % m_pntCnt];
            if (point.isOnSeg(p1, p2)) {
                crossCnt = incBound? 1: 2;
                break;
            }
            if (p1.y != p2.y) {
                if (p1.isOnSeg(leftFaraway, point)) {
                    if (p1.y > p2.y) {
                        crossCnt++;
                    }
                }
                else if (p2.isOnSeg(leftFaraway, point)) {
                    if (p2.y > p1.y) {
                        crossCnt++;
                    }
                }
                else if (isSegInter(p1, p2, leftFaraway, point)) {
                    crossCnt++;
                }
            }
        }
        return crossCnt % 2 != 0;
    }

    //This function is like the "isPointIn()" but only for a convex polygon
    //and runs faster than the "isPointIn()". For a not convex polygon,
    //the result of this function is unknown!
    bool isPointInConvex(const XY& p, bool incBound) const {
        bool in = false;
        if (incBound) {
            for (int i = 0; i < m_pntCnt; i++) {
                if (p.isOnSeg(m_point[i], m_point[(i + 1) % m_pntCnt])) {
                    in = true;
                    break;
                }
            }
        }
        if (!in) {
            in = true;
            XY vec[m_pntCnt];
            for (int i = 0; i < m_pntCnt; i++) {
                vec[i] = m_point[i] - p;
            }
            Real crs = crsProd(vec[0], vec[1]);
            bool dir = (crs < 0.0);
            in = (crs != 0.0);
            for (int i = 1; i != 0 && in; i = (i + 1) % m_pntCnt) {
                Real crs = crsProd(vec[i], vec[(i + 1) % m_pntCnt]);
                in = (crs != 0.0 && (crs < 0.0) == dir);
            }
        }
        return in;
    }
    
    //Whether a segment crosses this polygon. "A segment crossing a polygon"
    //means there is at least one point on the segment that falls "inside" the
    //polygon. The parameter "incBound" tells whether the "inside" mentioned
    //above includes the situation that a point is right on one edge of the
    //polygon.
    bool isSegCross (const XY& a, const XY& b, bool incBound) {
        bool cross = isPointIn(a, incBound) || isPointIn(b, incBound);
        if (!cross) {
            XY inter[m_pntCnt];
            int intCnt = 0;
            for (int i = 0; i < m_pntCnt; i++) {
                XY p1 = m_point[i];
                XY p2 = m_point[(i + 1) % m_pntCnt];
                if (isSegInter(a, b, p1, p2)) {
                    if (incBound) {
                        cross = true;
                        break;
                    }
                    inter[intCnt] = interLine(a, b, p1, p2);
                    intCnt++;
                }
            }
            if (!incBound) {
                for (int i = 0; i < intCnt; i++) {
                    for (int j = i + 1; j < intCnt; j++) {
                        XY mid = (inter[i] + inter[j]) / 2.0;
                        if (isPointIn(mid, false)) {
                            cross = true;
                            break;
                        }
                    }
                }
            }
        }
        return cross;
    }

    //This function is like the "isSegCross()" but only for a convex polygon
    //and runs faster than the "isSegCross()". For a not convex polygon,
    //the result of invoking this function is unknown!
    bool isSegCrossConvex(const XY& a, const XY& b, bool incBound) {
        bool cross = isPointInConvex(a, incBound)
                     || isPointInConvex(b, incBound);
        if (!cross) {
            XY inter[m_pntCnt];
            int intCnt = 0;
            for (int i = 0; i < m_pntCnt; i++) {
                XY p1 = m_point[i];
                XY p2 = m_point[(i + 1) % m_pntCnt];
                if (isSegInter(a, b, p1, p2)) {
                    if (incBound) {
                        cross = true;
                        break;
                    }
                    inter[intCnt] = interLine(a, b, p1, p2);
                    intCnt++;
                }
            }
            if (!incBound) {
                if (intCnt >= 3) {
                    cross = true;
                }
                else if (intCnt <= 1) {
                    cross = false;
                }
                else {//intCnt == 2
                    cross = isPointInConvex((inter[0] + inter[1]) / 2.0, false);
                }
            }
        }
        return cross;
    }

    int pointCnt() const {
        return m_pntCnt;
    }
    
    XY point(const int i) const {
        return m_point[i];
    }

    //Sort all the vertices by their polar angles in counter-clockwise order.
    //After sorting, the lowest and leftest vertex will be at index 0;
    void polarSort() {
        int lowLeft = findLowLeft(m_point, m_pntCnt);
        XY orig = m_point[lowLeft];
        XY right(1.0, 0.0);
        Vertex vertex[m_pntCnt];
        int sortCnt = 0;
        for (int i = 0; i < m_pntCnt; i++) {
            if (i != lowLeft) {
                vertex[sortCnt].len = (m_point[i] - orig).norm();
                vertex[sortCnt].polar = dotProd(right, m_point[i] - orig)
                                        / vertex[sortCnt].len;
                vertex[sortCnt].indx = i;
                vertex[sortCnt].point = m_point[i];
                sortCnt++;
            }
        }
        sort(vertex, vertex + sortCnt);

        m_point[0] = orig;
        for (int i = 0; i < sortCnt; i++) {
            m_point[i + 1] = vertex[i].point;
        }
    }
    
    void print() const {
        for (int i = 0; i < m_pntCnt; i++) {
            cout << "(" << m_point[i].x << ", " << m_point[i].y << ")";
            if (i < m_pntCnt - 1) {
                cout << ", ";
            }
            else {
                cout << endl;
            }
        }
    }
};

//Test suites.
//Choose to type the parts you want to use, which are separated by comments.

int main() {
    //Initialization part, which you must type.
    //Index:      0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
    Real x[15] = {2, 1, 2, 3, 3, 4, 2, 5, 0, 2, 5, 6, 3, 5, 6};
    Real y[15] = {9, 8, 8, 7, 6, 5, 4, 3, 2, 2, 2, 1, 0, 0, 0};
    XY p[15];
    for (int i = 0; i < 15; i++) {
        p[i] = XY(x[i], y[i]);
    }
    XY inter[2];
    int cnt;
    Polygon hull;

    //Whether a point is on a segment.
    cout << p[5].isOnSeg(p[3], p[11]) << " ";
    cout << p[0].isOnSeg(p[0], p[1]) << " ";
    cout << p[0].isOnSeg(p[0], p[0]) << " ";
    cout << p[0].isOnSeg(p[1], p[2]) << endl;//correct: 1 1 1 0

    //Intersection of lines.
    cout << interLine(p[0],p[2], p[1], p[2]) << " ";
    cout << interLine(p[5],p[9], p[6], p[7]) << endl;
    //correct: (2, 8) (3.09091, 3.63636)
    
    //Distance from point to line.
    cout << p[0].dis2Line(p[3], p[5]) << " ";
    cout << p[6].dis2Line(p[8], p[9]) << endl;//correct: 0 2

    //Intersections of line and circle.
    cnt = interLineCirc(p[0], p[1], p[9], 1, inter);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) {
        cout << inter[i] << " ";
    }
    cnt = interLineCirc(p[2], p[9], p[5], 2, inter);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) {
        cout << inter[i] << " ";
    }
    cnt = interLineCirc(p[6], p[9], p[7], 4, inter);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) {
        cout << inter[i] << " ";
    }
    cout << endl;//correct: 0 1 (2, 5) 2 (2, 0.354249) (2, 5.64575)

    //Intersections of two circles.
    cnt = interCircle(p[0], 1, p[9], 1, inter);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) {
        cout << inter[i] << " ";
    }
    cnt = interCircle(p[0], 3, p[6], 2, inter);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) {
        cout << inter[i] << " ";
    }
    cnt = interCircle(p[0], 1, p[2], 1, inter);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) {
        cout << inter[i] << " ";
    }
    cout << endl;//correct: 0 1 (2, 6) 2 (2.86603, 8.5) (1.13397, 8.5)

    //Whether two segments intersect.
    cout << isSegInter(p[1], p[2], p[3], p[4]) << " ";
    cout << isSegInter(p[5], p[9], p[6], p[7]) << " ";
    cout << isSegInter(p[0], p[1], p[0], p[2]) << " ";
    cout << isSegInter(p[5], p[9], p[3], p[7]) << " ";
    cout << isSegInter(p[0], p[1], p[0], p[2], false) << " ";
    cout << isSegInter(p[5], p[9], p[3], p[7], false) << " ";
    cout << isSegInter(p[0], p[5], p[3], p[7]) << " ";
    cout << isSegInter(p[0], p[5], p[3], p[7], false) << endl;
    //correct: 0 1 1 1 0 0 0 0

    //Shortest distance of two segments.
    cout << disSeg(p[0], p[1], p[1], p[2]) << " ";
    cout << disSeg(p[3], p[4], p[5], p[7]) << " ";
    cout << disSeg(p[6], p[9], p[5], p[7]) << endl;
    //correct: 0 1.41421 2.23607

    //Shorest distance of a segment and a line.
    cout << dSeg2Line(p[0], p[1], p[1], p[2]) << " ";
    cout << dSeg2Line(p[6], p[9], p[5], p[7]) << endl;//correct: 0 2.23607

    //Distance of two lines.
    cout << disLine(p[0], p[1], p[1], p[2]) << " ";
    cout << disLine(p[0], p[3], p[2], p[4]) << " ";
    cout << disLine(p[0], p[3], p[5], p[7]) << endl;//corrent: 0 0.447214 0

    //Test convex hull. Choose the one you want from the following two.
    hull.getConvexHullCo(p, 15);
    hull.print();
    //Corrent: (3, 0), (5, 0), (6, 0), (6, 1), (5, 3), (4, 5), (3, 7), (2, 9), (1, 8), (0, 2)
    hull.getConvexHull(p, 15);
    hull.print();//Correct: (3, 0), (6, 0), (6, 1), (2, 9), (1, 8), (0, 2)

    //Public codes for the following 3 parts of test suites.
    int pIndx[8] = {9, 7, 0, 6, 8, 12, 14, 11};
    hull.clear();
    for (int i = 0; i < 8; i++) {
        hull.add(p[pIndx[i]]);
    }

    //Area of a polygon.
    cout << hull.area() << endl;//correct: 19.5

    //Whether a point is inside a polygon.
    int testIn[] = {0, 10, 4, 5, 13};
    int testBound[] = {0, 5, 13};
    for (int i = 0; i < 5; i ++) {
        cout << hull.isPointIn(p[testIn[i]]) << " ";
    }
    for (int i = 0; i < 3; i ++) {
        cout << hull.isPointIn(p[testBound[i]], false) << " ";
    }
    cout << endl;//correct: 1 0 1 1 1 0 0 0

    //Polar angle sort.
    hull.add(p[13]);
    hull.polarSort();
    hull.print();
    //(3, 0), (5, 0), (6, 0), (6, 1), (5, 3), (2, 9), (2, 4), (2, 2), (0, 2)

    //Public codes for the following 2 parts of test suites.
    int tIndx[5] = {8, 9, 7, 0, 6};
    hull.clear();
    for (int i = 0; i < 5; i++) {
        hull.add(p[tIndx[i]]);
    }
    int lineA[9] = {1, 1, 6, 8, 10, 2, 4, 4, 0};
    int lineB[9] = {2, 0, 7, 9, 12, 3, 5, 11, 9};

    //Whether a line cross a polygon.
    for (int i = 0; i < 9; i++) {
        cout << hull.isLineCross(p[lineA[i]], p[lineB[i]], true) << " ";
        cout << hull.isLineCross(p[lineA[i]], p[lineB[i]], false) << " ";
    }
    cout << endl;//correct: 1 1 1 0 1 1 1 0 0 0 1 1 1 1 1 1 1 1

    //Whether a segment cross a polygon.
    for (int i = 0; i < 9; i++) {
        cout << hull.isSegCross(p[lineA[i]], p[lineB[i]], true) << " ";
        cout << hull.isSegCross(p[lineA[i]], p[lineB[i]], false) << " ";
    }
    cout << endl;//correct: 1 0 1 0 1 1 1 0 0 0 1 1 1 1 1 1 1 1

    //Public code for the following 2 test suites. (A convex polygon)
    int conIndx[5] = {0, 9, 12, 10, 7};
    hull.clear();
    for (int i = 0; i < 5; i++) {
        hull.add(p[conIndx[i]]);
    }

    //Whether a point is inside a convex polygon.
    int inCon[4] = {8, 4, 5, 0};
    for (int i = 0; i < 4; i++) {
        cout << hull.isPointInConvex(p[inCon[i]], true) << " ";
        cout << hull.isPointInConvex(p[inCon[i]], false) << " ";
    }
    cout << endl;//correct: 0 0 1 1 1 0 1 0

    //Whether a segment crosses a convex polygon.
    int conSegA[9] = {0, 6, 13, 10, 13, 0, 1, 1, 13};
    int conSegB[9] = {10, 10, 12, 7, 1, 4, 4, 2, 14};
    for (int i = 0; i < 9; i++) {
        cout<<hull.isSegCrossConvex(p[conSegA[i]], p[conSegB[i]], true)<<" ";
        cout<<hull.isSegCrossConvex(p[conSegA[i]], p[conSegB[i]], false)<<" ";
    }
    cout << endl;//correct: 1 1 1 1 1 0 1 0 1 1 1 1 1 1 1 0 0 0

    //Triangle area.
    cout << triArea(1, 2, 3) << " " << triArea(3, 4, 5) << " ";
    cout << triArea(2, 3, 2) << endl;//correct: 0 6 1.98431

    //Symmetric point about a line.
    cout << p[6].symPoint(p[7], p[9]) << " ";
    cout << p[1].symPoint(p[6], p[0]) << " ";
    cout << p[3].symPoint(p[0], p[5]) << endl;
    //correct: (3.2, 0.4) (3, 8) (3, 7)
    return 0;
}
