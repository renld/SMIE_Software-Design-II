#include<stdio.h>
void sift(int e[],int n,int s){//�󶥶ѣ���С���� 
	int t,k,j;
	t=e[s];
	k=s;
	j=2*k+1;
	while(j<n){
		if(j<n-1 && e[j]<e[j+1])
		j++;
		if(t<e[j]){
			e[k]=e[j];
			k=j;
			j=2*k+1;
		}
		else
			break;
	}
	e[k]=t;
}

void heapsort(int e[],int n){
	int i,k,t;
	for(i=n/2-1;i>=0;i--)
		sift(e,n,i);
	for(k=n-1;k>=1;k--){
		t=e[0];
		e[0]=e[k];
		e[k]=t;
		sift(e,k,0);
	}
}
