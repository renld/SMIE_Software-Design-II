class TreeArray{
public:
	int array[MAX],len;//�����1��ʼ
	void init(int size){
		len=size;
		memset(array,0,sizeof(array));
	}
	int lowBit(int x){
		return x&(x^(x-1));
	}
	void insert(int index,int data){
		while(index<=len){
			array[index]=array[index]+data;
			index+=lowBit(index);
		}
	}
	int getSum(int k){
		int t;
		t=0;
		while(k>0){
			t+=array[k];
			k-=lowBit(k);
		}
		return t;
	}
	void print(){
		int i;
		for(i=1;i<=len;i++)
		printf("%d ",array[i]);
		printf("\n");
	}
};
