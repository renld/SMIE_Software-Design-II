#include <iostream>
using namespace std;

float hls(float **a,int n){
	int i,j,k;
	float result=1;
	for(i=0;i<n-1;i++)
	for(j=i+1;j<n;j++)
	for(k=n;k>=0;k--)
		a[j][k]=a[j][k]-a[i][k]*a[j][i]/a[i][i]; 
	for(i=0;i<n;i++)
		result=result*a[i][i];
	return result;
}

void main(){
	float **a,result;
	int n,i;
	cout<<"��������ʽ�Ľ�����";
	cin>>n;
	a=new float *[n];
	for(i=0;i<n;i++)
	a[i]=new float[n];
	cout<<"�����ʼֵ��"<<endl;
	for(i=0;i<n;i++)
	for(int j=0;j<n;j++)
		cin>>a[i][j];
	result=hls(a,n);
	cout<<result<<endl;
}


