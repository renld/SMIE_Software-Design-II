#include <iostream>
#define MaxN 15
#define MaxM 26
#define MaxNum 500001

using namespace std;

struct Node{
 bool end;
 int id;
 Node *p[MaxM];
}*root;

int f[MaxNum];
int degree[MaxNum],cnt;


//建立Trie Tree.
int GetNum(char *s){
	Node * r = root;
	Node * tmp;
	int i,j;

	for(i=0; i<strlen(s); i++){
		if(r->p[s[i]-'a'] == NULL){
			tmp = new Node; tmp->end = 0; tmp->id = -1;
			for(j=0; j<MaxM; j++) 
				tmp->p[j] = NULL;
			r->p[s[i]-'a'] = tmp;
		}
		r = r->p[s[i]-'a'];
	}

	if(r->end == 1) 
		return r->id;

	r->end = 1; r->id = cnt++;

	return r->id;
}


//并查集
int Find(int x){
	if(x != f[x])
		return f[x] = Find(f[x]);
	return f[x];
}

void Union(int x,int y){
	f[Find(x)] = f[Find(y)];
}

int main(){
	char str1[MaxN],str2[MaxN];
	int i,x,y,m = 0;

	root = new Node; root->end = 0; root->id = 0;
	for(i=0; i<MaxM; i++) root->p[i] = NULL;

	for(i=1; i<MaxNum; i++){ degree[i] = 0; f[i] = i;}

	cnt = 1;
	while(scanf("%s %s",&str1,&str2) != EOF){
		if(strcmp(str1,"0") == 0) 
			break;
		x = GetNum(str1); y = GetNum(str2);
		degree[x]++; degree[y]++;
		Union(x,y);
	}

	for(i=1; i<cnt; i++){
		if(degree[i] % 2 != 0) m++;
	}


	//判断图是否连通
	x = Find(1);
	for(i=2; i<cnt; i++) if(x != Find(i)){
		m = -1 ;break;
	}

	if(m == 2 || m == 0) 
		printf("Possible\n");
	else 
		printf("Impossible\n");

	return 0;
}


