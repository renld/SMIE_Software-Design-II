#include <iostream>
#include <queue>
using namespace std;
class node{
public:
	double f;
	double t;
	node(int x,int y){
		f=(double)x;
		t=0;
	}
	friend bool operator< (const node &a, const node &b){
		return a.f > b.f;	
	}
};


int main(){
	priority_queue<node,vector<node>,less<node> > q;

	int n,d;
	int x,y;
	while(cin>>n>>d){
		if(n==0) break;
		for(int i=0;i<n;i++){
			cin>>x>>y;
			q.push(node(x,y));
		}
		cout<<endl;
		while(!q.empty()){
			cout<<q.top().f<<endl;
			q.pop();
		}
	}
	return 0;
}

//从小到大
