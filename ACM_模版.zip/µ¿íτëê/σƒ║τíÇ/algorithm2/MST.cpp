be careful that

if a-b is null set mstmap[a][b]=max+1;
and mstmap[a][a]=0;

int MST(){
	int mincost=0;
	int i,j,k;
	int closet[102];
	int lowcost[102];
	
	for(i=0;i<cnt;i++){
	   lowcost[i]=MSTMap[0][i];
	   closet[i]=0;
	}
	for(i=0;i<cnt-1;i++){
		int min=MAX;
		for(j=0;j<cnt;j++)
			if(lowcost[j]!=0 && lowcost[j]<min){
				min=lowcost[j];
				k=j;
			}
		mincost+=MSTMap[closet[k]][k];
		//cout<<"("<<closet[k]<<","<<k<<")";
		lowcost[k]=0;
		for(j=0;j<cnt;j++)
			if(MSTMap[k][j]<lowcost[j]){
				lowcost[j]=MSTMap[k][j];
				closet[j]=k;
			}
	}
	
	return mincost;
}
