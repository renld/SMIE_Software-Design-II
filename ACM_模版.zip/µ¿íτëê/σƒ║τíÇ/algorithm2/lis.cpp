#include <iostream>

using namespace std;

//Longest increasing subsequence. (time = n * lgn)
void findLIS(const int* const seq, const int size,
             int* const output, int& len) {
    //tail[i] is the index of the lowest tail out of all LISs of length i.
    int tail[size + 1];
    //pre[i] is the index of previous element seq[i] in LIS.
    int pre[size];
    
    len = size > 0? 1: 0;//Length of LIS.
    tail[1] = 0;
    
    for (int i = 1; i < size; i++) {
        if (seq[i] <= seq[tail[1]]) {
            tail[1] = i;
        }
        else {
            //Find the last tail lower than seq[i].
            int low = 1;
            int high = len;
            while (low < high) {
                int mid = (low + high + 1) / 2;
                if (seq[tail[mid]] < seq[i]) {
                    low = mid;
                }
                else {
                    high = mid - 1;
                }
            }
            tail[low + 1] = i;
            pre[i] = tail[low];
            if (low == len) {
                len++;
            }
        }
    }
    int p = tail[len];
    for (int i = len - 1; i >= 0; i--) {
        output[i] = seq[p];
        p = pre[p];
    }
}

int main() {
    int a[] = {1, 7, 14, 0, 9, 4, 18, 18, 2, 4,
               5, 5, 1, 7, 1, 11, 15, 2, 7, 16};
    int b[20];
    int len;
    findLIS(a, 20, b, len);
    cout << len << ": ";
    for (int i = 0; i < len; i++) {
        cout << b[i] << " ";
    }
    cout << endl;
    //Right output is "8: 0 2 4 5 7 11 15 16".
    return 0;
}
