#include <iostream>
#include <cstring>
#include <list>
#include <climits>

using namespace std;

const int ERROR=2000000000;

class Cal{
public:
	int getAns(char str[]){
		
		int relation[7][7]={
		//	 + - * / ( ) #
			{3,3,2,2,2,3,3},//+
			{3,3,2,2,2,3,3},//-
			{3,3,3,3,2,3,3},//*
			{3,3,3,3,2,3,3},///
			{2,2,2,2,2,1,0},//(
			{3,3,3,3,0,3,3},//)
			{2,2,2,2,2,0,1} //#
		};// 3:> 2:< 1:=
		int len=strlen(str);
		str[len++]='#';
		list<int>  OPND;
		list<char> OPTR;
		OPTR.push_front('#');
		OPND.push_front(0);
		int i=0;
		while(str[i]!='#'||OPTR.front()!='#'){
			if(type(str[i])==2){
				int NUM;
				sscanf(str+i,"%d",&NUM);
				OPND.push_front(NUM);
				while(type(str[i])==2) i++;
			}
			else if(type(str[i])==1){
				switch(relation[turnInt(OPTR.front())][turnInt(str[i])]){
					case 0:
						return ERROR;
					case 2://<
						OPTR.push_front(str[i]);
						i++;
						break;
					case 1://=
						OPTR.pop_front();
						i++;
						break;
					case 3://>
						/*if(OPTR.front()=='-'){
							OPTR.pop_front();
							int a=OPND.front();			OPND.pop_front();
							a=neg(a);
							OPND.push_front(a);
						}
						else{*/
							char theta=OPTR.front();	OPTR.pop_front();
							int b=OPND.front();			OPND.pop_front();
							int a=OPND.front();			OPND.pop_front();
							OPND.push_front(Operate(a,theta,b));
						//}
						break;
				}
			}
			else i++;
		}
		int ans=OPND.front();
		return ans;
	}
	
	int Operate(int A,char theta,int B){
		switch(theta){
			case  '+':return A+B;
			case  '-':return A-B;
			case  '*':return A*B;
			case  '/':return A/B;
		}
		return ERROR;
	}
	
	int turnInt(char c){
		switch (c){
			case '+':	return 0;
			case '-':	return 1;
			case '*':	return 2;
			case '/':	return 3;
			case '(':	return 4;
			case ')':	return 5;
			case '#':	return 6;
		}
	}
	 
	int type(char s){
		if(s>='0'&&s<='9') return 2;
		else if(s=='+'||s=='-'||s=='*'||s=='/'||s=='('||s==')'||s=='#')	return 1;
		else return 0;
	}
};

int main(){
	Cal cal;
	char str[200];
	while(cin.getline(str,200)){
		cout<<cal.getAns(str)<<endl;
	}
	return 0;
}
