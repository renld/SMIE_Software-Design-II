    boolean next_permutation() {
        int i = first;
        ++i;
        if (i == last) {
            return false;
        }
        i = last;
        --i;

        for (;;) {
            int ii = i--;
            if (list[i] < list[ii]) {
                int j = last;
                while (!(list[i] < list[--j])) {
                }
                swap(i, j);
                reverse(ii, last);
                return true;
            }
            if (i == first) {
                reverse(first, last);
                return false;
            }
        }
    }
