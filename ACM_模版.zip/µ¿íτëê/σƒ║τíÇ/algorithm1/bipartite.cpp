/////////////////////////////////////////////////////////////////
//MAXIMUM BIPARTITE MATCH by HUNGARIAN algorithm and
//MAXIMUM COST PERFECT BIPARTITE MATCH by KM algorithm.
/////////////////////////////////////////////////////////////////
#include <cstring>//memset
#include <algorithm>//max, min
#include <deque>

using namespace std;

typedef short NT;//Type of node number.
typedef int CT;//Type of cost.

const CT CT_MAX = (1 << sizeof(CT) * 8 - 1) - 1;
const CT CT_MIN = -CT_MAX;
const int MAX_LN = 1000;//Maximum number of node on left and right
const int MAX_RN = 1000;//sides.

NT g_adj[MAX_LN][MAX_RN];//I don't put these large arrays
CT g_cost[MAX_LN][MAX_RN];//inside the class.

class Bipartite {
public:
    Bipartite( NT (*adj)[MAX_RN], CT (*cost)[MAX_RN] )
        : m_adj(adj), m_c(cost) {}

    //Don't add more than one edges between the same pair of nodes.
    void addEdge(NT l, NT r, CT c = 0)
        { m_adj[l][ m_adjN[l]++ ] = r;  m_c[l][r] = c; }
    
    void init(NT lN, NT rN) { m_lN = lN;  m_rN = rN;
                              memset(m_adjN, 0, sizeof(m_adjN)); }

    //Before invoking this function, "maxMatch()" must be invoked.
    //This function returns the index of the matching vertex of
    //index l in the left part of the graphic.
    int getL2R(int l) const { return m_l2r[l]; }

    //See "getL2R()", and this function is opposite to it.
    int getR2L(int r) const { return m_r2l[r]; }

    //Return the maximum cost of PERFECT MATCH. DON'T invoke this if
    //there is not perfect match.
    CT km() {
        memset( m_l2r, 0xFF, sizeof(m_l2r) );
        memset( m_r2l, 0xFF, sizeof(m_r2l) );
        memset( m_rB, 0, sizeof(m_rB) );
        for (NT l = 0; l < m_lN; l++)
            { m_lB[l] = CT_MIN;
              for (NT* r = m_adj[l]; r != m_adj[l] + m_adjN[l]; r++)
                  m_lB[l] = max( m_c[l][*r], m_lB[l] ); }
        for (NT l = 0; l < m_lN; l++) {
            for (NT r = 0; r < m_rN; r++)  m_d[r] = CT_MAX;
            while (1) {
                memset( m_lVst, 0, sizeof(m_lVst) );
                memset( m_rVst, 0, sizeof(m_rVst) );
                if ( KMAugment(l) )  break;
                CT d = CT_MAX;
                for (NT r = 0; r < m_rN; r++)
                    if ( !m_rVst[r] )  d = min( d, m_d[r] );
                for (NT l = 0; l < m_lN; l++)
                    if ( m_lVst[l] )  m_lB[l] -= d;
                for (NT r = 0; r < m_rN; r++)
                    if ( m_rVst[r] )  m_rB[r] += d;
                    else  m_d[r] -= d;
            }
        }
        CT c = 0;
        for (NT r = 0; r < m_rN; r++)  if ( -1 != m_r2l[r] )
            { m_l2r[ m_r2l[r] ] = r;  c += m_c[ m_r2l[r] ][r]; }
        return c;
    }

    NT maxMatch() {
        memset( m_l2r, 0xFF, sizeof(m_l2r) );
        memset( m_r2l, 0xFF, sizeof(m_r2l) );
        for (NT l = 0; l < m_lN; l++)  augment(l);
        NT m = 0;
        for (NT l = 0; l < m_lN; l++)  if ( -1 != m_l2r[l] )  m++;
        return m;
    }

private:
    void augment(int start) {
        for (int i = 0; i < m_lN; i++)  m_prL[i] = -1;
        memset( m_rVst, 0, sizeof(m_rVst) );
        deque<int> que(1, start);
        while ( !que.empty() ) {
            int l = que.front();  que.pop_front();
            for (NT* r = m_adj[l]; r != m_adj[l]+m_adjN[l]; r++) {
                if ( !m_rVst[*r] ) {
                    m_rVst[*r] = true;
                    if ( -1 == m_r2l[*r] ) { reverse(l,*r); return; }
                    else { que.push_back( m_r2l[*r] );
                           m_prL[ m_r2l[*r] ] = l; }
                }
                
            }
        }
    }

    void reverse(int l, int r) {
        m_r2l[r] = l;
        while( -1 != m_prL[l] ) {
            int nextR = m_l2r[l];
            m_r2l[nextR] = m_prL[l];  m_l2r[l] = r;
            l = m_prL[l];  r = nextR;
        }
        m_l2r[l] = r;
    }

    bool KMAugment(NT l) {
        m_lVst[l] = true;
        for (NT* r = m_adj[l]; r != m_adj[l] + m_adjN[l]; r++)
            if ( m_c[l][*r] == m_lB[l] + m_rB[*r] ) {
                if ( !m_rVst[*r] ) {
                    m_rVst[*r] = true;
                    if ( -1 == m_r2l[*r] || KMAugment( m_r2l[*r] ) )
                        { m_r2l[*r] = l;  return true; }
                }
            }
            else  m_d[*r] = min( m_d[*r],
                                 m_lB[l] + m_rB[*r] - m_c[l][*r] );
        return false;
    }

    NT (*m_adj)[MAX_RN];
    NT m_adjN[MAX_LN];//Adjacent number of each left node.
    CT (*m_c)[MAX_RN];//Matrix of edges' costs.
    NT m_lN, m_rN;//Number of nodes on left and right sides.
    NT m_l2r[MAX_LN], m_r2l[MAX_RN];//Match
    bool m_lVst[MAX_LN], m_rVst[MAX_RN];//Help the DFS.
    NT m_prL[MAX_LN];
    CT m_lB[MAX_LN], m_rB[MAX_RN], m_d[MAX_RN];//Help KM algorihtm.
};

//Test suite and usage example.
#include <iostream>
void testMaxMatch() {
    Bipartite bip(g_adj, g_cost);
    int l, r, n, a, b;
    while (cin >> l >> r >> n) {
        bip.init(l, r);
        for (int i = 0; i < n; i++)
            { cin >> a >> b;  bip.addEdge(a, b); }
        int m = bip.maxMatch();  cout << m;
        for (int i = 0; i < l; i++)
            cout << " " << i << "-->" << bip.getL2R(i);
        for (int i = 0; i < r; i++)
            cout << " " << bip.getR2L(i) << "<--" << i;
        cout << endl; } }
/*Input: 3 4 7  0 1  0 2  1 1  1 3  2 0  2 1  2 2
Output: 3 0-->1 1-->3 2-->0 2<--0 0<--1 -1<--2 1<--3 */

void testKM() {
    Bipartite bip(g_adj, g_cost);
    int l, r, n, a, b, c;
    while (cin >> l >> r >> n) {
        bip.init(l, r);
        for (int i = 0; i < n; i++)
            { cin >> a >> b >> c;  bip.addEdge(a, b, c); }
        cout << bip.km() << endl; } }
/*Input: 5 5 25  0 0 3  0 1 4  0 2 6  0 3 4  0 4 9  1 0 6  1 1 4
1 2 5  1 3 3  1 4 8  2 0 7  2 1 5  2 2 3  2 3 4  2 4 2  3 0 6
3 1 3  3 2 2  3 3 2  3 4 5  4 0 8  4 1 4  4 2 5  4 3 4  4 4 7
Output: 29 */

int main() //Choose one test suite.
    { testMaxMatch();  /* testKM(); */  return 0; }
