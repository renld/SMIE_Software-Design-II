/////////////////////////////////////////////////////////////////////
//2-dimension Tree Array.
/////////////////////////////////////////////////////////////////////
using namespace std;

const int BOUND = 1000;

//Array for the tree array. Too big to define in the class.
int m_tree[BOUND + 1][BOUND + 1];
int m_range[BOUND + 1];

class TreeArray {
private:
    int m_xBound;
    int m_yBound;

public:
    TreeArray(int xBound = BOUND, int yBound = BOUND) {
        for (int i = 0; i <= BOUND; i++) {
            m_range[i] = (i + 1) & ((i + 1) ^ i);
        }
        init(xBound, yBound);
    }

    //Initialize a tree array of range [0, xBound][0, yBound].
    void init(int xBound, int yBound) {
        m_xBound = xBound;
        m_yBound = yBound;
        for (int i = 0; i <= m_xBound; i++) {
            for (int j = 0; j <= m_yBound; j++) {
                m_tree[i][j] = 0;
            }
        }
    }
    
    //Add value v at point (x, y).
    void add(int x, int y,  int v) {
        if (x >= 0 && y >= 0) {
            while (x <= m_xBound) {
                int i = y;
                while (i <= m_yBound) {
                    m_tree[x][i] += v;
                    i += m_range[i];
                }
                x += m_range[x];
            }
        }
    }

    //Get the value in the area [0, x][0, y].
    int getValue(int x, int y) {
        int v = 0;
        x = x <= m_xBound? x: m_xBound;
        y = y <= m_yBound? y: m_yBound;
        while (x >= 0) {
            int i = y;
            while (i >= 0) {
                v += m_tree[x][i];
                i -= m_range[i];
            }
            x -= m_range[x];
        }
        return v;
    }
};

//Test suite.
#include <iostream>

int main() {
    TreeArray tree(3, 5);
    int add[5][3]
        = {{1, 1, 1}, {1, 4, 5}, {3, 1, 2}, {2, 3, 7}, {3, 2, 4}};
    for (int i = 0; i < 5; i++) tree.add(add[i][0], add[i][1], add[i][2]);
    for (int i = 0; i <= 3; i++) {
        for (int j = 0; j <= 5; j++) {
            cout << tree.getValue(i, j) << " ";
        }
        cout << endl;
    }
    cout << endl;
    //output: 0 0 0 0 0 0 
    //        0 1 1 1 6 6 
    //        0 1 1 8 13 13 
    //        0 3 7 14 19 19
    return 0;
}
