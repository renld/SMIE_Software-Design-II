/////////////////////////////////////////////////////////////////////
//A Graph represented by adjacent list.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset.
#include <set>//help DIJKSTRA.
#include <queue>//queue, priority_queue

using namespace std;

typedef short VT;//Type of vertex number.
typedef int LT;//Type of length.

const int MAX_VER = 1000;
const int MAX_LEN = 99999999;

struct Edge {
    VT t;//target of this edge.
    LT l;//length
    Edge* next;//pointer of the linked list.
    Edge(VT T = 0, LT L = 0, Edge* n = NULL): t(T), l(L), next(n) {}
};

Edge g_eMem[MAX_VER * MAX_VER * 2];
int g_allocN = 0;

Edge* newEdge(VT t = 0, LT l = 0, Edge* n = NULL)
    { g_eMem[g_allocN] = Edge(t, l, n);
      return &g_eMem[g_allocN++]; }

class Graph {
public:
    void addEdge(VT from, VT to, LT len)
        { m_adj[from] = newEdge(to, len, m_adj[from]); }

    //Return whether the shortest path exists.
    bool bellmanFord(VT source) {
        initSingleSrc(source);
        bool refresh = true;
        for (int iter = 0; refresh && iter < m_vN - 1; iter++) {
            refresh = false;
            for (VT i = 0; i < m_vN; i++)
                for (Edge* adj = m_adj[i]; adj; adj = adj->next)
                    refresh = relax(i, adj->t, adj->l) || refresh;
        }
        for (VT i = 0; i < m_vN; i++)
            for (Edge* adj = m_adj[i]; adj; adj = adj->next)
                if ( relax(i, adj->t, adj->l) )  return false;
        return true;
    }

    //Get single source shortest paths with BFS.
    //Fall into INFINITE LOOP when the graph has NEGATIVE CIRCLE!!!
    void bfsShortest(VT source) {
        initSingleSrc(source);
        bool inQue[MAX_VER] = {false};
        queue<VT> que;  que.push(source);  inQue[source] = true;
        while ( !que.empty() ) {
            VT v = que.front();  que.pop();  inQue[v] = false;
            for (Edge* adj = m_adj[v]; adj; adj = adj->next) {
                VT to = adj->t;
                if ( relax(v, to, adj->l) && !inQue[to] )
                    { que.push(to);  inQue[to] = true; }
            }
        }
    }

    //Can NOT handle graphs with NEGATIVE edges!!!
    void dijkstra(VT source) {
        initSingleSrc(source);
        set<Sh> remain;
        for (VT i = 0; i < m_vN; i++)
            remain.insert( Sh(i, m_sh[i]) );
        while (!remain.empty()) {
            set<Sh>::iterator sh = remain.begin();
            VT v = sh->num;
            for (Edge* adj = m_adj[v]; adj; adj = adj->next) {
                VT to = adj->t;
                LT oldSh = m_sh[to];
                if ( relax(v, to, adj->l) )
                    { remain.erase( Sh(to, oldSh) );
                      remain.insert( Sh(to, m_sh[to]) ); }
            }
            remain.erase(sh);
        }
    }

    //Must run "solveSCC();" before invoking this function.
    VT getSCC(VT v) const { return m_scc[v]; }

    //Initialize a graph with n vertices and no edge.
    void init(VT n = MAX_VER) {
        m_vN = n;
        memset( m_adj, 0, sizeof(m_adj) );
        g_allocN = 0;
    }

    //The shortest distance from the source to v
    //(after solving the single source shortest paths).
    LT shortest(VT v) const { return m_sh[v]; }

    void solveSCC() {
        memset( m_popT, 0xFF, sizeof(m_popT) );
        VT t = 0;
        for (VT v = 0; v < m_vN; v++)
            if ( -1 == m_popT[v] )  t = getPopT(v, t) + 1;
        memset( m_rev, 0, sizeof(m_rev) );
        for (VT v = 0; v < m_vN; v++)
            for (Edge* e = m_adj[v]; e; e = e->next)
                m_rev[e->t] = newEdge( v, e->l, m_rev[e->t] );
        VT vi[MAX_VER];
        for (VT v = 0; v < m_vN; v++)  vi[ m_popT[v] ] = v;
        memset( m_scc, 0xFF, sizeof(m_scc) );
        VT scc = 0;
        for (VT i = m_vN - 1; i >= 0; i--)
            if ( -1 == m_scc[ vi[i] ] )  setSCC( vi[i], scc++ );
    }

    //Solve single source shortest paths by A*.
    //If sink is given, solve the single source and sink shortest path.
    void spfa(VT source, VT sink = -1) {
        initSingleSrc(source);
        priority_queue< Sh, vector<Sh>, greater<Sh> > pq;
        pq.push( Sh( source, m_sh[source] ) );
        bool solved[MAX_VER] = {false};
        while ( !pq.empty() ) {
            VT v = pq.top().num;
            pq.pop();
            if ( sink == v )  return;
            if ( solved[v] )  continue;
            solved[v] = true;
            for (Edge* e = m_adj[v]; e; e = e->next) {
                VT to = e->t;
                if ( !solved[to] && relax(v, to, e->l) )
                    pq.push( Sh( to, m_sh[to] ) );
            }
        }
    }

    //TOPOLOGICAL SORT. Put the sorted vertex numbers into "out".
    void topoSort(VT* out) const {
        VT dgr[MAX_VER] = {0};
        for (VT v = 0; v < m_vN; v++)
            for (Edge* e = m_adj[v]; e; e = e->next)  dgr[e->t]++;
        queue<VT> que;
        for (VT v = 0; v < m_vN; v++)  if ( !dgr[v] )  que.push(v);
        VT i = 0;
        while ( !que.empty() ) {
            VT v = que.front();  que.pop();
            out[i++] = v;
            for (Edge* e = m_adj[v]; e; e = e->next)
                if ( !--dgr[e->t] )  que.push(e->t);
        }
    }

private:
    struct Sh {//Help the dijkstra() and spfa().
        VT num;
        LT len;
        
        Sh(VT n = 0, LT l = 0): num(n), len(l) {}
        bool operator < (const Sh& s) const
            { return len < s.len || len == s.len && num < s.num; }

        bool operator > (const Sh& s) const { return len > s.len; }
    };

    VT getPopT(VT v, VT t) {//Help the solveSCC().
        m_popT[v] = 0;//m_popT[v] != -1 means visited.
        for (Edge* e = m_adj[v]; e; e = e->next)
            if ( -1 == m_popT[e->t] )  t = getPopT(e->t, t) + 1;
        return m_popT[v] = t;
    }

    //Initialize the single source shortest path algorithms.
    void initSingleSrc(VT source) {
        for (VT i = 0; i < m_vN; i++) { m_sh[i] = MAX_LEN;
                                        m_pre[i] = -1; }
        m_sh[source] = 0;
    }

    //Help the shortest path algorithms.
    bool relax(VT from, VT to, LT len) {
        if (m_sh[to] > m_sh[from] + len) { m_sh[to] = m_sh[from]+len;
                                           m_pre[to] = from;
                                           return true; }
        return false;
    }

    void setSCC(VT v, VT scc) {//Help the solveSCC().
        m_scc[v] = scc;
        for (Edge* e = m_rev[v]; e; e = e->next)
            if ( -1 == m_scc[e->t] )  setSCC(e->t, scc);
    }

    VT m_vN;//Number of vertices.
    Edge* m_adj[MAX_VER];//Adjacent list.
    //members for SHORTEST PATH:
    LT m_sh[MAX_VER];//Every vertex's shortest distance from the source.
    VT m_pre[MAX_VER];//The previous vertex in the shortest path.
    //members for STRONGLY CONNECTED COMPONENT:
    Edge* m_rev[MAX_VER];//The REVERSE graph.
    VT m_scc[MAX_VER];//Number of each vertex's component.
    VT m_popT[MAX_VER];//The pop time of each vertex in the DFS.
};

//Test suite and usage examples.
#include <iostream>

//test SHORTEST PATH algorithms.
void testSh() {
    Graph g; g.init(6);
    //This is a graph from "INTRODUCTION TO ALGORITHMS", page 596.
    int e[][3] = {{0,1,10}, {0,3,5}, {1,2,1}, {1,3,2}, {3,1,3},
                  {3,2,9}, {3,4,2}, {2,4,4}, {4,2,6}, {4,0,7}};
    for (int i = 0; i < 10; i++)
        g.addEdge(e[i][0], e[i][1], e[i][2]);
    //g.bellmanFord(0);
    //g.dijkstra(0);
    g.bfsShortest(0);
    //g.spfa(0);
    for (VT i = 0; i < 6; i++)  cout << g.shortest(i) << " ";
    cout << endl;//Correct: 0 8 9 5 7 99999999
}

//Test Graph::solveSCC()
void testSCC() {
    Graph g;  g.init(8);
    //This is a graph from "INTRODUCTION TO ALGORITHMS", page 553.
    VT e[][2] = { {0,1}, {1,2}, {2,3}, {3,2}, {4,0}, {1,4}, {2,6},
                  {3,7}, {4,5}, {5,6}, {6,5}, {6,7}, {7,7} };
    for (int i = 0; i < 13; i++)  g.addEdge( e[i][0], e[i][1], 1 );
    g.solveSCC();
    for (VT v = 0; v < 8; v++)  cout << g.getSCC(v) << " ";
    cout << endl;//Output: 0 0 1 1 0 2 2 3
}

//Test Graph::topoSort().
void testTopo() {
    Graph g;  g.init(9);
    //This is a graph from "INTRODUCTION TO ALGORITHMS", page 550.
    VT e[][2] = { {0,1}, {0,7}, {1,2}, {1,7}, {2,5}, {3,2}, {3,4},
                  {4,5}, {6,7} },  out[9];
    for (int i = 0; i < 9; i++)  g.addEdge( e[i][0], e[i][1], 1 );
    g.topoSort(out);
    for(VT i = 0; i < 9; i++)  cout << out[i] << " ";
    cout << endl;//Output: 0 3 6 8 1 4 7 2 5
}

int main() {
    testSh();
    testSCC();
    testTopo();
    return 0;
}
