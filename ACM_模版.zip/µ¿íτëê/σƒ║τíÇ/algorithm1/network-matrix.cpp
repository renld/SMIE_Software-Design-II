/////////////////////////////////////////////////////////////////////
//Network represented by both adjacent lists and matrix. Do BFS by
//adjacent lists, and access flows of each edge by matrix.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset
#include <climits>//INT_MAX
#include <deque>//As a queue in the BFS.

using namespace std;

const int MAX_VERTEX = 500;

struct Edge {
    int to, cap, flow, cost;
    Edge *next, *rev;

    Edge(int t = 0, int ca = 0, int co = 0, Edge* n = NULL)
        :to(t), cap(ca), cost(co), next(n), flow(0) {}
};

Edge g_mem[MAX_VERTEX * MAX_VERTEX];
int g_allocN = 0;

Edge* newEdge(int t, int ca, int co = 0, Edge* n = NULL)
    { g_mem[g_allocN] = Edge(t, ca, co, n);
      return &g_mem[g_allocN++]; }

class Network {
public:
    void addEdge(int from, int to, int cap, int revCap, int cost = 0) {
        if ( !m_matrix[from][to] )
              m_matrix[from][to]
            = m_adj[from] = newEdge( to, cap, cost, m_adj[from] );
        else  m_matrix[from][to]->cap += cap;
        if ( !m_matrix[to][from] )
              m_matrix[to][from]
            = m_adj[to] = newEdge( from, revCap, -cost, m_adj[to] );
        else  m_matrix[to][from]->cap += cap;
        m_adj[from]->rev = m_adj[to];  m_adj[to]->rev = m_adj[from];
    }

    void clear() { g_allocN = 0;
                   memset( m_matrix, 0, sizeof(m_matrix) );
                   memset( m_adj,    0, sizeof(m_adj   ) ); }

    void init(int n, int source, int sink)
        { clear();  m_n = n;  m_src = source;  m_snk = sink; }

    int getFlow(int from, int to) const
        { return m_matrix[from][to]? m_matrix[from][to]->flow: 0; }

    int maxFlow() {
        int result = 0;
        while ( findAugment() ) {
            int flow = m_path[m_snk].cap;
            for (int i = m_snk; i != m_src; i = m_path[i].pre)
                { m_path[i].edge->flow      += flow;
                  m_path[i].edge->rev->flow -= flow; }
            result += flow;
        }
        return result;
    }

    //Before invoking this function, "minCostMaxFlow()" must be invoked.
    int minCost() const { return m_minC; }

    int minCostMaxFlow() {
        int result = 0;
        m_minC = 0;
        while ( findMinCostAugment() ) {
            for (int i = m_snk; i != m_src; i = m_path[i].pre)
                { m_path[i].edge->flow++;
                  m_path[i].edge->rev->flow--; }
            result++;
            m_minC += m_path[m_snk].cost;
        }
        return result;
    }

private:
    struct Path { int pre, cap, cost;//To store a vertex on an
                  Edge* edge; };     //augment path.

    bool findAugment() {
        for (int i = 0; i < m_n; i++)  m_path[i].pre = -1;
        deque<int> que(1, m_src);
        m_path[m_src].pre = m_src;
        m_path[m_src].cap = INT_MAX;
        while ( !que.empty() && -1 == m_path[m_snk].pre ) {
            int from = que.front();  que.pop_front();
            for (Edge* p = m_adj[from]; p; p = p->next) {
                int augment = p->cap - p->flow;
                if (augment > 0 && -1 == m_path[p->to].pre) {
                    m_path[p->to].pre = from;
                    m_path[p->to].edge = p;
                    m_path[p->to].cap = m_path[from].cap < augment
                                        ? m_path[from].cap: augment;
                    que.push_back(p->to);
                }
            }
        }
        return m_path[m_snk].pre != -1;
    }

    //Find an augment path which has 1 unit of flow and minimum cost.
    bool findMinCostAugment() {
        for (int i = 0; i < m_n; i++) { m_path[i].pre = -1;
                                        m_path[i].cost = INT_MAX; }
        m_path[m_src].pre = m_src;  m_path[m_src].cost = 0;
        deque<int> que(1, m_src);
        while ( !que.empty() ) {
            int from = que.front();  que.pop_front();
            for (Edge* e = m_adj[from]; e; e = e->next)
                if (e->cap > e->flow) {
                    int cost = m_path[from].cost + e->cost, to = e->to;
                    if (cost < m_path[to].cost) {
                        m_path[to].cost = cost;
                        m_path[to].pre = from;
                        m_path[to].edge = e;
                        if (to != m_snk)  que.push_back(to);
                    }
                }
        }
        return m_path[m_snk].pre != -1;
    }

    Edge *m_adj[MAX_VERTEX], *m_matrix[MAX_VERTEX][MAX_VERTEX];
    int m_n, m_src, m_snk, m_minC;
    Path m_path[MAX_VERTEX];
};

//Test suites.
#include <iostream>

void testMaxFlow() {
    Network network;
    network.init(10, 0, 9);
    int from[] = {0, 0, 0, 4, 5, 6, 7, 8, 1, 1, 1, 3, 3, 3};
    int to[] = {1, 2, 3, 9, 9, 9, 9, 9, 5, 6, 7, 5, 6, 7};
    for (int i = 0; i < 14; i++) {
        network.addEdge(from[i], to[i], 1, 0);
    }
    cout << network.maxFlow() << " ";
    int a[] = {2, 1, 1, 3, 6, 5};
    int b[] = {6, 5, 6, 7, 9, 9};
    for (int i = 0; i < 6; i++) {
        cout << network.getFlow(a[i], b[i]) << " ";
    }
    cout << endl;//Correct output: "2 0 0 1 1 1 0"
}

void testMinCost() {
    Network network;
    network.init(9, 0, 8);
    int from[] = {0, 0, 0, 1, 1, 2, 1, 2, 3, 4, 5, 6, 7};
    int to[]   = {1, 2, 3, 5, 6, 6, 7, 7, 7, 8, 8, 8, 8};
    int x = INT_MAX;
    int capa[] = {3, 2, 4, x, x, x, x, x, x, 3, 2, 4, x};
    int co[] = {0, 0, 0, 6, 3, 6, 10, 10, 10, 0, 0, 0, 0};
    for (int i = 0; i < 13; i++) {
        network.addEdge(from[i], to[i], capa[i], 0, co[i]);
    }
    int flow = network.minCostMaxFlow();
    int cost = network.minCost();
    cout << flow << " " << cost << " ";
    int a[] = {1, 2, 3, 7, 4, 5};
    int b[] = {7, 6, 7, 8, 8, 6};
    for (int i = 0; i < 6; i++) {
        cout << network.getFlow(a[i], b[i]) << " ";
    }
    cout << endl;//Correct output: "9 64 0 2 4 4 0 0".
}

int main() {
    testMaxFlow();
    testMinCost();
    return 0;
}
