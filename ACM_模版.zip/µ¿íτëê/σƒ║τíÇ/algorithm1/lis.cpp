/////////////////////////////////////////////////////////////////////
//Longest increasing subsequence. O(N * logN)
//Returns the length of LIS and put the lis into the array "out".
/////////////////////////////////////////////////////////////////////
int findLIS(const int* a, int n, int* out) {
    int *tl = new int[n + 1],//tl[i]: index of the lowest tail
                             //among all LISs of length i.
        pr[n],//pr[i]: index of previous element of a[i] in LIS.
        len = n > 0? 1: 0;//Length of LIS.
    tl[1] = 0;
    for (int i = 1; i < n; i++)
        if ( a[i] <= a[ tl[1] ] )  tl[1] = i;
        else { //Find the last tail lower than a[i].
            int low = 1, high = len;
            while (low < high)
                { int m = (low + high + 1) / 2;
                  ( a[ tl[m] ] < a[i] ) ? low = m : high = m-1; }
            tl[low + 1] = i;  pr[i] = tl[low];
            if (low == len)  len++;
        }
    int p = tl[len];
    for (int i = len-1; i >= 0; i--) { out[i] = a[p];  p = pr[p]; }
    delete[] tl;  return len;
}

//Test suite and usage example.
#include <iostream>
using namespace std;
int main() {
    int a[100], b[100], n;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> a[i];
        int m = findLIS(a, n, b);  cout << m << ":";
        for (int i = 0; i < m; i++)  cout << " " << b[i];
        cout << endl;
    } return 0; }
//Input:  20  1 7 14 0 9 4 18 18 2 4 5 5 1 7 1 11 15 2 7 16
//Output: 8:  0 2 4 5 7 11 15 16
