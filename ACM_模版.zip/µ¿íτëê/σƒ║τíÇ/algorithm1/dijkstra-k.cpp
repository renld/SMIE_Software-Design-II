/////////////////////////////////////////////////////////////////////
//Solving K shortest paths by extension of DIJKSTRA algorithm.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset.
#include <queue>//priority_queue.
#include <functional>//greater.
#include <algorithm>//reverse the vector.

using namespace std;

typedef short VT;//Type of vertex number.
typedef int LT;//Type of length.

const VT MAX_VER = 1000;
const LT MAX_LEN = 99999999;

class Graph {
public:
    Graph() { memset(m_adj, 0, sizeof(m_adj)); }
    ~Graph() { init(); }

    void addEdge(VT from, VT to, LT len) {
        m_adj[from] = new Edge(to, len, m_adj[from]);
    }

    //Can NOT handle graphs with NEGATIVE edges!!!
    void dijkstraK(VT source, VT sink, int k) {
        m_sh.clear();  m_pre.clear();  m_map.clear();  m_tail.clear();
        int elm = 0;
        m_map.push_back(source);
        m_sh.push_back(elm);
        m_pre.push_back(-1);
        priority_queue< Sh, vector<Sh>, greater<Sh> > que;
        que.push( Sh( elm, m_sh[elm] ) );
        int cnt[MAX_VER] = {0};
        while ( cnt[sink] < k && !que.empty() ) {
            int e = que.top().elm;  que.pop();
            int v = m_map[e];
            cnt[v]++;
            if (sink == v) { m_tail.push_back(e); }
            if ( cnt[v] <= k ) {
                for (Edge* adj = m_adj[v]; adj; adj = adj->next) {
                    m_map.push_back(adj->to);
                    m_sh.push_back( m_sh[e] + adj->len );
                    m_pre.push_back(e);
                    elm++;
                    que.push( Sh( elm, m_sh[elm] ) );
                }
            }
        }
    }

    //Initialize a graph with "verCnt" vertices and no edge.
    void init(VT verCnt = MAX_VER) {
        m_verCnt = verCnt;
        Edge* p, *temp;
        for (VT i = 0; i < m_verCnt; i++) {
            p = m_adj[i];
            while (p) { temp = p;  p = p->next;  delete temp; }
            m_adj[i] = NULL;
        }
    }

    //The (k + 1)-th shortest distance from source to sink.
    //(after running the "dijkstraK()").
    //return -1 if the k-th shortest path doesn't exist.
    LT kShLen(int k) const {//Acceptable k is in [ 0, m_tial.size() ).
        if ( m_tail.size() <= k ) { return -1; }
        return m_sh[ m_tail[k] ];
    }

    //The (k + 1)-th shortest path from source to sink.
    //(after running the "dijkstraK()").
    //return an empty path if the k-th shortest path doesn't exist.
    //Acceptable k is in [ 0, m_tial.size() ).
    vector<VT> kShPath(int k) const {
        vector<VT> p;
        if ( m_tail.size() > k) {
            int e = m_tail[k];
            while ( -1 != e) { p.push_back( m_map[e] );  e = m_pre[e]; }
        }
        reverse( p.begin(), p.end() );
        return p;
    }

private:
    struct Edge {
        VT to;
        LT len;
        Edge* next;

        Edge(VT t = 0, LT l = 0, Edge* n = NULL) {
            to = t; len = l; next = n;
        }

        bool operator < (const Edge& e) const { return len < e.len; }
    };

    struct Sh {//Help the dijkstraK().
        int elm;//Element number.
        LT len;
        
        Sh(int e = 0, LT l = 0) { elm = e; len = l; }

        bool operator > (const Sh& s) const { return len > s.len; }
    };

    VT m_verCnt;//Number of vertices.
    Edge* m_adj[MAX_VER];//Adjacent list.
    vector<VT> m_sh;//Every element's shortest distance from the source.
    vector<VT> m_pre;//The previous element in the shortest path.
    vector<VT> m_map;//Mapping element number to vertex number.
    vector<VT> m_tail;//The tail element of the k shortest paths.
};

//Test suite.
#include <iostream>

int main() {
    int e [20][3] = { {0, 1, 1}, {0, 2, 2}, {0, 3, 1}, {0, 4, 3},
                      {1, 0, 1}, {1, 2, 1}, {1, 3, 2}, {1, 4, 2},
                      {2, 0, 1}, {2, 1, 2}, {2, 3, 1}, {2, 4, 1},
                      {3, 0, 1}, {3, 1, 1}, {3, 2, 1}, {3, 4, 2},
                      {4, 0, 1}, {4, 1, 1}, {4, 2, 1}, {4, 3, 1} };
    Graph g;  g.init(5);
    for (int i = 0; i < 20; i++)
        { g.addEdge( e[i][1], e[i][0], e[i][2]); }
    g.dijkstraK(4, 0, 16);
    for (int i = 0; i < 16; i++) {
        vector<VT> p = g.kShPath(i);
        for (int j = 0; j < p.size(); j++) { cout << p[j] << " "; }
        cout << ": " << g.kShLen(i) << endl;
    }
    //output:
    //4 0 : 3
    //4 2 0 : 3
    //4 1 0 : 3
    //4 3 0 : 3
    //4 2 3 0 : 3
    //4 2 1 0 : 3
    //4 1 3 0 : 4
    //4 2 1 3 0 : 4
    //4 2 3 2 0 : 5
    //4 2 4 0 : 5
    //4 2 4 2 1 0 : 5
    //4 3 2 0 : 5
    //4 3 2 1 0 : 5
    //4 2 3 2 3 0 : 5
    //4 2 3 2 1 0 : 5
    //4 2 1 0 3 0 : 5
    return 0;
}
