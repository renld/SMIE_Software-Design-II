/////////////////////////////////////////////////////////////////////
//Lexical analysis for arithmetic expression.
/////////////////////////////////////////////////////////////////////
#include <cstdio>//getchar
#include <cctype>//isalpha, isdigit, ispunct

using namespace std;

const int MAX_WORD = 100;
const int VAR_L = 10;

enum WT { WT_END, WT_INT, WT_VAR, WT_PUNC };//Word Type

struct Word {
    WT type;
    int i;//int value when type is WT_INT.
    char c,//char value when type is WT_PUNC.
         str[VAR_L + 1];//the variable name when type is WT_VAR.
};

class WordStream {
public:
    bool hasNext() { return m_i < m_wdN; }

    //Read words from STDIN until the character 'end' or EOF.
    void init(int end = EOF) {
        m_wdN = m_i = 0;
        char c = getchar();
        while (end != c && EOF != c) {
            if ( isdigit(c) ) {
                m_wd[m_wdN].i = 0;
                while ( end != c && EOF != c && isdigit(c) ) {
                    m_wd[m_wdN].i = m_wd[m_wdN].i * 10 + (c - '0');
                    c = getchar();
                }
                m_wd[m_wdN++].type = WT_INT;
            }
            else if ( isalpha(c) ) {
                int i = 0;
                while ( end != c && EOF != c && isalpha(c) ) {
                    m_wd[m_wdN].str[i++] = c;
                    c = getchar();
                }
                m_wd[m_wdN].str[i] = '\0';
                m_wd[m_wdN++].type = WT_VAR;
            }
            else if ( ispunct(c) ) { m_wd[m_wdN].c = c;
                                     m_wd[m_wdN++].type = WT_PUNC;
                                     c = getchar(); }
            else  c = getchar();//pass space.
        }
        m_wd[m_wdN].type = WT_END;  m_wd[m_wdN++].c = '#';
    }

    Word next() { return m_wd[m_i++]; }

private:
    Word m_wd[MAX_WORD];
    int m_wdN, m_i;
};

//Test suites.
int main() {
    WordStream wdStrm;
    wdStrm.init('\n');
    while ( wdStrm.hasNext() ) {
        Word w = wdStrm.next();
        printf("%d ", w.type);
        if (w.type == WT_INT) printf("%d, ", w.i);
        else if (w.type == WT_PUNC || w.type == WT_END)
            printf("%c, ", w.c);
        else printf("%s, ", w.str);
    }
    printf("\n");
    //Input: (a + 987bcd)  *  2Xi - 1
    //Output:
    //3 (, 2 a, 3 +, 1 987, 2 bcd, 3 ), 3 *, 1 2, 2 Xi, 3 -, 1 1, 0 #,
    return 0;
}
