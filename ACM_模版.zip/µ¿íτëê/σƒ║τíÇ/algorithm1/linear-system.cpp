/////////////////////////////////////////////////////////////////////
//Linear Equation System.
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <algorithm>

using namespace std;

template <class Coef>
class LinearSys {
private:
    const static int MATRIX_SIZE = 100;

    Coef m_matrix[MATRIX_SIZE][MATRIX_SIZE];
    int m_wid;
    int m_hei;

    //Swap lines m_matrix[a] and m_matrix[b] from the line element at index
    //"head" (Maybe the elements before "head" are all zeros and needn't be
    //swapped).
    void swapLine(int a, int b, int head) {
        for (int i = head; i < m_wid; i++) {
            swap(m_matrix[a][i], m_matrix[b][i]);
        }
    }

    //Set m_matrix[l][head] to one, and the following elements of the line
    //will also be changed.
    void toOne(int l, int head) {
        for (int i = head + 1; i < m_wid; i++) {
            m_matrix[l][i] = m_matrix[l][i] / m_matrix[l][head];
        }
        m_matrix[l][head] = 1;
    }

    //Clear m_matrix[l][head] to zero based on the line m_matrix[base]. And
    //the following elements of line "l" will also be changed.
    void toZero(int l, int base, int head) {
        for (int i = head + 1; i < m_wid; i++) {
            m_matrix[l][i]
            = m_matrix[l][i]
              - m_matrix[base][i] * m_matrix[l][head] / m_matrix[base][head];
        }
        m_matrix[l][head] = 0;
    }

public:
    void addEq(const Coef* eq) {
        for (int i = 0; i < m_wid; i++) {
            m_matrix[m_hei][i] = eq[i];
        }
        m_hei++;
    }

    //Initialize an system for "unCnt" unknowns.
    void init(int unCnt) {
        m_wid = unCnt + 1;
        m_hei = 0;
    }

    //Solve the equation system, and return the rank of the matrix. If there
    //is no solution, return zero. If thers is unique solution, the solution
    //will be put into the array "solution". 
    int solve(Coef* solution) {
        //print();
        int curL = 0;//The current line.
        int unCnt = m_wid - 1;//Number of unknowns.
        for (int un = 0; un < unCnt; un++) {
            if (m_matrix[curL][un] == 0) {
                for (int i = curL + 1; i < m_hei; i++) {
                    if (m_matrix[i][un] != 0) {
                        swapLine(i, curL, un);
                        break;
                    }
                }
            }
            //print();
            if (m_matrix[curL][un] != 0) {
                for (int i = 0; i < m_hei; i++) {
                    if (i != curL && m_matrix[i][un] != 0) {
                        toZero(i, curL, un);
                    }
                }
                //print();
                toOne(curL, un);
                //print();
                curL++;
            }
        }
        
        int rank = curL;
        for (int i = curL ; i < m_hei && rank != 0; i++) {
            if (m_matrix[i][m_wid - 1] != 0) {
                rank = 0;
            }
        }
        if (rank == unCnt) {
            for (int i = 0; i < unCnt; i++) {
                solution[i] = m_matrix[i][m_wid - 1];
            }
        }
        return rank;
    }

    void print() {
        for (int i = 0; i < m_hei; i++) {
            for (int j = 0; j < m_wid; j++) {
                cout << m_matrix[i][j] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
};

int main() {
    LinearSys<double> sys;
    sys.init(8);
    double ot = 1.0 / 3.0;
    double coef[][9] = {{1, 0, 0, 0, -1, 1, 0, 0, 0},
                        {0, 1, 0, 0, 0, -0.5, 0.5, 0, 0},
                        {0, 0, 1, 0, 0, 0, -ot, ot, 0 },
                        {0, 0, 0, 1, 0, -1, 0, 1, 0},
                        {1, -1, 0, -1, 0, 0, 0, 0, 0},
                        {0, 1, -1, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 1, 0, 0, 0, 1},
                        {0, 0, 0, 0, 0, 0, 0, 1, 0}
                       };
    for (int i = 0; i < 8; i++) {
        sys.addEq(coef[i]);
    }
    double solu[8];
    int rank = sys.solve(solu);
    cout << rank << " ";
    for (int i = 0; i < 8; i++) {
        cout << solu[i] << " ";
    }
    cout << endl;
    //Correct: 8 0.545455 0.0909091 0.0909091 0.454545 1 0.454545 0.272727 0
    return 0;
}
