/////////////////////////////////////////////////////////////////
//Range Minimum Query with Sparse Table Algorithm.
//Preprocessing: O(n lg n); Query: O(1).
/////////////////////////////////////////////////////////////////
#include <cmath>//log2

const int MAX_N = 100000,  LG_MAX_N = 17;

int g_min[MAX_N][LG_MAX_N];

//Preprocessing for the RMQ of array a[0, n).
void initST(const int* a, int n) {
    for (int i = 0; i < n; i++)  g_min[i][0] = i;
    for (int j = 1; (1 << j) <= n; j++)
        for (int i = 0; i + (1 << j) - 1 < n; i++)
        { if (a[ g_min[i][j-1] ] < a[ g_min[ i+( 1<<(j-1) ) ][j-1]])
              g_min[i][j] = g_min[i][j - 1];
          else  g_min[i][j] = g_min[ i + ( 1 << (j-1) ) ][j-1]; }
}

//Get the INDEX of the minimum element of 'a' in interval [l, r].
int rmq(const int* a, int l, int r) {
    if (l > r)  return rmq(a, r, l);  if (l == r)  return r;
    int lg = int( log2(r - l + 1) ); // Be sure l <= r.
    return a[ g_min[l][lg] ] <= a[ g_min[r - (1<<lg) + 1][lg] ]
           ? g_min[l][lg] : g_min[r - (1<<lg) + 1][lg];
}

//Test suite and usage example
#include <iostream>
using namespace std;
int main() {
    int a[] = {2, 4, 3, 1, 6, 7, 8, 9, 1, 7};
    initST(a, 10);
    int q [][2] = {{3, 6}, {0, 9}, {4, 4}, {3, 8}, {5, 4}};
    for (int i=0; i<5; i++) cout<<a[rmq(a, q[i][0], q[i][1])]<<' ';
    cout << endl;
    return 0; // output: 1 1 6 1 6
}
