/////////////////////////////////////////////////////////////////////
//Interval Tree. A segment tree representing integral intervals.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset;

using namespace std;

enum Cover {ALL, NONE, PART};

class IntervalTree {
public:
    IntervalTree (int left = 0, int right = 0): m_root(NULL)
        { init(left, right); }
    ~IntervalTree () { clear(m_root); }

    //Initialize a tree of the interval [left, right] wholly unset.
    void init(int left, int right)
        { clear(m_root); m_root = new Node(left, right, NULL, NONE); }

    void flip(int left, int right) {
        if (left <= right && left <= m_root->r && right >= m_root->l)
            { flip(m_root, left, right); }
    }

    //Store the intervals represented by this tree into a bool array.
    void get(bool* cvr) const { get(m_root, cvr, false); }

    void set(int left, int right, Cover cvr) {
        if (   left <= right && left <= m_root->r && right >= m_root->l
            && PART != cvr) { set(m_root, left, right, cvr); }
    }

private:
    struct Node {
        int l;//left bound
        int r;//right bound
        Cover cvr;//how the interval is covered, one of ALL, NONE, PART
        bool flp;//whether the interval is flipped.
        Node* prnt;//parent
        Node* lch;//left child
        Node* rch;//right child

        Node (int left, int right, Node* p = NULL, Cover c = NONE)
            : l(left), r(right), prnt(p), cvr(c),
              lch(NULL), rch(NULL), flp(false) {}
    };

    void clear(Node* p)
        { if (p) { clear(p->lch);  clear(p->rch);  delete p; } }

    void divide(Node* p) {
        if (PART != p->cvr) {
            int mid = (p->l + p->r) / 2;
            if (!p->lch) { p->lch = new Node(p->l, mid, p, p->cvr); }
            if (!p->rch) { p->rch = new Node(mid+1, p->r, p, p->cvr); }
            p->lch->cvr = p->rch->cvr = p->cvr;
            p->lch->flp = p->rch->flp = false;
        }
        if (p->flp)
            { flip(p->lch, p->l, p->r);  flip(p->rch, p->l, p->r); }
        p->cvr = PART;  p->flp = false;
    }

    void flip(Node* p, int left, int right) {
        if (left <= p->l && p->r <= right) {
            if (PART != p->cvr)
                { p->cvr = ALL == p->cvr? NONE: ALL;  p->flp = false; }
            else { p->flp = !p->flp; }
            return;
        }
        divide(p);
        int mid = (p->l + p->r) / 2;
        if (left <= mid) { flip(p->lch, left, right); }
        if (right > mid) { flip(p->rch, left, right); }
        if (p->lch->cvr == p->rch->cvr && p->lch->cvr != PART)
            { p->cvr = p->lch->cvr; }
    }

    void get(const Node* p, bool* cvr, bool flp) const {
        flp = flp != p->flp;
        if (PART != p->cvr) {
            bool flag = (ALL == p->cvr) != flp;
            memset( cvr, flag, (p->r - p->l + 1) * sizeof(bool) );
            return;
        }
        int mid = (p->l + p->r) / 2;
        get(p->lch, cvr, flp);
        get(p->rch, cvr + (mid - p->l + 1), flp);
    }

    void set(Node* p, int left, int right, Cover cvr) {
        if (cvr == p->cvr) { return; }
        if (left <= p->l && p->r <= right)
            { p->cvr = cvr;  p->flp = false;  return; }
        divide(p);
        int mid = (p->l + p->r) / 2;
        if (left <= mid) { set(p->lch, left, right, cvr); }
        if (right > mid) { set(p->rch, left, right, cvr); }
        if (cvr == p->lch->cvr && cvr == p->rch->cvr) { p->cvr = cvr; }
    }

    Node* m_root;
};

//Test suites:
#include <cstdio>
int main() {
    IntervalTree tree(0, 10);
    int a[][3] = { {2, 0, 10}, {2, 0, 10}, {0, 1, 3}, {0, 5, 7},
        {0, 8, 8}, {1, 2, 5}, {2, 2, 7}, {1, 9, 10}, {0, 10, 10},
        {0, 0, 6}, {2, 0, 10}, {1, 3, 7}, {0, 4, 8} };
    bool result[100], cnt;
    for (int i = 0; i < 13; i++) {
        switch (a[i][0]) {
            case 0: tree.set(a[i][1], a[i][2], ALL); break;
            case 1: tree.set(a[i][1], a[i][2], NONE); break;
            case 2: tree.flip(a[i][1], a[i][2]); break;
        }                         //Output: 1 1 1 1 1 1 1 1 1 1 1
        tree.get(result);                // 0 0 0 0 0 0 0 0 0 0 0
        for (int i = 0; i <= 10; i++)    // 0 1 1 1 0 0 0 0 0 0 0
            { printf("%d ", result[i]); }// 0 1 1 1 0 1 1 1 0 0 0
        printf("\n");                    // 0 1 1 1 0 1 1 1 1 0 0
    }                                    // 0 1 0 0 0 0 1 1 1 0 0
    return 0;                            // 0 1 1 1 1 1 0 0 1 0 0
}                                        // 0 1 1 1 1 1 0 0 1 0 0
                                         // 0 1 1 1 1 1 0 0 1 0 1
                                         // 1 1 1 1 1 1 1 0 1 0 1
                                         // 0 0 0 0 0 0 0 1 0 1 0
                                         // 0 0 0 0 0 0 0 0 0 1 0
                                         // 0 0 0 0 1 1 1 1 1 1 0
