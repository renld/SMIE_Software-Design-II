/////////////////////////////////////////////////////////////////////
//Big Integer
/////////////////////////////////////////////////////////////////////
#include <iostream>//ostream
#include <cstring>//memset, strlen

using namespace std;

const int INT_LEN = 3000;

typedef char Dig;//Digit
typedef long long I64;

//A big integer which is 0 defaultly.
class BigInt {
public:
    friend ostream& operator << (ostream& os, const BigInt& big);

    BigInt(I64 i = 0) { *this = i; }
    BigInt(const char* str) { *this = str; }

    void operator = (I64 n) { memset( m_d, 0, sizeof(m_d) );
                              m_len = int2Array(n, m_d); }

    void operator = (const char* str) {
        memset( m_d, 0, sizeof(m_d) );
        int len = strlen(str);
        m_len = 1;
        for(int i = 0; i < len; i++)
            { m_d[i] = str[len - 1 - i] - '0';
              if ( '0' != str[len - 1 - i] )  m_len = i + 1; }
    }

    void operator += (const BigInt& a) {
        Dig c = 0;//carry
        for (int i = 0; i < m_len || i < a.m_len || c > 0; i++) {
            if (i < m_len)  c += m_d[i];
            if (i < a.m_len)  c += a.m_d[i];
            m_d[i] = c % 10;  c /= 10;
            if (i >= m_len)  m_len = i + 1;
        }
    }

    void operator += (I64 a) {
        I64 c = a;//carry
        for (int i = 0; c > 0; i++) {
            if (i < m_len)  c += I64( m_d[i] );
            m_d[i] = Dig(c % 10);  c /= 10;
            if (i >= m_len)  m_len = i + 1;
        }
    }
    
    //Only for subtractor not greater than this number.
    void operator -= (const BigInt& s) {
        int newL = 1;  Dig b = 0;//borrow
        for (int i = 0; i < m_len || b > 0; i++) {
            Dig dec = b;
            if (i < s.m_len) dec += s.m_d[i];
            if (m_d[i] < dec)
                { m_d[i] = m_d[i] + 10 - dec;  b = 1; }
            else { m_d[i] -= dec;  b = 0; }
            if (m_d[i] != 0)  newL = i + 1;
        }
        m_len = newL;
    }

    //Only for subtractor not greater than this number.
    void operator -= (I64 sub) {
        int newL = 0;  I64 dec = sub;
        for (int i = 0; i < m_len; i++) {
            I64 b = 0;//borrow
            if ( I64( m_d[i] ) < dec ) {
                b = 10;
                while (b + I64( m_d[i] ) < dec)  b *= 10;
            }
            I64 temp = b + I64( m_d[i] ) - dec;
            dec = b / 10 - temp / 10;
            m_d[i] = Dig(temp % 10);
            if (m_d[i] > 0)  newL = i + 1;
        }
        m_len = newL;
        if (!m_len) { m_len = 1;  m_d[0] = 0; }
    }

    void operator *= (const BigInt& m) {
        Dig result[INT_LEN] = {0};  int newL = 1;
        for (int i = 0; i < m.m_len; i++) {
            Dig c = Dig(0);//carray
            int k = i;
            for (int j = 0; j < m_len; j++) {
                result[k] += m.m_d[i] * m_d[j] + c;
                c = result[k] / 10;  result[k] = result[k] % 10;
                if ( k >= newL && (result[k] || c) )  newL = k + 1;
                k++;
            }
            while (c > 0) { result[k] += c;  c /= 10;
                            if (k >= newL)  newL = k + 1; }
        }
        m_len = newL;
        for (int i = 0; i < m_len; i++)  m_d[i] = result[i];
    }

    void operator *= (I64 m) {
        if (!m) { *this = 0LL;  return; }
        I64 c = 0;//carry
        for (int i = 0; i < m_len; i++) { c += I64( m_d[i] ) * m;
                                          m_d[i] = Dig(c % 10);
                                          c /= 10; }
        while (c > 0) { m_d[m_len++] = Dig(c % 10);  c /= 10; }
    }

    //If can not divide exactly, just reserve the integer part.
    void operator /= (const BigInt& d) {
        BigInt low = 0LL, high = *this, mid, temp;
        while ( low.compare(high) < 0 ) {
            mid = low;  mid += high;  mid += 1;  mid /= 2;
            temp = mid;  temp *= d;
            if ( temp.compare(*this) > 0 ) { high = mid; high -= 1; }
            else  low = mid;
        }
        *this = low;
    }
    
    //If can not divide exactly, just reserve the integer part.
    void operator /= (I64 d) {
        I64 c = 0;  int newL = 0;
        for (int i = m_len - 1; i >= 0; i--) {
            I64 temp = c + m_d[i];
            m_d[i] = Dig(temp / d);
            c = (temp % d) * 10;
            if (m_d[i] && !newL)  newL = i + 1;
        }
        if (newL > 0)  m_len = newL;
        else  *this = 0LL;
    }

    int compare(const BigInt& i) const
        { return cmpWithArray(i.m_d, i.m_len); }

    int compare(I64 i) const
        { Dig digit[21];  int len = int2Array(i, digit);
          return cmpWithArray(digit, len); }

private:
    Dig m_d[INT_LEN];//Digits from low to high.
    int m_len;

    //Compare m_d with another array of digits.
    //Returns -1 if this number is lower than the other;
    //         0 if this number equals the other;
    //         1 if this number is greater than the other;
    int cmpWithArray(const Dig* digit, int n) const {
        int result = 0;
        if (m_len > n)  return 1;
        if (m_len < n)  return -1;
        for (int i = m_len - 1; i >= 0; i--)
            { if (m_d[i] > digit[i])  return 1;
              if (m_d[i] < digit[i])  return -1; }
        return 0;
    }

    //Convert an interger into an array of digit.
    int int2Array(I64 n, Dig* a) const {
        int len = 1;
        a[0] = n % 10;  n /= 10;
        while(n > 0) { a[ len++ ] = n % 10;  n /= 10; }
        return len;
    }
};

ostream& operator << (ostream& os, const BigInt& big) {
    for(int i = big.m_len - 1; i >= 0; i--)
        os << char( '0' + big.m_d[i] );
    return os;
}

//Test suites. You can choose to type the parts which you want to use.
int main(){
    BigInt a, b, c, d, zero = 0LL;

    //Test add small integer.
    a = 0LL;  a += 987654321987654321LL;  a += 987654321;  a += 0;
    cout << a << endl;//output: 987654322975308642

    //Test add big integer.
    a = "0";  b = "987654321987654321";  a += b;
    b = 987654321LL;  a += b;  a += zero;
    cout << a << endl;//output: 987654322975308642

    //Test subtract small integer.
    a = "123456789123456789";  a -= 23456789000000000LL;//9 zeros;
    a -= 123456789;  a -= 0;  a -= 100000000000000000LL;//17 zeros;
    cout << a << endl;//output: 0

    //Test subtract big integer.
    a = "123456789123456789";  b = 123456789000000000LL;//9 zeros;
    a -= b;  b = 123456789;  a -= zero;  a -= b;
    cout << a << endl;//output: 0

    //Test multiply small integer.
    a = "987654321";  a *= 123456789;  a *= 123456789123456789LL;
    cout << a << " ";
    a *= 0;  cout << a << " ";  a = 0LL;  a *= 123456789;
    cout << a << endl;//output: 15053411126540858750378688638891241 0 0

    //Test multiply big integer.
    a = "987654321";  b = 123456789LL;  a *= b;
    cout << a << " ";  a *= zero;  cout << a << " ";  a = 0LL;  a *= b;
    cout << a << endl;//output: 121932631112635269 0 0

    //Test divide small integer.
    a = "987654321987654321987654321";  a /= 123456789;
    a /= 8000000080900000744LL;
    cout << a << " ";  a = 123;  a /= 123456789;  cout << a << " ";
    a = 0LL;  a /= 123456789;  cout << a << endl;//output: 1 0 0
    
    //Test divide big integer.
    a = "987654321987654321987654321";  b = "123456789123456789";
    a /= b;  cout << a << " ";
    a="987654321987654321987654321"; b="987654321987654321987654320";
    a /= b;  cout << a << " ";
    a="987654321987654321987654321"; b="987654321987654321987654321";
    a /= b; cout << a << " ";
    a="987654321987654321987654321"; b="987654321987654321987654322";
    a /= b; cout << a << " ";
    a = 0LL;  b = 123456789123456789LL;  a /= b;
    cout << a << endl;//output: 8000000072 1 1 0 0

    //Test compare with small integer.
    a = 1LL;  cout << a.compare(0) << " " << a.compare(1) << " ";
    cout << a.compare(123456) << endl; //output: 1 0 -1
    
    //Test compare with big integer.
    a = "123456789123456789";  b=a;  c=a;  c -= 1;  d=a;  d += 1;
    cout << a.compare(b) << " " << a.compare(c) << " "
         << a.compare(d) << endl; //output: 0 1 -1
    return 0;
}
