/////////////////////////////////////////////////////////////////////
//Some basic code about math.
/////////////////////////////////////////////////////////////////////
#include <cmath>//fabs
#include <algorithm>//fill

using namespace std;

int g_prime[50000];//Needed by "testTotient()".

typedef double Real;
const Real PREC = 1e-8;

bool eq(Real a, Real b) { return fabs(a - b) < PREC; }

//Solving a binary linear system : a1 * x + b1 * y = c1
//                                 a2 * x + b2 * y = c2
//Store the solution in the parameter x and y.
//Return whether there is unique solution.
bool binSys(Real a1, Real b1, Real c1, Real a2, Real b2, Real c2,
            Real& x, Real& y
           )  {
    Real down = a1 * b2 - a2 * b1;
    if ( eq(down, 0.0) )  return false;
    x = (b2 * c1 - b1 * c2) / down;
    y = (a1 * c2 - a2 * c1) / down;
    return true;
}

//Get all prime numbers which is <= n, store them into array "p".
//After invoking this function, "p[i] == true" means i is prime.
void getPrimes(bool* p, int n) {
    fill(p, p + n + 1, true);
    p[0] = p[1] = false;  p[2] = true ;
    for(int i = 2; i <= n ; i++)  if( p[i] )
        for(int j = i * 2; j <= n; j += i)  p[j] = false;
}

//Length of an unsigned long long integer.
int intLen(unsigned long long num) {
    int len = 1;
    unsigned long long bound = 10;
    while (len < 20 && num >= bound) {
        len++;
        bound *= 10;
    }
    return len;
}

//Return the length of the given unsigned long long integer's binary form.
int binLen (unsigned long long num) {
    int result = 64;
    unsigned long long mask = 0x8000000000000000ULL;//15 zeros.
    while (mask > 1ULL) {
        if ((mask & num) > 0ULL) { break; }
        result--;  mask >>= 1;
    }
    return result;
}

//The greatest common divisor of a and b.
int gcd(int a, int b) {
    int temp;
    if (a < b) { temp = a;  a = b;  b = temp; }
    while (b) { temp = a % b;  a = b;  b = temp; }
    return a;
}

//get a^e mod m
int modExp(int a, int e, int p) {
    a = a % p;
    int result = 1;
    while (e > 0) {
        if (e & 1) {
            result = (result * a) % p;
        }
        e >>= 1;
        a = (a * a) % p;
    }
    return result;
}

//Get all of n's prime divisors.
//Store divisors in "divisors[]", exponent of every divisor in "exp[]",
//number of divisors in "divisorCnt".
void getPrimeDivisors(int n, int* divisors, int* exp, int& divisorCnt) {
    divisorCnt = 0;
    int i = 0;
    while (n > 1) {
        int p = g_prime[i];
        if (n % p == 0) {
            divisors[divisorCnt] = p;
            exp[divisorCnt] = 0;
            while (n > 1 && n % p == 0) {
                n /= p;
                exp[divisorCnt]++;
            }
            divisorCnt++;
        }
        i++;
    }
}

//Get the number of positive integers <= n and relatively prime to n.
//The two arrays "divisors" and "exp" are just used to store some
//intermediate results during the algorithm.
//But if you need to calculate a lot of totients,
//reallocate these arrays may slow down the program.
//So I need you just allocate the two arrays somewhere outside,
//so you can reuse these spaces every time you call this function.
int totient(int n, int* divisors, int* exp) {
    int divisorCnt;
    getPrimeDivisors(n, divisors, exp, divisorCnt);
    int result = 1;
    for (int i = 0; i < divisorCnt; i++) {
        result *= divisors[i] - 1;
        for (int j = 0; j < exp[i] - 1; j++) {
            result *= divisors[i];
        }
    }
    return result;
}

//Test suite
#include <iostream>

//Test the function binSys();
void testBinSys() {
    Real x, y;
    binSys(1, 2, 3, 8, 3, 7, x, y); cout << x << "," << y << " ";
    binSys(2, 3, 4, 5, 6, 9, x, y); cout << x << "," << y << " ";
    binSys(3, 4, 5, 6, 2, 3, x, y); cout << x << "," << y << " ";
    binSys(4, 5, 6, 7, 4, 2, x, y); cout << x << "," << y << endl;
    cout << binSys(1, 2, 3, 2, 4, 6, x, y) << endl;
    //Correct output: 
    //0.384615,1.30769 1,0.666667 0.111111,1.16667 -0.736842,1.78947
    //0
}

void testPrime() {
    bool a[100];
    getPrimes(a, 99);
    for (int i = 0; i <= 99; i++) {
        if (a[i]) {
            cout << i << " ";
        }
    }
    cout << endl;
    //correct:
    //2 3 5 7 11 13 17 19 23 29 31 37 41 43 47 53 59 61 67 71 73 79 83 89 97
}

void testLen() {
    unsigned long long a[] = {18446744073709551615ULL, 0, 1000};
    long long b[] = {9223372036854775807LL, 0, 1000};
    for (int i = 0; i < 3; i++) {                   //correct: 64 20 63 19
        cout << binLen(a[i]) << " " << intLen(a[i]) << " "; // 1 1 1 1
        cout << binLen(b[i]) << " " << intLen(b[i]) << endl;// 10 4 10 4
    }
}

void testGcd() {
    int a[] = {1, 11, 99, 3, 63, 0};
    int b[] = {1, 11, 99, 6, 27, 99999999};
    for (int i = 0; i < 6; i++) {
        cout << gcd(a[i], b[i]) << " ";
    }
    cout << endl;//correct output: 1 11 99 3 9 99999999
}

void testModExp() {
    cout << modExp(12345, 2002, 2003) << " ";
    cout << modExp(3, 4, 13) << " ";
    cout << modExp(1, 99999, 12345) << " ";
    cout << modExp(5, 1, 17) << endl;//correct: 1 3 1 5
}

//Don't forget the "int g_prime[50000];" at the beginning of this code.
void testTotient() {
    bool isPrime[50001];
    int divisor[50000], exp[50000], cnt = 0;
    getPrimes(isPrime, 50000);
    for (int i = 2; i <= 50000; i++) {
        if (isPrime[i]) {
            g_prime[cnt] = i;
            cnt++;
        }
    }
    int n[] = {2, 1, 5, 25940, 5188};
    for (int i = 0; i < 5; i++) {
        getPrimeDivisors(n[i], divisor, exp, cnt);
        for (int j = 0; j < cnt; j++) {
            cout << divisor[j] << "^" << exp[j] << " ";
        }
        cout << endl << totient(n[i], divisor, exp) << endl;
    }//Correct output:
    //2^1 
    //1
    //
    //1
    //5^1 
    //4
    //2^2 5^1 1297^1 
    //10368
    //2^2 1297^1 
    //2592
}

int main() {
    testBinSys();
    testPrime();
    testLen();
    testGcd();
    testModExp();
    testTotient();
    return 0;
}
