/////////////////////////////////////////////////////////////////////
//Randomized binary search tree. Its time of inserting, deleting and
//searching are all log(N).
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <cstdlib>

using namespace std;

template <class Key> struct TNode {
    Key key;
    TNode<Key>* lch;//right child
    TNode<Key>* rch;//left child
    TNode<Key>* prnt;//parent
    int cnt;//Number of nodes in the subtree whose root is this node.
    int prio;//priority
};

template <class Key> class Treap {
private:
    typedef TNode<Key> Node;
    Node* m_root;

    //This node represents the NULL pointer, pointed by the children pointers
    //of the leaf nodes and the parent pointer of the root. Its only useful
    //field is "cnt" which is 0 (The node count of an empty subtree is
    //certainly zero).
    Node* m_null;

    //Fix the tree to be a heap (each parent has a higher priority than its
    //children have). So while the given node has a lower priority than its
    //parent has, it is bubbled up by the leftRotate or rightRotate operation.
    void insertFixup(Node* node) {
        while (node->prnt != NULL && node->prio > node->prnt->prio) {
            if (node == node->prnt->lch) { rightRotate(node->prnt); }
            else { leftRotate(node->prnt); }
        }
    }

    //Do a left rotation on the specified node. Its original right child will
    //take the place of it.
    void leftRotate(Node* node) {
        Node* right = node->rch;
        node->rch = right->lch;
        node->cnt -= (right->rch == NULL? 0: right->rch->cnt) + 1;
        if (node->rch != NULL) { node->rch->prnt = node; }
        right->prnt = node->prnt;
        if (right->prnt == NULL) { m_root = right; }
        else if (node == node->prnt->lch) { node->prnt->lch = right; }
        else { node->prnt->rch = right; }
        right->lch = node;
        right->cnt += (node->lch == NULL? 0: node->lch->cnt) + 1;
        node->prnt = right;
    }

    //Do a right rotation on the specified node. Its original left child will
    //take the place of it.
    void rightRotate(Node* node) {
        Node* left = node->lch;
        node->lch = left->rch;
        node->cnt -= (left->lch == NULL? 0: left->lch->cnt) + 1;
        if (node->lch != NULL) { node->lch->prnt = node; }
        left->prnt = node->prnt;
        if (left->prnt == NULL) { m_root = left; }
        else if (node == node->prnt->lch) { node->prnt->lch = left; }
        else { node->prnt->rch = left; }
        left->rch = node;
        left->cnt += (node->rch == NULL? 0: node->rch->cnt) + 1;
        node->prnt = left;
    }

    //Return the node with the maximum key in a subtree whose root is p.
    Node* max(Node* p) const
        { while (p->rch != NULL) { p = p->rch; }  return p; }

    //Return the node with the minimum key in a subtree whose root is p.
    Node* min(Node* p) const
        { while (p->lch != NULL) { p = p->lch; }  return p; }

public:
    Treap() { m_root = NULL; }
    ~Treap() { clear(); }

    //Return the pointer to the (i + 1)th element in the sequence represented
    //by this tree. If "i" is not in the range [0, size() - 1], return NULL.
    Node* atIndex(int i) const {
        Node* p = m_root;
        if (i < 0 || i >= size()) { p = NULL; }
        else {
            int lCnt = p->lch == NULL? 0: p->lch->cnt;
            while (i != lCnt) {
                if (i < lCnt) { p = p->lch; }
                else { i -= lCnt + 1;  p = p->rch; }
                lCnt = p->lch == NULL? 0: p->lch->cnt;
            }
        }
        return p;
    }

    void clear() {
        Node* p = m_root;
        while (p != NULL) {
            if (p->lch != NULL) { p = p->lch; }
            else if (p->rch != NULL) { p = p->rch; }
            else {
                Node* temp = p;
                p = p->prnt;
                if (p != NULL) {
                    if (temp == p->lch) { p->lch = NULL; }
                    else { p->rch = NULL; }
                }
                delete temp;
            }
        }
        m_root = NULL;
    }

    void del(Node* node) {
        while (node->cnt > 1) {//Bubble down the node until it is a leaf.
            if (node->lch == NULL
                || node->lch != NULL && node->rch != NULL
                   && node->rch->prio > node->lch->prio) {
                leftRotate(node);
            }
            else { rightRotate(node); }
        }
        if (node == m_root) { m_root = NULL; }
        else if (node == node->prnt->lch) { node->prnt->lch = NULL; }
        else { node->prnt->rch = NULL; }
        for (Node* p = node->prnt; p != NULL; p = p->prnt) { p->cnt--; }
        delete node;
    }

    //Return the index of the key (contained in the given node) in the sequence
    //represented by this tree.
    int indexOf(Node* node) const {
        int lCnt = node->lch == NULL ? 0: node->lch->cnt;
        int i = lCnt;
        while (node->prnt != NULL) {
            Node* temp = node;
            node = node->prnt;
            if (temp == node->rch) {
                lCnt = node->lch == NULL ? 0: node->lch->cnt;
                i += lCnt + 1;
            }
        }
        return i;
    }

    void insert(const Key& key) {
        Node* node = new Node;
        node->key = key;
        node->cnt = 1;
        node->lch = NULL;
        node->rch = NULL;
        node->prio = rand();

        Node* p = m_root;
        Node* leaf = NULL;
        while (p != NULL) {
            leaf = p;
            leaf->cnt++;
            if (node->key < p->key) { p = p->lch; }
            else { p = p->rch; }
        }
        node->prnt = leaf;
        if (leaf == NULL) {//An empty tree.
            m_root = node;
        }
        else if (node->key < leaf->key) { leaf->lch = node; }
        else { leaf->rch = node; }
        insertFixup(node);//Fix the tree to keep the balance.
    }

    //The next node in the inorder traversal of the given node. If the given
    //node is the last element in the sequence represented by this tree, NULL
    //is returned.
    Node* next(const Node* node) const {
        Node* p;
        if (node->rch != NULL) { p = min(node->rch); }
        else {
            p = node->prnt;
            while (p != NULL && node == p->rch)
                { node = p;  p = p->prnt; }
        }
        return p;
    }

    Node* search(const Key& key) const {
        Node* p = m_root;
        while (p != NULL) {
            if (key < p->key) { p = p->lch; }
            else if (p->key < key) { p = p->rch; }
            else break;
        }
        return p;
    }

    void toArray(Key* array) const {
        Node* p = min(m_root);
        int i = 0;
        while (p != NULL) { array[i] = p->key;  i++;  p = next(p); }
    }

    //The previous node in the inorder traversal of the given node. If the
    //given node is the first element in the sequence represented by this tree,
    //NULL is returned.
    Node* pre(const Node* node) const {
        Node* p;
        if (node->lch != NULL) { p = max(node->lch); }
        else {
            p = node->prnt;
            while (p != NULL && node == p->lch)
                { node = p;  p = p->prnt; }
        }
        return p;
    }

    void print(const Node* root) const {
        if (root != NULL) {
            cout << root << " key: " << root->key;
            cout << " lch: " << root->lch << " rch: " << root->rch;
            cout << " cnt: " << root->cnt;
            cout << " priority: " << root->prio << endl;
            print(root->lch);
            print(root->rch);
        }
    }

    //Number of nodes in the tree.
    int size() const { return m_root != NULL? m_root->cnt: 0; }

    Node* root() const { return m_root; }
};

int main() {
    Treap<int> treap;
    char ins;
    int key;
    TNode<int>* p;
    while (cin >> ins) {
        switch(ins) {
            case 'i':
                cin >> key;
                treap.insert(key);
                break;

            case 'd':
                cin >> key;
                p = treap.search(key);
                treap.del(p);
                break;

            case 'p':
                treap.print(treap.root());
                break;

            case 's':
                cin >> key;
                p = treap.search(key);
                cout << p << endl;
                break;

            case 'l':
                cin >> key;
                p = treap.atIndex(key);
                cout << p << endl;
                break;

            case 'x':
                cin >> key;
                p = treap.search(key);
                cout << treap.indexOf(p) << endl;
                break;

            case 'n':
                p = treap.atIndex(0);
                while(p != NULL) {
                    cout << p->key << " ";
                    p = treap.next(p);
                }
                cout << endl;
                break;

            case 'm':
                p = treap.atIndex(treap.size() - 1);
                while(p != NULL) {
                    cout << p->key << " ";
                    p = treap.pre(p);
                }
                cout << endl;
                break;

            default:
                return 0;
        }
    }
    return 0;
}
