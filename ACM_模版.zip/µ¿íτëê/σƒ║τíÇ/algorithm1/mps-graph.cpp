/////////////////////////////////////////////////////////////////////
//A Graph represented by adjacent list.
//Providing shortest path algorithms.
/////////////////////////////////////////////////////////////////////
#include <cstring>
#include <set>
#include <list>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

typedef int Lt;//The type of lengths of edges.

const int MAX_VER = 1000;
const int MAX_LEN = 99999999;

struct Edge {
    int to;
    Lt len;
    Edge* next;

    Edge(int t = 0, Lt l = 0, Edge* n = NULL) {
        to = t; len = l; next = n;
    }
};

typedef const Edge* CEP;//const edge pointer.
typedef list<CEP>::const_iterator CLIt;//const list iterator.

//////////////////////////////////////////////////////
//Temp
#include <iostream>
/////////////////////////////////////////////////////
struct Path {
    int head;
    list<CEP> edge;
    Lt len;

    //Initialize a path with only one vertex.
    Path(int h = -1) { head = h; len = 0; }

    bool operator < (const Path& p) const {
        if (p.len != len) { return len < p.len; }
        if (p.head != head) { return head < p.head; }
        for (CLIt i = edge.begin(), j = p.edge.begin();
             edge.end() != i && p.edge.end() != j;
             i++, j++
            ) {
            if ( (*i)->to != (*j)->to ) { return (*i)->to < (*j)->to; }
        }
        return edge.size() < p.edge.size();
    }

    void addHead(int from, CEP e) {//Please be sure e->to == head
        if (e->to != head) { return; }
        edge.push_front(e); head = from; len += e->len;
    }

    void addTail(CEP e) { edge.push_back(e); len += e->len; }

    //Please be sure p's head is this path's tail.
    void concat(const Path& p) {
        for (CLIt i = p.edge.begin(); p.edge.end() != i; i++) {
            addTail(*i);
        }
    }

    bool contain(int v) const {
        if (v == head) { return true; }
        for (CLIt i = edge.begin(); edge.end() != i; i++) {
            if ((*i)->to == v) { return true; }
        }
        return false;
    }

    int from(CLIt e) const {//Get the source of the edge e.
        if (edge.empty() || edge.begin() == e) { return head; }
        return (*(--e))->to;
    }

    bool loopless() const {
        set<int> used; used.insert(head);
        for (CLIt i = edge.begin(); edge.end() != i; i++) {
            if ( 0 != used.count( (*i)->to ) ) { return false; }
            used.insert( (*i)->to );
        }
        return true;
    }

    Path subpath(CLIt e) const {//The subpath from head to the edge BEFORE e.
        Path p(head);
        for (CLIt i = edge.begin(); e != i; i++) { p.addTail(*i); }
        return p;
    }
};


//////////////////////////////////////
//TEMP

ostream& operator << (ostream& os, const Path& p) {
    os << p.head << " ";
    for (CLIt i = p.edge.begin(); p.edge.end() != i; i++) {
        os << (*i)->to << " ";
    }
    os << ": " << p.len;
    return os;
}
/////////////////////////////////////


class Graph {
public:
    Graph() { memset(m_adj, 0, sizeof(m_adj)); }
    ~Graph() { init(); }

    void addEdge(int from, int to, Lt len) {
        m_adj[from] = new Edge(to, len, m_adj[from]);
        Pair p(from, to);
        if (m_edge.count(p) == 0 || len < m_edge[p]->len) {
            m_edge[p] = m_adj[from];
        }
    }

    //Return whether shortest path exists.
    bool bellmanFord(int source) {
        initSingleSrc(source);
        int edgeCnt = 0;
        for (int i = 0; i < m_verCnt; i++) {
            for (Edge* adj = m_adj[i]; adj; adj = adj->next) {
                edgeCnt++;
            }
        }
        bool refresh = true;
        for (int iter = 0; refresh && iter < edgeCnt - 1; iter++) {
            refresh = false;
            for (int i = 0; i < m_verCnt; i++) {
                for (Edge* adj = m_adj[i]; adj; adj = adj->next) {
                    refresh = refresh || relax(i, adj->to, adj->len);
                }
            }
        }
        for (int i = 0; i < m_verCnt; i++) {
            for (Edge* adj = m_adj[i]; adj; adj = adj->next) {
                if ( relax(i, adj->to, adj->len) ) { return false; }
            }
        }
        return true;
    }

    //Get single source shortest paths with BFS.
    //Fall into INFINITE LOOP when the graph has NEGATIVE CIRCLE!!!
    void bfsShortest(int source) {
        initSingleSrc(source);
        list<int> que(1, source);
        while (!que.empty()) {
            int v = que.front();
            for (Edge* adj = m_adj[v]; adj; adj = adj->next) {
                if ( relax(v, adj->to, adj->len) ) {
                    que.push_back(adj->to);
                }
            }
            que.pop_front();
        }
    }

    //Can NOT handle graphs with NEGATIVE edges!!!
    void dijkstra(int source) {
        initSingleSrc(source);
        set<Sh> remain;
        for (int i = 0; i < m_verCnt; i++) {
            remain.insert( Sh(i, m_sh[i]) );
        }
        while (!remain.empty()) {
            set<Sh>::iterator sh = remain.begin();
            int v = sh->num;
            for (Edge* adj = m_adj[v]; adj; adj = adj->next) {
                int to = adj->to;
                Lt oldSh = m_sh[to];
                if ( relax(v, to, adj->len) ) {
                    remain.erase( Sh(to, oldSh) );
                    remain.insert( Sh(to, m_sh[to]) );
                }
            }
            remain.erase(sh);
        }
    }

    //Initialize a graph with "verCnt" vertices and no edge.
    void init(int verCnt = MAX_VER) {
        m_verCnt = verCnt;
        Edge* p, *temp;
        for (int i = 0; i < m_verCnt; i++) {
            p = m_adj[i];
            while (p) { temp = p; p = p->next; delete temp; }
            m_adj[i] = NULL;
        }
        m_edge.clear();
    }

    //Get the k loopless shortest paths.
    //Running this function will CHANGE the m_adj[].
    vector<Path> mpsLoopless(int source, int sink, int k) {
        vector<Path> result;
        Graph rev = reverse();
        rev.bellmanFord(sink);
        sortEdges(rev);
        //printEdge();
        set<Path> candidate;
        if (rev.shortest(source) < MAX_LEN) {
            candidate.insert( reverse( rev.shortestPath(source) ) );
        }
        while (!candidate.empty() && result.size() < k) {
            Path p = *(candidate.begin());
            candidate.erase(candidate.begin());
            //cout << "p: " << p << endl;
            CLIt dev = deviation(p, result);
            if (p.loopless()) { result.push_back(p); }
            Path half = p.subpath(dev);
            while ( half.loopless() && dev != p.edge.end() ) {
                //cout << "half: " << half << endl;
                CEP e = (*dev)->next;
                while (e && half.contain(e->to)) { e = e->next; }
                if ( e && rev.shortest(e->to) < MAX_LEN ) {
                    Path newP = half;  newP.addTail(e);
                    //cout << "newP1: " << newP << endl;
                    Path eSh = rev.shortestPath(e->to);
                    //cout << "eSh rev: " << eSh << endl;
                    eSh = reverse(eSh);
                    //cout << "eSh: " << eSh << endl;
                    newP.concat(eSh);
                    //cout << "newP2: " << newP << endl;
                    //newP.concat( reverse( rev.shortestPath(e->to) ) );
                    candidate.insert(newP);
                }
                half.addTail(*dev);  dev++;
            }
        }
        return result;
    }

    //The shortest path from the source to v
    //(after solving the single source shortest paths).
    Path shortestPath(int v) const {
        int len = m_sh[v];
        Path p(v);
        while (-1 != m_pre[v]) {
            p.addHead( m_pre[v], edge(m_pre[v], v) ); v = m_pre[v];
        }
        p.len = len;
        return p;
    }

    //The shortest distance from the source to v
    //(after solving the single source shortest paths).
    Lt shortest(int v) const { return m_sh[v]; }

    /////////////////////////////////////////
    //TEMP
    void printEdge() {
        for (int i = 0; i < m_verCnt; i++) {
            cout << i << ": ";
            for (Edge* p = m_adj[i]; p; p = p->next) {
                cout << p->to << " ";
            }
            cout << endl;
        }
    }
    ////////////////////////////////////////

private:
    struct Pair {
        int from; int to;
        Pair(int f = 0, int t = 0) { from = f; to = t; }
        bool operator < (const Pair& p) const {
            return from < p.from || from == p.from && to < p.to;
        }
    };

    struct TempEdge {//Help the sortEdges().
        Edge* e; int cost;
        bool operator < (const TempEdge& e) const {
            return cost < e.cost;
        }
    };

    struct Sh {//Help the dijkstra().
        int num; Lt len;
        Sh(int n = 0, Lt l = 0) { num = n; len = l; }
        bool operator < (const Sh& s) const {
            return len < s.len || len == s.len && num < s.num;
        }
    };

    CLIt deviation(const Path& p, const vector<Path>& k) const {
        int max = 0;
        CLIt result = p.edge.begin();
        for (int i = 0; i < k.size(); i++) {
            if (p.head != k[i].head) { continue; }
            int cnt = 1;
            CLIt it = p.edge.begin(), kIt = k[i].edge.begin();
            while (p.edge.end() != it && k[i].edge.end() != kIt
                   && (*it)->to == (*kIt)->to
                  ) { cnt++; it++; kIt++; }
            if (cnt > max) { max = cnt; result = it; }
        }
        return result;
    }

    Edge* edge(int from, int to) const {
        Pair p(from, to);
        if (m_edge.count(p) > 0) { return m_edge.find(p)->second; }
        else { return NULL; }
    }

    //Initialize the single source shortest path algorithms.
    void initSingleSrc(int source) {
        for (int i = 0; i < m_verCnt; i++) {
            m_sh[i] = MAX_LEN;
            m_pre[i] = -1;
        }
        m_sh[source] = 0;
    }

    //Help the shortest path algorithms.
    bool relax(int from, int to, Lt len) {
        if (m_sh[to] > m_sh[from] + len) {
            m_sh[to] = m_sh[from] + len; m_pre[to] = from; return true;
        }
        return false;
    }

    Graph reverse() const {
        Graph rev; rev.init(m_verCnt);
        for (int i = 0; i < m_verCnt; i++) {
            for (Edge* p = m_adj[i]; p; p = p->next) {
                rev.addEdge(p->to, i, p->len);
            }
        }
        return rev;
    }

    //Help the K loopless shortest path algorithms.
    Path reverse(const Path& p) const {
        int pre = p.head;
        Path rev(pre);
        for (CLIt i = p.edge.begin(); p.edge.end() != i; i++) {
            rev.addHead( (*i)->to, edge( (*i)->to, pre ) );
            pre = (*i)->to;
        }
        return rev;
    }

    //Help the K loopless shortest paths algorithms.
    //Edges are sorted in ascending order by their reduced costs.
    void sortEdges(const Graph& rev) {
        TempEdge e[MAX_VER];//Maybe more edges, change it if you need.
        for (int i = 0; i < m_verCnt; i++) {
            int cnt = 0;
            for (Edge* p = m_adj[i]; p; p = p->next) {
                e[cnt].e = p;
                e[cnt].cost = p->len - (rev.m_sh[i] - rev.m_sh[p->to]);
                cnt++;
            }
            if (0 == cnt) { continue; } 
            sort(e, e + cnt);
            for (int j = 0; j < cnt - 1; j++) {
                e[j].e->next = e[j + 1].e;
            }
            m_adj[i] = e[0].e; e[cnt - 1].e->next = NULL;
        }
    }

    int m_verCnt;//Number of vertices.
    Edge* m_adj[MAX_VER];//Adjacent list.
    Lt m_sh[MAX_VER];//Every vertex's shortest distance from the source.
    int m_pre[MAX_VER];//The previous vertex in the shortest path.
    //m_edge[Pair(i, j)]: the shortest edge from i to j.
    //If no edege from i to j, no m_edge[Pair(i, j)].
    map<Pair, Edge*> m_edge;
};

//Test suite.
int main() {
    Graph g; g.init(6);
    //This is a graph from "INTRODUCTION TO ALGORITHMS", page 596.
    int e[][3] = {{0,1,10}, {0,3,5}, {1,2,1}, {1,3,2}, {3,1,3},
                  {3,2,9}, {3,4,2}, {2,4,4}, {4,2,6}, {4,0,7}};
    for (int i = 0; i < 10; i++)
        g.addEdge(e[i][0], e[i][1], e[i][2]);
    //g.bellmanFord(0);
    g.dijkstra(0);
    //g.bfsShortest(0);
    for (int i = 0; i < 6; i++) { cout << g.shortest(i) << " "; }
    cout << endl;//Correct: 0 8 9 5 7 99999999
    for (int v = 0; v < 6; v++) {
        cout << g.shortestPath(v) << endl;
    }
    vector<Path> kSh = g.mpsLoopless(2, 3, 100);
    for (int i = 0; i < kSh.size(); i++) { cout << kSh[i] << endl; }
    return 0;
}
