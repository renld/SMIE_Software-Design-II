/////////////////////////////////////////////////////////////////////
//Trie.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset.

using namespace std;

const int ALPHA_SIZE = 26;
const int MAX_N = 1100000;

struct TNode {
    TNode* ch[ALPHA_SIZE];//Children
    int i;//the index of the word that ends at this node
};

TNode g_ndMem[MAX_N];
int g_allocI = 0;

TNode* newTNode() {
    g_ndMem[g_allocI].i = -1;
    memset( g_ndMem[g_allocI].ch, 0, sizeof( g_ndMem[0].ch ) );
    return &g_ndMem[g_allocI++];
}

class Trie {
public:
    Trie(): m_n(0) { m_rt = newTNode(); }
    ~Trie() { clear(); }

    //Return the index of the inserted word.
    //Return -1 if failed (the word already exists or is empty).
    int insert(const char* str) {
        TNode* p = m_rt;
        for ( ; *str; str++) {
            int i = ch2i(*str);
            if ( !p->ch[i] )  p->ch[i] = newTNode();
            p = p->ch[i];
        }
        if (p == m_rt || -1 != p->i)  return -1;
        p->i = m_n++;
        return p->i;
    }

    void clear() { g_allocI = 0;  m_n = 0; m_rt = newTNode(); }
    
    //Find the index the word "str".
    //Return -1 if not found or an empty string is given.
    int find(const char* str) const {
        TNode* p = m_rt;
        for ( ; *str; str++) { p = p->ch[ ch2i(*str) ];
                               if (!p)  return -1; }
        return p->i;
    }

    TNode* getRoot() { return m_rt; }

private:
    inline int ch2i(char c) const { return c - 'a'; }

    TNode* m_rt;//Tree Root.
    int m_n;//Number of words in the TRIE.
};

//Test suite.
#include <iostream>

int main() {
    Trie t;
    char w[][10] = {"red", "blue", "red", "", "green"};
    char q[][10] = {"blue", "red", "green", "", "white", "redred"};
    for (int i = 0; i < 5; i++) { cout << t.insert(w[i]) << " "; }
    cout << endl;//Output: 0 1 -1 -1 2
    for (int i = 0; i < 6; i++) { cout << t.find(q[i]) << " "; }
    cout << endl;//Output: 1 0 2 -1 -1 -1
    return 0;
}
