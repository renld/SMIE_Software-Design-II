/////////////////////////////////////////////////////////////////////
//Disjoint Set
/////////////////////////////////////////////////////////////////////
const int MAX_SET_ELE = 10000;

class DisjointSet {
public:
    void init(int n)
        { m_n = n;
          for (int i = 0; i < m_n; i++)  m_set[i] = i; }

    int findSet(int i)
        { if ( m_set[i] != i )  m_set[i] = findSet( m_set[i] );
          return m_set[i]; }

    //Usually you needn't distinguish the parent and child.
    void unionSet(int parent, int child)
        { m_set[ findSet(child) ] = findSet(parent); }

private:
    int m_set[MAX_SET_ELE], m_n;
};

//Test suites
#include <iostream>

using namespace std;

int main() {
    DisjointSet ds;
    ds.init(10);
    int a[] = {5, 7, 6, 9, 0, 2, 5, 3, 4, 6};
    int b[] = {8, 2, 3, 0, 5, 6, 9, 7, 1, 4};
    for (int i = 0; i < 10; i++) {
        ds.unionSet(a[i], b[i]);
    }
    for (int i = 0; i < 10; i++) {
        cout << ds.findSet(i) << " ";
    }
    cout << endl;//Right output: 9 7 7 7 7 9 7 7 9 9 
    return 0;
}
