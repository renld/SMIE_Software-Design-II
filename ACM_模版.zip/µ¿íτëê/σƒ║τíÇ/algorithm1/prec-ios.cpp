/////////////////////////////////////////////////////////////////
//Output real numbers rounded to specified decimal by cout.
/////////////////////////////////////////////////////////////////
#include <iostream>
#include <iomanip>//setprecision
#include <sstream>//ostringstream
#include <cstdlib>//atof
#include <cmath>//fabs, pow
#include <string>

using namespace std;

const double DELTA = 1e-8;

inline bool eq(double a, double b) { return fabs(a - b) < DELTA; }
inline bool lt(double a, double b) { return a < b && !eq(a, b); }
inline bool ge(double a, double b) { return a > b || eq(a, b); }

struct Prec { double r;  int d;//Real number and decimal width
              Prec(double R, int D): r(R), d(D) {} };

ostream& operator << (ostream& os, const Prec& p) {
    ostringstream sOut;
    sOut << setprecision(16) << fixed << p.r;
    string str = sOut.str();
    for (int i = 0; ; i++)  if ( '.' == str[i] )
        { str.erase( str.begin()+i+p.d+1, str.end() );  break; }
    double r2 = atof( str.c_str() ), rem = fabs(p.r - r2),
           c = pow(0.1, p.d);
    if ( ge(rem, c / 2.0) )  r2 += lt(p.r, 0.0)? -c: c;
    if ( eq(r2, 0.0) )  r2 = 0.0;
    return os << setprecision(p.d) << fixed << r2;
}

//Test suite and usage example.
int main() {
    double r;  int d;
    while (cin >> r >> d)  cout << Prec(r, d) << endl;
    return 0; }
/* Input:  0.00049999999 3  -0.0001 3  1.234 0  -2.3456e-100 3  1 4
   Output: 0.001  0.000  1  0.000  1.0000*/
