/////////////////////////////////////////////////////////////////
//Constructing Suffix Array with DC3 Algorithm in O(3n) time.
/////////////////////////////////////////////////////////////////
#include <cstring>//memset, memcmp

using namespace std;

const int ALPHABET_SIZE = 26 * 2 + 1;
const int MAX_SFX = 1000;

//Some utility functions in the DC3 algorithm.
inline int s2i(int* s, int* text, int n1)
    { return 1 == (s-text) % 3? (s-text) / 3: n1 + (s-text) / 3; }
inline int* i2s(int i, int* text, int n1)
    { return text + (i < n1? 3 * i + 1: 3 * (i - n1) + 2); }
inline bool lt(int a1, int a2,  int b1, int b2)
    { return a1 < b1 || a1 == b1 && a2 < b2; }
inline bool lt(int a1, int a2, int a3,   int b1, int b2, int b3)
    { return a1 < b1 || a1 == b1 && lt(a2, a3,  b2, b3); }

void cSort(int** in, int n, int key, int alph, int** out) {
    int* cnt = new int[alph];  memset(cnt, 0, sizeof(int) * alph);
    for (int i = 0; i < n; i++)  cnt[ in[i][key] ]++;
    for (int i = 1; i < alph; i++)  cnt[i] += cnt[i - 1];
    for (int i = n-1; i >= 0; i--)  out[ --cnt[ in[i][key] ] ] = in[i];
    delete[] cnt;
}

void merge(int* text, int* r, int** s12, int n12,
           int** s0, int n0, int** out) {
    int **i = out, **j = s12, **k = s0;
    if ( !**j ) j++; //There may be suffix starting with 0
    if ( !**k ) k++; //whice is useless now. Skip.
    for (; j < s12 + n12 && k < s0 + n0; i++)
        if (1 == (*j - text) % 3)
            *i = lt( **j, r[*j - text + 1], **k, r[*k - text + 1] )
                 ? *(j++): *(k++);
        else  *i = lt( **j, *(*j+1), r[*j-text+2],
                       **k, *(*k+1), r[*k-text+2] )? *(j++): *(k++);
    for (; j < s12 + n12; i++, j++)  *i = *j;
    for (; k < s0 + n0; i++, k++)  *i = *k;
}

//Put the suffix array of the integer array 'text' into array 'out'.
//'text' is of length 'n', but must have (n + 3) space.
void dc3(int* text, int n, int** out) {
    text[n] = text[n + 1] = text[n + 2] = 0;
    int n1 = (n+2) / 3, n2 = (n+1) / 3, n12 = n1 + n2,
    **s12=new int*[n12], *r12=new int[n12+3], **temp=new int*[n12];
    for (int i=0, j=0; i <= n; i++)  if (i%3)  temp[j++] = text + i;
    cSort(temp, n12, 2, n + 1, s12);//Radix sort the mod 1,2 samples.
    cSort(s12,  n12, 1, n + 1, temp);
    cSort(temp, n12, 0, n + 1, s12);
    int r=1;  r12[ s2i(s12[0], text, n1) ] = r;
    for (int i = 1; i < n12; i++)
        { if ( memcmp(s12[i], s12[i - 1], sizeof(int) * 3) )  r++;
          r12[ s2i(s12[i], text, n1) ] = r; }
    if (r < n12) {          //Ranks are not unique,
        dc3(r12, n12, s12); //sort their suffixes recursively.
        for (int i=0; i < n12; i++)
            { s12[i] = i2s(s12[i] - r12, text, n1);
              r12[ s2i(s12[i], text, n1) ] = i + 1; }
    }
    int n0 = (n + 2) / 3, **s0 = new int*[n0];
    for (int i = 0, j = 0; i < n12; i++)
        if (1 == (s12[i] - text) % 3)  temp[j++] = s12[i] - 1;
    cSort(temp, n0, 0, n + 1, s0);//Sort the mod 0 samples.
    int* R = new int[n + 3];
    for (int i = 0; i < n12; i++)  if (i < n1)  R[i*3 + 1] = r12[i];
                                   else  R[(i-n1)*3 + 2] = r12[i];
    R[n] = R[n + 1] = R[n + 2] = 0;
    merge(text, R, s12, n12, s0, n0, out);
    delete[] s12; delete[] r12; delete[] s0; delete[] temp; delete[] R;
}

int getLCP(int* a, int* b)
{ int l=0;  while(*a>1 && *b>1 && *a==*b) {l++;a++;b++;}  return l; }

void getLCP(int* text, int** sfx, int len, int* lcp) {
    int* rank = new int[len];
    for (int i=0, r=0; i < len; i++, r++) rank[sfx[i] - text] = r;
    lcp[0] = 0;
    if (rank[0])  lcp[ rank[0] ] = getLCP( text, sfx[rank[0] - 1] );
    for (int i = 1; i < len; i++) {
        if ( !rank[i] )  continue;
        if (lcp[ rank[i - 1] ] <= 1)
        { lcp[ rank[i] ] = getLCP( text + i, sfx[rank[i] - 1] ); }
        else
        { int l = lcp[ rank[i - 1] ] - 1;
          lcp[rank[i]] = l + getLCP(text+i+l, sfx[rank[i]-1]+l); }
    }
    delete[] rank;
}

inline int c2i(char c) { return !c ? 0: (c<='Z'? 1+c-'A': 27+c-'a'); }
void c2i(char* in, int* out, int len) {
    int cnt[ALPHABET_SIZE] = {0};
    for (int i = 0; i < len; i++)  cnt[ c2i( in[i] ) ] = 1;
    for (int i = 1; i < ALPHABET_SIZE; i++)  cnt[i] += cnt[i - 1];
    for (int i = 0; i < len; i++)  out[i] = cnt[ c2i( in[i] ) ];
}

//Test suite and usage example.
#include <iostream>
struct Suffix { const char* str;  int from; };
int main() {
    char str[] = "abcabc\0abcabc";
    int from[] = {0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1};
    int text[13 + 3], *out[13], lcp[13];
    c2i(str, text, 13);
    dc3(text, 13, out);
    getLCP(text,out,13,lcp);
    Suffix sfx[13];
    for (int i=0; i<13; i++) { sfx[i].str = str + (out[i] - text);
                               sfx[i].from = from[out[i] - text]; }
    for (int i=1; i<13; i++)//The first suffix is useless (empty).
        { cout<<sfx[i].from<<' '<<sfx[i].str<<' '<<lcp[i]<<endl; }
    return 0;//output:1 abc 0
    //                0 abc 3
    //                1 abcabc 3
    //                0 abcabc 6
    //                1 bc 0
    //                0 bc 2
    //                1 bcabc 2
    //                0 bcabc 5
    //                1 c 0
    //                0 c 1
    //                1 cabc 1
    //                0 cabc 4
}
