/////////////////////////////////////////////////////////////////////
//Find the K shortest LOOPLESS paths with YEN algorithm.
//Uncomment the "BEGIN-LEXICOGRAPHICAL"~"END-LEXICOGRAPHICAL" parts
//to rank the paths in REVERSED-lexicographical order,
//ONLY when the graph has NO ZERO-WEIGHT CYCLE.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset.
#include <vector>//representing paths.
#include <queue>//priority_queue.
#include <algorithm>//reverse, lexicographical_compare.
#include <functional>//greater.

using namespace std;

typedef short VT;//The type of vertex numbers.
typedef int LT;//The type of lengths of edges.

const VT MAX_VER = 50;
const LT MAX_LEN = 99999999;

struct Edge {
    VT to;
    LT len;
    Edge* next;

    Edge(VT t = 0, LT l = 0, Edge* n = NULL) {
        to = t; len = l; next = n;
    }
};

struct Path {
    vector<VT> node;
    vector<VT> block;
    LT len;

    //The index of the deviation node. Nodes before this node are on the
    //k shortest paths' tree.
    VT dev;

    //Initialize a path with only one vertex.
    Path(VT v = 0) : node(), block() { node.push_back(v); len = 0; }

    bool operator > (const Path& p) const {
        return len > p.len
               //---------------BEGIN-LEXICOGRAPHICAL----------------
               //|| len == p.len
               //&& lexicographical_compare(
               //       p.node.rbegin(), p.node.rend(),
               //       node.rbegin(), node.rend() )
               //----------------END-LEXICOGRAPHICAL-----------------
               ;
    }
};

class Graph {
public:
    Graph() { memset(m_adj, 0, sizeof(m_adj)); }
    ~Graph() { init(); }

    //Multiple edges between same pair of vertices are not allowed.
    void addEdge(VT from, VT to, LT len) {
        if ( NULL == m_edge[from][to] ) {
            m_adj[from] = new Edge(to, len, m_adj[from]);
            m_edge[from][to] = m_adj[from];
        }
    }

    //Can NOT handle graphs with NEGATIVE edges!!!
    void dijkstra() {
        int minV;
        for (int iter = 0; iter < m_verCnt; iter++) {
            minV = -1;
            for (int i = 0; i < m_verCnt; i++) {
                if (!m_visit[i]
                    && ( -1 == minV || m_sh[i] < m_sh[minV] )
                   ) { minV = i; }
            }
            if (-1 == minV) { break; }
            m_visit[minV] = true;
            for (Edge* adj = m_adj[minV]; adj; adj = adj->next) {
                VT to = adj->to;
                //The condition "!m_visit[to]" is suitable
                //only for non-negative-edge graphs.
                if (!m_visit[to] && !m_block[minV][to]) {
                    relax(minV, to, adj->len);
                }
            }
        }
    }

    //Initialize a graph with "verCnt" vertices and no edge.
    void init(VT verCnt = MAX_VER) {
        memset( m_edge, 0, sizeof(m_edge) );
        m_verCnt = verCnt;
        Edge* p, *temp;
        for (VT i = 0; i < m_verCnt; i++) {
            p = m_adj[i];
            while (p) { temp = p; p = p->next; delete temp; }
            m_adj[i] = NULL;
        }
    }

    //Get the k loopless shortest paths with YEN's algorithm.
    //If two paths have the same length
    //and the "BEGIN-LEXICOGRAPHICAL"~"END-LEXICOGRAPHICAL" parts of the
    //code are uncommented, the path whose reversed path has
    //lexicographically lower value ranks first.
    vector<Path> yenLoopless(VT source, VT sink, int k) {
        vector<Path> result;
        priority_queue< Path, vector<Path>, greater<Path> > candidate;
        memset(m_block, 0, sizeof(m_block));
        initSingleSrc(source);
        dijkstra();
        if (shortest(sink) < MAX_LEN) {
            Path sh = shortestPath(sink);
            sh.dev = 1;
            sh.block.push_back( sh.node[sh.dev] );
            candidate.push(sh);
        }
        while ( result.size() < k && !candidate.empty() ) {
            Path p = candidate.top();
            candidate.pop();
            VT dev = p.dev;
            while ( dev < p.node.size() ) {
                VT pre = p.node[dev - 1];
                if (dev == p.dev) {
                    for (int i = 0; i < p.block.size(); i++) {
                        m_block[pre][ p.block[i] ] = true;
                    }
                }
                else { m_block[pre][ p.node[dev] ] = true; }
                initSingleSrc(source);
                delSubpath(p, dev);
                dijkstra();
                if (shortest(sink) < MAX_LEN) {
                    Path newP = shortestPath(sink);
                    newP.dev = dev;
                    if (dev == p.dev) { newP.block = p.block; }
                    else { newP.block.push_back( p.node[dev] ); }
                    newP.block.push_back( newP.node[dev] );
                    candidate.push(newP);
                }
                dev++;
            }
            memset(m_block, 0, sizeof(m_block));
            result.push_back(p);
        }
        return result;
    }

    Path shortestPath(VT v) const {
        Path p(v);
        p.len = m_sh[v];
        for (v = m_pre[v]; -1 != v; v = m_pre[v]) {p.node.push_back(v);}
        reverse( p.node.begin(), p.node.end() );
        return p;
    }

    //The shortest distance from the source to v
    //(after solving the single source shortest paths).
    LT shortest(VT v) const { return m_sh[v]; }

private:
    //Determine leading subpath of the shortest path generated by
    //dijkstra().
    void delSubpath(const Path& p, VT dev) {
        VT pre = p.node[0];
        m_visit[pre] = true;
        int v;
        for (VT i = 1; dev != i; i++) {
            v = p.node[i];
            m_pre[v] = pre;
            m_sh[v] = m_sh[pre] + m_edge[pre][v]->len;
            m_visit[v] = true;
            pre = v;
        }
        m_visit[pre] = false;
    }

    //Initialize the single source shortest path algorithms.
    void initSingleSrc(VT source) {
        for (VT i = 0; i < m_verCnt; i++) {
            m_sh[i] = MAX_LEN;
            m_pre[i] = -1;
            m_visit[i] = false;
        }
        m_sh[source] = 0;
    }

    //Help the shortest path algorithms.
    bool relax(VT from, VT to, LT len) {
        if (m_sh[to] > m_sh[from] + len) {
            m_sh[to] = m_sh[from] + len; m_pre[to] = from; return true;
        }
        //-------------------BEGIN-LEXICOGRAPHICAL-------------------
        //else if (m_sh[to] == m_sh[from] + len && from < m_pre[to]) {
        //    m_pre[to] = from; return true;
        //}
        //--------------------END-LEXICOGRAPHICAL--------------------
        return false;
    }

    VT m_verCnt;//Number of vertices.
    Edge* m_adj[MAX_VER];//Adjacent list.
    LT m_sh[MAX_VER];//Every vertex's shortest distance from the source.
    VT m_pre[MAX_VER];//The previous vertex in the shortest path.
    //m_edge[i][j]: the edge from i to j. NULL value if no edge (i, j).
    Edge* m_edge[MAX_VER][MAX_VER];
    bool m_visit[MAX_VER];//Help the dijkstra.

    //Help to make acyclic paths.
    bool m_block[MAX_VER][MAX_VER];
};

//Test suite.
#include <iostream>

ostream& operator << (ostream& os, const Path& p) {
    os << p.node[0];
    for (int i = 1; i < p.node.size() ; i++) {
        os << "-" << p.node[i];
    }
    os << ": " << p.len;
    return os;
}

int main() {
    int e [20][3] = { {0, 1, 1}, {0, 2, 2}, {0, 3, 1}, {0, 4, 3},
                      {1, 0, 1}, {1, 2, 1}, {1, 3, 2}, {1, 4, 2},
                      {2, 0, 1}, {2, 1, 2}, {2, 3, 1}, {2, 4, 1},
                      {3, 0, 1}, {3, 1, 1}, {3, 2, 1}, {3, 4, 2},
                      {4, 0, 1}, {4, 1, 1}, {4, 2, 1}, {4, 3, 1} };
    Graph g;  g.init(5);
    for (int i = 0; i < 20; i++)
        { g.addEdge( e[i][1], e[i][0], e[i][2]); }
    vector<Path> v = g.yenLoopless(4, 0, 16);
    for (int i = 0; i < v.size(); i++) { cout << v[i] << endl; }
    //output:
    //reversed-lexicographically sorted  |  not sorted
    //4-2-1-0: 3                            4-0: 3
    //4-1-0: 3                              4-2-0: 3
    //4-2-0: 3                              4-1-0: 3
    //4-2-3-0: 3                            4-2-1-0: 3
    //4-3-0: 3                              4-3-0: 3
    //4-0: 3                                4-2-3-0: 3
    //4-2-1-3-0: 4                          4-2-1-3-0: 4
    //4-1-3-0: 4                            4-1-3-0: 4
    //4-3-2-1-0: 5                          4-2-3-1-0: 5
    //4-2-3-1-0: 5                          4-3-2-0: 5
    //4-3-1-0: 5                            4-3-1-0: 5
    //4-3-2-0: 5                            4-3-2-1-0: 5
    //4-1-2-0: 6                            4-1-3-2-0: 6
    //4-1-3-2-0: 6                          4-1-2-0: 6
    //4-1-2-3-0: 6                          4-1-2-3-0: 6
    //4-3-1-2-0: 8                          4-3-1-2-0: 8
    return 0;
}
