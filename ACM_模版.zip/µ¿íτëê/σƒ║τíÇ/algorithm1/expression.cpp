//===============================================//
//  Title  : Solve Expression
//  Author : Sunkid
//  Data   : 2003/10/06
//===============================================//
#include <iostream.h>
#define BUF_SIZE 1000

char buf[ BUF_SIZE ];

class Equation
{
public:
    int slv( char *buf )
    {
        equ=buf;
        return getExp();
    }
    int slv2( char*buf )
    {
        equ=buf;
        return getExp2();
    }
    Equation()
    {
        PRI['+']=1;
        PRI['-']=1;        
        PRI['*']=2;
        PRI['/']=2;
        PRI['(']=0;
        PRI[')']=0;
    }
    
protected:
    char *equ;
    
    int PRI[256];
   
    inline bool isDigit(char c)
    {
        return ( '0'<=c && c<='9' );
    }
    inline bool isOper(char c)
    {
        return ( c=='+' ||
                 c=='-' ||
                 c=='*' );
    }
    int operation(int a,int b,char oper)
    {
        switch( oper )
        {
        case '+': return a+b;
        case '-': return a-b;
        case '*': return a*b;
        }
    }
    char getOper()
    {
        return *equ;
    }
    
    int getNum()
    {
        int r=0;
        while( isDigit(*equ) )
        {
            r=r*10+(*equ)-'0';
            equ++;
        }
        return r;
    }
    int getExp()                   /*no supervise*/ 
    {
        int a=0,b;
        char oper='+';
        while( *equ )
        {
            if( *equ=='(' )
            {
                equ++;
                b=getExp();
            }
            else
                b=getNum();
            a=operation(a,b,oper);
            switch( *equ )
            {
            case '+':
            case '-':
            case '*':
                oper=*equ;
                equ++;
                break;
            case ')':
                equ++;
                return a; 
            case '\0':
                return a;
            }
        }   
    }
    
    int getExp2()              /*supervise*/
    {
        int stk_n[1000];
        char stk_o[1000];
        int n_top=-1;
        int o_top=-1;
        
        int a,b;
        char op;
        
        while( *equ )
        {        
            if( isDigit(*equ) )
            {
                n_top++;
                stk_n[n_top]=getNum();                
            }
            else
            {
                op=getOper();
                if( op==')' )
                {
                    while( stk_o[o_top]!='(' )
                    {
                        op=stk_o[o_top];
                        o_top--;
                        a=stk_n[n_top];
                        n_top--;
                        b=stk_n[n_top];
                        stk_n[n_top]=operation(b,a,op);                    
                    }
                    o_top--;
                    equ++;
                }
                else if( o_top<0 || PRI[op]>PRI[ stk_o[o_top] ] || op=='(' )
                {
                    o_top++;
                    stk_o[o_top]=op;
                    equ++;
                }
                else
                {
                    op=stk_o[o_top];
                    o_top--;
                    a=stk_n[n_top];
                    n_top--;
                    b=stk_n[n_top];
                    stk_n[n_top]=operation(b,a,op);                    
                }
            }
        }
        while( n_top>0 )
        {
            op=stk_o[o_top];
            o_top--;
            a=stk_n[n_top];
            n_top--;
            b=stk_n[n_top];
            stk_n[n_top]=operation(b,a,op); 
        }
        return stk_n[0];        
    }
};

int main()
{
    Equation equ;
    while( cin.getline(buf,sizeof(buf)) )
    {
        cout<<equ.slv2(buf)<<endl;
        cout<<equ.slv(buf)<<endl;        
    }
}
