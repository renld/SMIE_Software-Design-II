/////////////////////////////////////////////////////////////////
//Maximum Flow: DINIC and FORD-FULKERSON Algorithms.
/////////////////////////////////////////////////////////////////
#include <algorithm>//fill, min
#include <queue>

using namespace std;

typedef short NT;//Type of node number.
typedef int FT;//Type of flow.

const int MAX_N = 1000;//Maximum number of Nodes.

struct Edge {
    NT t;  FT c, f;//Towards; Capacity, Flow.
    Edge(NT T = 0, FT C = 0, FT F = 0): t(T), c(C), f(F) {}
};

//I Define the big arrays global to avoid SIGSEGV.
Edge g_adj[MAX_N][MAX_N], *g_mtrx[MAX_N][MAX_N];

//A network model to solve MAXIMUM FLOW problems. After invoking
//any max-flow function, the flow will remain in the graph, other
//invokings will not return right answers until initialization.
class Network {
public:
    Network(Edge (*a)[MAX_N] = g_adj, Edge *(*m)[MAX_N] = g_mtrx)
        :m_adj(a), m_mtrx(m) {}

    //Add an edge from s to t of capacity c. Node index begins
    //from 0. Multiple edges with same (s, t) will be united.
    void addEdge(NT s, NT t, FT c) {
        Edge*& e = m_mtrx[s][t];
        if (!e) { e = &m_adj[s][ m_adjN[s]++ ];  *e = Edge(t, c); }
        else  e->c += c;
        Edge*& r = m_mtrx[t][s];
        if (!r) { r = &m_adj[t][ m_adjN[t]++ ];  *r = Edge(s, 0); }
    }

    //Initialize an network with n nodes.
    void init(NT n) {
        m_n = n;
        fill(m_adjN, m_adjN + m_n, 0);
        for (int i = 0; i < m_n; i++)
            fill( m_mtrx[i], m_mtrx[i] + m_n, (Edge*)0 );
    }

    //Get maximum flow by DNINC algorithm. After invoking, the flow
    //will remain in the graph, and other invokings will not return
    //right answer until initialization.
    FT dinic(NT s, NT t) {
        m_s = s;  m_t = t;
        FT f = 0, f0;
        do { getLvl();  f0 = f;  f += dinicAugment();
        } while (f > f0);
        return f;
    }

    //Get maximum flow by FORD-FULKERSON Algorithm.
    FT ff(NT s, NT t) {
        m_s = s;  m_t = t;
        FT f = 0, f0;
        do { f0 = f;  f += ffAugment(); } while (f > f0);
        return f;
    }

private:
    //Augment the path memorized by m_pr[]. Write the last reachable
    //node from s after augmentation into rch.
    FT augmentPath(NT* rch = NULL) {
        NT v = m_pr[m_t];
        FT f = m_mtrx[v][m_t]->c - m_mtrx[v][m_t]->f;
        while ( -1 != m_pr[v] ) { Edge*& e = m_mtrx[ m_pr[v] ][v];
                                  f = min(f, e->c - e->f);
                                  v = m_pr[v]; }
        if (rch)  *rch = m_t;
        for ( v = m_t; -1 != m_pr[v]; v = m_pr[v] ) {
            Edge*& e = m_mtrx[ m_pr[v] ][v];  e->f += f;
            Edge*& r = m_mtrx[v][ m_pr[v] ];  r->f -= f;
            if (e->f == e->c && rch)  *rch = m_pr[v];
        }
        return f;
    }

    FT dinicAugment() {
        fill(m_pr, m_pr + m_n, -1);
        m_srch[m_s] = -1;
        FT f = 0;
        NT v = m_s;
        while ( m_srch[m_s] < m_adjN[m_s] ) {
            if (m_t == v) { f += augmentPath(&v);  continue; }
            NT v0 = v;
            while ( ++m_srch[v] < m_adjN[v] ) {
                Edge* e = m_adj[v] + m_srch[v];
                if ( m_lvl[v] + 1 == m_lvl[e->t] && e->c > e->f )
                    { m_pr[e->t] = v;  v = e->t;  m_srch[v] = -1;
                      break; }
            }
            if ( v0 == v && -1 != m_pr[v] ) { m_lvl[v] = -1;
                                              v = m_pr[v]; }
        }
        return f;
    }

    FT ffAugment() {
        fill(m_pr, m_pr + m_n, -1);
        queue<NT> q;  q.push(m_s);
        while ( !q.empty() && -1 == m_pr[m_t] ) {
            NT v = q.front();  q.pop();
            for (Edge* e = m_adj[v]; e != m_adj[v] + m_adjN[v]; e++)
                if (m_s != e->t && -1 == m_pr[e->t] && e->c > e->f)
                    { m_pr[e->t] = v;  q.push(e->t); }
        }
        return -1 != m_pr[m_t]? augmentPath(): 0;
    }

    void getLvl() {
        fill(m_lvl, m_lvl + m_n, -1);  m_lvl[m_s] = 0;
        queue<NT> q;  q.push(m_s);
        while ( !q.empty() ) {
            NT v = q.front();  q.pop();
            for (Edge* e = m_adj[v]; e != m_adj[v] + m_adjN[v]; e++)
                if ( -1 == m_lvl[e->t] && e->c > e->f )
                    { m_lvl[e->t] = m_lvl[v] + 1;  q.push(e->t); }
        }
    }

    Edge (*m_adj)[MAX_N];  NT m_adjN[MAX_N];//Adjecent list.
    Edge *(*m_mtrx)[MAX_N];//Adjacent matrix.
    NT m_n, m_s, m_t;//Number of nodes, source, sink.
    NT m_pr[MAX_N];//The previous node in the augment path.
    //For DINIC algorithm:
    NT m_lvl[MAX_N];//Nodes' level in the residual graph.
    NT m_srch[MAX_N];//The last cearched node in DFS.
};

#include <iostream>
int main() {
    Network net;  int n, m, s, t, c;
    while (cin >> n >> m) { net.init(n);
        for (int i = 0; i < m; i++) { cin >> s >> t >> c;
                                      net.addEdge(s, t, c); }
        cin >> s >> t;
        //Choose EITHER of the two functions, but NOT BOTH.
        cout << net.dinic(s, t) << endl;
        //cout << net.ff(s, t) << endl;
    } return 0; } /*Input: 6 10  0 1 16  0 2 13  1 2 10  1 3 12
2 1 4  3 2 9  2 4 14  4 3 7  3 5 20  4 5 4  0 5  Output: 23 */
