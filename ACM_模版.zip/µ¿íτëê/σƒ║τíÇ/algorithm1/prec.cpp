/////////////////////////////////////////////////////////////////
//Output real numbers rounded to specified decimal.
/////////////////////////////////////////////////////////////////
#include <cstdio>//sprintf
#include <cstdlib>//atof
#include <cmath>//fabs, pow

using namespace std;

const double DELTA = 1e-8;

inline bool eq(double a, double b) { return fabs(a - b) < DELTA; }
inline bool lt(double a, double b) { return a < b && !eq(a, b); }
inline bool ge(double a, double b) { return a > b || eq(a, b); }

void prec(double d, int dig) {
    char str[100];
    sprintf(str, "%.16lf", d);
    for (int i = 0; ; i++)  if ( '.' == str[i] )
        { str[i + dig + 1] = '\0';  break; }
    double d2 = atof(str), rem = fabs(d - d2), c = pow(0.1, dig);
    if ( ge(rem, c / 2.0) )  d2 += lt(d, 0.0)? -c: c;
    sprintf(str, "%s%d%s", "%.", dig, "lf");
    if ( eq(d2, 0.0) )  d2 = 0.0;
    printf(str, d2);
}

//Test suite and usage example.
int main() {
    double r;  int d;
    while (scanf("%lf %d", &r, &d)==2) { prec(r,d); printf("\n"); }
    return 0; }
/* Input:  0.00049999999 3  -0.0001 3  1.234 0  -2.3456e-100 3  1 4
   Output: 0.001  0.000  1  0.000  1.0000 */
