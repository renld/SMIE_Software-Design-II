///////////////////intrCrclCnvx() Test Suite/////////////////////
#include "inter-circle-convex.h"
int main() {
    int n;  XY v[100], o, p[200];  Real r;  bool arc[200];
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        cin >> r >> o;
        int m = intrCrclCnvx(o, r, v, n, p, arc);  cout << m;
        for (int i = 0; i < m; i++) cout<<" "<<p[i]<<" "<<arc[i];
        cout << endl; }  return 0;  } /*Input:
3  0 0  1 0  1 1  1  2 2
3  0 3.41421356  0 0  3.41421356 0  1  1 1
3  0 0  2 2  0 4  1  1 2
3  2 0  3 1  2 2  1  1 1
3  3 0  3 2  2 1  1  1 1
3  1 0  5 2  1 4  2  2 2
Output: 0    1 (0, 1) 1    3 (1, 1) 0 (2, 2) 0 (1, 3) 1
1 (2, 1) 1    1 (2, 1) 1
6 (1.27335, 0.136675) 0 (3.92665, 1.46332) 1 (3.92665, 2.53668) 0
  (1.27335, 3.86332) 1 (1, 3.73205) 0 (1, 0.267949) 1 */
