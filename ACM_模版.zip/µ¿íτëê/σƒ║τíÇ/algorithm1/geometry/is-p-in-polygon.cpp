////////////////////isPInPlgn() test suite.//////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n, m;  XY v[100], p;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        cin >> m;
        for (int i = 0; i < m; i++)
            { cin >> p;
              cout << isPInPlgn(p, v, n) << " ";
              cout << isPInPlgn(p, v, n, false) << "  "; }
        cout << endl;  } return 0; }
/*Input: 8  3 0  6 0  6 1  2 2  5 3  2 9  2 4  0 2
         5  2 9  5 2  3 6  4 5  5 0
Output:  1 0  0 0  1 1  1 0  1 0*/
