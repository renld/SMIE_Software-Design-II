///////////////////////leftLine() Test Suite.////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n;  XY v[100], a, b;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        cin >> a >> b;
        leftLine(a, b, v, n);
        cout << n << ":";
        for (int i = 0; i < n; i++)  cout << " " << v[i];
        cout << endl;
    } return 0; }
/*Input: 6  0 2  3 1  5 2  5 3  4 4  1 4    2 2  2 3
         6  0 2  3 1  5 2  5 3  4 4  1 4    1 1  3 2
         6  0 2  3 1  5 2  5 3  4 4  1 4    0 2  5 3
         6  0 2  3 1  5 2  5 3  4 4  1 4    5 4  0 4
         6  0 2  3 1  5 2  5 3  4 4  1 4    6 2  0 0
Output: 4: (0, 2) (2, 1.33333) (2, 4) (1, 4) 
        5: (0, 2) (1.8, 1.4) (5, 3) (4, 4) (1, 4) 
        4: (0, 2) (5, 3) (4, 4) (1, 4) 
        6: (0, 2) (3, 1) (5, 2) (5, 3) (4, 4) (1, 4) 
        1: (3, 1)*/
