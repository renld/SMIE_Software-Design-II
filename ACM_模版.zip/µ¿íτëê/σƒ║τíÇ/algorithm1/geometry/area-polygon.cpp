/////////////////areaPlgn() Test Suite///////////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n;  XY v[100];
    while (cin >> n)
        { for (int i = 0; i < n; i++)  cin >> v[i];
          cout << areaPlgn(v, n) << endl; }
    return 0; } /* Input: 1  0 0    2  1 1  2 2    3  0 0  1 1  2 2
4  0 0  1 0  1 1  0 1    8  0 0  2 1  4 0  3 2  4 4  2 3  0 4  1 2
Output:  0  0  0  1  8*/
