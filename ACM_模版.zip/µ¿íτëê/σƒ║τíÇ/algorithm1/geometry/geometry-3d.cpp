/////////////////////////////////////////////////////////////////////
//3D Geometry
/////////////////////////////////////////////////////////////////////
#include <cmath>//fabs, sqrt

using namespace std;

typedef double Real;

const Real PREC = 1e-8;

struct XYZ;
typedef const XYZ& CXYZ;

inline bool eq(Real a, Real b) { return fabs(a - b) < PREC; }
inline bool lt(Real a, Real b) { return a < b && !eq(a, b); }
inline bool le(Real a, Real b) { return a < b || eq(a, b); }
inline bool gt(Real a, Real b) { return a > b && !eq(a, b); }
inline bool ge(Real a, Real b) { return a > b || eq(a, b); }

//Solving a binary linear system : a1 * x + b1 * y = c1
//                                 a2 * x + b2 * y = c2
//Store the solution in the parameter x and y.
//Return whether there is unique solution.
bool binSys(Real a1, Real b1, Real c1, Real a2, Real b2, Real c2,
            Real& x, Real& y) {
    Real down = a1 * b2 - a2 * b1;
    if ( eq(down, 0.0) ) return false;
    x = (b2*c1 - b1*c2) / down;  y = (a1*c2 - a2*c1) / down;
    return true;
}

inline XYZ crsProd(CXYZ, CXYZ);
inline Real dotProd(CXYZ, CXYZ);
Real dSeg2Seg(CXYZ, CXYZ, CXYZ, CXYZ);
XYZ getPOnIntr(CXYZ, CXYZ, CXYZ, CXYZ, Real);
XYZ intrLine(CXYZ, CXYZ, CXYZ, CXYZ);
bool isLineIntrSeg(CXYZ, CXYZ, CXYZ, CXYZ, bool = true);
bool isSegIntr(CXYZ, CXYZ, CXYZ, CXYZ, bool = true);

//A 3-D point or vector.
struct XYZ {
    Real x, y, z;

    XYZ(Real X = 0.0, Real Y = 0.0, Real Z = 0.0): x(X), y(Y), z(Z) {}

    XYZ operator + (CXYZ v) const { return XYZ(x+v.x, y+v.y, z+v.z); }
    XYZ operator - (CXYZ v) const { return XYZ(x-v.x, y-v.y, z-v.z); }
    XYZ operator / (Real r) const { return XYZ(x / r, y / r, z / r); }
    XYZ operator * (Real r) const { return XYZ(x * r, y * r, z * r); }
    bool operator == (CXYZ p) const
        { return eq(x, p.x) && eq(y, p.y) && eq(z, p.z); }

    //The distance from this point to line (a, b).
    Real d2Line(CXYZ a, CXYZ b) const
        { return crsProd(a - *this, b - *this).norm() / (b-a).norm(); }

    //The shortest distance from this point to segment (a, b).
    Real d2Seg(CXYZ a, CXYZ b) const {
        //If it is a obtuse angle...
        if ( lt( dotProd(b - a, *this - a), 0.0 ) )
            return (*this - a).norm();
        if ( lt( dotProd(a - b, *this - b), 0.0 ) )
            return (*this - b).norm();
        return d2Line(a, b);
    }

    //The distance from this point to a plane, which is given by
    //its normal vector n and an arbitrary point p on it.
    Real d2Pln(CXYZ n, CXYZ p) const { return (*this - p).prjL(n); }

    //Whether this point is on the line (a, b).
    bool isOnLine(CXYZ a, CXYZ b) const
        { XYZ crs = crsProd(a - *this, b - *this);
          return eq(crs.normSqr(), 0.0); }

    //Whether this point is on the segment (a, b).
    bool isOnSeg(CXYZ a, CXYZ b) const {
        if ( *this == a || *this == b )  return true;
        if ( !isOnLine(a, b) )  return false;
        return lt( dotProd(a - *this, b - *this), 0.0 );
    }

    //Whether this point is in the same plane with a convex polygon
    //and inside the polygon. Points on the edges are not inside.
    bool isInCnvx(const XYZ* v, int vN) const {
        XYZ un = crsProd( v[0] - *this, v[1] - *this );
        Real unN = un.norm();
        if ( eq(unN, 0.0) )  return false;
        un = un / unN;
        for (int i = 1; i < vN; i++) {
            XYZ n = crsProd( v[i] - *this, v[ (i+1) % vN ] - *this );
            unN = n.norm();
            if ( eq(unN, 0.0) || !(n / unN == un) )  return false;
        }
        return true;
    }

    //Square of the length of a vector.
    //Sometimes you just want to compare the lengths of two vectors,
    //so you needn't calculate their square roots.
    inline Real normSqr() const { return x * x + y * y + z * z; }

    //Length of a vector.
    inline Real norm() const { return sqrt( normSqr() ); }

    //Length of this vector's projection onto the vector v.
    Real prjL(CXYZ v) const
        { Real n = v.norm();  if ( eq(n, 0.0) )  return 0.0;
          return fabs( dotProd(*this, v) / n ); }

    //Project this vector onto vector v.
    XYZ prj2Vct(CXYZ v) const
        { Real n = v.normSqr();
          if ( eq(n, 0.0) )  return XYZ(0.0, 0.0, 0.0);
          return v * dotProd(*this, v) / n; }

    //Project this point onto a plane, which is given by
    //its normal vector n and an arbitrary point p on it.
    XYZ prj2Pln(CXYZ n, CXYZ p) const
        { return *this + (p - *this).prj2Vct(n); }
};

//Cross product of 3D vectors a and b
inline XYZ crsProd(CXYZ a, CXYZ b)
    { return XYZ(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x); }

inline Real dotProd(CXYZ a, CXYZ b)
    { return a.x * b.x + a.y * b.y + a.z * b.z; }

//Get a point on the intersection of two planes.
//One of the point's x, y, z coordinates is a given constant "c".
//The two planes are determined by their normal verctors n1 and n2,
//and two points p1 and p2 respectively on the two planes.
//Don't input two parallel planes!!!
XYZ getPOnIntr(CXYZ n1, CXYZ p1, CXYZ n2, CXYZ p2, Real c) {
    //Calculate the "d" in the equations of the two planes.
    //The equation of a is ax + by + cz = d,
    //where {a, b, c} is the normal vector.
    Real d1 = n1.x * p1.x + n1.y * p1.y + n1.z * p1.z,
         d2 = n2.x * p2.x + n2.y * p2.y + n2.z * p2.z;
    XYZ v = crsProd(n1, n2), p(c, c, c);
    if ( eq(v.z, 0.0) )
        if ( eq(v.x, 0.0) )
              binSys(n1.x, n1.z, d1 - n1.y * c,
                     n2.x, n2.z, d2 - n2.y * c, p.x, p.z);
        else  binSys(n1.y, n1.z, d1 - n1.x * c,
                     n2.y, n2.z, d2 - n2.x * c, p.y, p.z);
    else      binSys(n1.x, n1.y, d1 - n1.z * c,
                     n2.x, n2.y, d2 - n2.z * c, p.x, p.y);
    return p;
}

Real dSeg2Seg(CXYZ a, CXYZ b, CXYZ c, CXYZ d) {
    XYZ ab = b - a, cd = d - c, n = crsProd(ab, cd),
        a2 = a.prj2Pln(n, c), b2 = b.prj2Pln(n, c);
    if (   a2.isOnSeg(c,d) || b2.isOnSeg(c,d)
        || c.isOnSeg(a2,b2) || d.isOnSeg(a2,b2)
        || isSegIntr(c, d, a2, b2) )  return a.d2Pln(n, c);
    Real r = a.d2Seg(c, d), r2;
    r2 = b.d2Seg(c, d);  if (r2 < r)  r = r2;
    r2 = c.d2Seg(a, b);  if (r2 < r)  r = r2;
    r2 = d.d2Seg(a, b);  if (r2 < r)  r = r2;
    return r;
}

//Intersection of line (a, b) and line (c, d).
//!!!!!!!!!!Don't input two parallel or overlapped lines!!!!!!!!!!
XYZ intrLine(CXYZ a, CXYZ b, CXYZ c, CXYZ d) {
    XYZ ab = b - a, cd = d - c;
    //For the equations of the lines: x = x0 + at, y = y0 + bt, z = z0 + ct,
    //solve a binary linear system to get the two "t"s.
    Real t1, t2;
    if (     !binSys(ab.x, cd.x, c.x - a.x, ab.y, cd.y, c.y - a.y, t1, t2) )
        if ( !binSys(ab.x, cd.x, c.x - a.x, ab.z, cd.z, c.z - a.z, t1, t2) )
              binSys(ab.y, cd.y, c.y - a.y, ab.z, cd.z, c.z - a.z, t1, t2);
    return a + ab * t1;
}

//Whether line (a, b) intersect with segment (c, d). Return false if
//overlap. The parament "bnd" indicates whether it's judged to be
//intersected when the intersection is exactly on point c or d.
bool isLineIntrSeg(CXYZ a, CXYZ b, CXYZ c, CXYZ d, bool bnd) {
    XYZ un1 = crsProd(c - a, b - a), un2 = crsProd(b - a, d - a);
    Real norm1 = un1.norm(), norm2 = un2.norm();
    if ( eq(norm1, 0.0) && eq(norm2, 0.0) )  return false;
    if ( eq(norm1, 0.0) || eq(norm2, 0.0) )  return bnd;
    un1 = un1 / norm1;  un2 = un2 / norm2;
    return un1 == un2;
}

//Whether segment (a, b) intersects with segment (c, d).
//The parament "bnd" indicates whether they are intersected
//when the intersection is exactly on point a, b, c or d.
bool isSegIntr(CXYZ a, CXYZ b, CXYZ c, CXYZ d, bool bnd) {
    if (!bnd)  return    isLineIntrSeg(a, b, c, d, bnd)
                      && isLineIntrSeg(c, d, a, b, bnd);
    XYZ ab = b-a, ac = c-a, ad = d-a, cd = d-c, ca = a-c, cb = b-c,
        ab1 = crsProd(ac, ab), ab2 = crsProd(ab, ad),
        cd1 = crsProd(ca, cd), cd2 = crsProd(cd, cb);
    Real ab1N = ab1.norm(), ab2N = ab2.norm(),
         cd1N = cd1.norm(), cd2N = cd2.norm();
    if ( eq(ab1N, 0.0) && eq(ab2N, 0.0) )
        return    a==c && lt( dotProd(ab,cd), 0.0 )
               || a==d && gt( dotProd(ab,cd), 0.0 )
               || b==c && gt( dotProd(ab,cd), 0.0 )
               || b==d && lt( dotProd(ab,cd), 0.0 );
    ab1 = ab1/ab1N;  ab2 = ab2/ab2N;  cd1 = cd1/cd1N; cd2 = cd2/cd2N;
    return    ( eq(ab1N,0.0) || eq(ab2N,0.0) || ab1 == ab2)
           && ( eq(cd1N,0.0) || eq(cd2N,0.0) || cd1 == cd2);
}

//Test suite. Choose to type the parts you need.
#include <iostream>

istream& operator >> (istream& is, XYZ& p)
    { return is >> p.x >> p.y >> p.z; }
ostream& operator << (ostream& os, CXYZ p)
    { return os << "(" << p.x << ", " << p.y << ", " << p.z << ")"; }

//Test XYZ::isOnSeg()
void testOnSeg() {
    cout << XYZ(0, 0, 0).isOnSeg(XYZ(1, 1, 1), XYZ(-1, -1, -1)) << " ";
    cout << XYZ(1, 1, 1).isOnSeg(XYZ(1, 2, 3), XYZ(0, 0, 0)) << " ";
    cout << XYZ(3, 3, 3).isOnSeg(XYZ(4, 4, 4), XYZ(3, 3, 3)) << " ";
    cout << XYZ(1, 1, 1).isOnSeg(XYZ(2, 2, 2), XYZ(3, 3, 3)) << endl;
    //Correct: 1 0 1 0
}

//Test XYZ::d2Pln() and XYZ::prj2Pln()
void testD2Pln() {
    XYZ pl[][3] = { {XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 1)},
                    {XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 0)},
                    {XYZ(1, 0, 0), XYZ(0, 0, 0), XYZ(0, 0, 1)},
                    {XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 1)} };
    XYZ p[] = {XYZ(0,0,0), XYZ(0, 0, 0.12345), XYZ(99999, 5, 99999),
               XYZ(0.3333333, 0.3333333, 0.3333333) };
    for (int i = 0; i < 4; i++) {
        XYZ crs = crsProd(pl[i][1] - pl[i][0], pl[i][2] - pl[i][0]);
        cout << fixed << p[i].d2Pln(crs, pl[i][0]) << " "
             << p[i].prj2Pln(crs, pl[i][0]) << endl;
    }//Correct: 0.577350 (0.333333, 0.333333, 0.333333)
     //         0.123450 (0.000000, 0.000000, 0.000000)
     //         5.000000 (99999.000000, 0.000000, 99999.000000)
     //         0.000000 (0.333333, 0.333333, 0.333333)
}

//Test getPOnIntr()
void testPOnIntr() {
    XYZ pl[][3] = { { XYZ(1, 4, 7), XYZ(2, 1, 9), XYZ(3, 7, 5) },
                    { XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 1) },
                    { XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 0) },
                    { XYZ(0, 1, 0), XYZ(0, 0, 0), XYZ(0, 0, 1) },
                    { XYZ(1, 0, 0), XYZ(0, 0, 0), XYZ(0, 0, 1) } };
    for (int i = 0; i < 4; i++) {
        XYZ crs1 = crsProd(pl[i][1] - pl[i][0], pl[i][2] - pl[i][0]);
        int j = i + 1;
        XYZ crs2 = crsProd(pl[j][1] - pl[j][0], pl[j][2] - pl[j][0]);
        cout << fixed
             << getPOnIntr(crs1, pl[i][0], crs2, pl[j][0], 1) << " "
             << getPOnIntr(crs1, pl[i][0], crs2, pl[j][0], 5) << endl;
    }//(-13.000000, 13.000000, 1.000000) (-11.000000, 7.000000, 5.000000)
     //(1.000000, 0.000000, 0.000000) (5.000000, -4.000000, 0.000000)
     //(0.000000, 1.000000, 0.000000) (0.000000, 5.000000, 0.000000)
     //(0.000000, 0.000000, 1.000000) (0.000000, 0.000000, 5.000000)
}

//Test XYZ::isInCnvx()
void testInCnvx() {
    XYZ pl[][3] = { { XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 1) },
                    { XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 1) },
                    { XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 0) },
                    { XYZ(1, 0, 0), XYZ(0, 1, 0), XYZ(0, 0, 0) } };
    XYZ p[] = { XYZ(0.3333333, 0.3333333, 0.3333333),
                XYZ(1.0/3.0, 1.0/3.0, 1.0/3.0),
                XYZ(0.5, 0, 0), XYZ(0.5, 0.000001, 0) };
    for (int i=0; i<4; i++) cout << p[i].isInCnvx( pl[i], 3 ) << " ";
    cout << endl;//Correct: 0 1 0 1
}

//Test isLineIntrSeg()
void testLineIntrSeg() {
    bool (*f)(CXYZ, CXYZ, CXYZ, CXYZ, bool) = isLineIntrSeg;
    cout << f(XYZ(0,0,0), XYZ(1,1,1), XYZ(1,1,1), XYZ(2,2,2), true)
         << f(XYZ(0,0,0), XYZ(1,1,1), XYZ(1,1,1), XYZ(2,2,2), false)
         << f(XYZ(2,0,0), XYZ(0,2,2), XYZ(0,0,0), XYZ(1,1,1), true)
         << f(XYZ(2,0,0), XYZ(0,2,2), XYZ(0,0,0), XYZ(1,1,1), false)
         << f(XYZ(1,1,1), XYZ(2,2,2), XYZ(1,0,0), XYZ(0,1,0), true)
         << f(XYZ(1,1,1), XYZ(2,2,2), XYZ(1,0,0), XYZ(0,1,0), false)
         << f(XYZ(0,0,1), XYZ(1,1,0), XYZ(1,0,0), XYZ(0,1,1), true)
         << f(XYZ(0,0,1), XYZ(1,1,0), XYZ(1,0,0), XYZ(0,1,1), false)
         << endl;//Correct: 00100011
}

//Test intrLine()
void testIntrLine() {
    XYZ (*f)(CXYZ, CXYZ, CXYZ, CXYZ) = intrLine;
    cout << fixed
    << f(XYZ(0,0,0), XYZ(1,1,1), XYZ(0,0,1), XYZ(0.5,0.5,0)) << endl
    << f(XYZ(1,0,0), XYZ(2,0,0), XYZ(0,1,0), XYZ(0,2,0)) << endl
    << f(XYZ(2,0,0), XYZ(2,1,1), XYZ(0,0,0), XYZ(1,1,1)) << endl;
    //(0.333333, 0.333333, 0.333333)
    //(0.000000, 0.000000, 0.000000)
    //(2.000000, 2.000000, 2.000000)
}

void testSegIntr() {//Test isSegIntr()
    Real x[]={0,1,2,3,0,3,3},y[]={0,1,2,3,1,1,3},z[]={0,1,2,3,1,1,0};
    XYZ p[7];  for (int i=0;i<7;i++)  p[i] = XYZ(x[i], y[i], z[i]);
    cout << fixed << isSegIntr( p[0], p[1], p[1], p[2] ) << " "
                  << isSegIntr( p[0], p[1], p[1], p[2], false ) << " "
                  << isSegIntr( p[0], p[2], p[1], p[2] ) << " "
                  << isSegIntr( p[3], p[1], p[0], p[3] ) << " "
                  << isSegIntr( p[4], p[1], p[3], p[0] ) << " "
                  << isSegIntr( p[0], p[3], p[4], p[3] ) << " "
                  << isSegIntr( p[0], p[3], p[4], p[3], false ) << " "
                  << isSegIntr( p[0], p[3], p[4], p[5] ) << " "
                  << isSegIntr( p[5], p[0], p[3], p[6] ) << endl;
}//Output: 1 0 0 0 1 1 0 1 0

void testDSeg2Seg() {//Test dSeg2Seg()
    Real x[]={0,1,2,3,0,3,3},y[]={0,1,2,3,1,1,3},z[]={0,1,2,3,1,1,0};
    XYZ p[7];  for (int i=0;i<7;i++)  p[i] = XYZ(x[i], y[i], z[i]);
    cout << fixed << dSeg2Seg( p[3], p[0], p[5], p[4] ) << " "
                  << dSeg2Seg( p[1], p[5], p[3], p[2] ) << " "
                  << dSeg2Seg( p[2], p[1], p[3], p[0] ) << " "
                  << dSeg2Seg( p[0], p[6], p[4], p[5] ) << " "
                  << dSeg2Seg( p[0], p[1], p[2], p[3] ) << endl;
}//Output: 0.000000 1.414214 0.000000 1.000000 1.732051

int main() {
    testOnSeg();
    testD2Pln();
    testPOnIntr();
    testInCnvx();
    testLineIntrSeg();
    testIntrLine();
    testSegIntr();
    testDSeg2Seg();
    return 0;
}
