/////////////////////////////////////////////////////////////////
//Remove repeating vertices and collinear edges on a polygon.
/////////////////////////////////////////////////////////////////
#include "geometry.h"//XY, crsProd, dotProd, sign, <<, >>
#include <algorithm>//copy
void simplify(XY* v, int& n) {
    while ( n > 1 && v[0] == v[n - 1] )  n--;
    XY e, e0 = v[n - 1] - v[0];
    for (int i = n - 1; n > 2 && i >= 0; i--) {
        e = v[ (i+n-1) % n ] - v[i];
        if ( XY(0.0, 0.0) == e ||
             !sign( crsProd(e,e0) ) && sign( dotProd(e,e0) ) > 0 )
            copy(v + i + 1, v + n--, v + i);
        else  e0 = e;
    }
}

//Test suite and usage example:
int main() {
    int n;  XY v[100];
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        simplify(v, n);
        cout << n;
        for (int i = 0; i < n; i++)  cout << " " << v[i];
        cout << endl;
    } return 0; } /* Input: 2  0 0  0 0
6  0 0  1 1  2 2  2 2  1 1  0 0
9  0 0  1 1  2 0  2 1  2 2  2 3  1 2  0 1  0 0
Output: 1 (0, 0)
2 (0, 0) (2, 2)
5 (0, 0) (1, 1) (2, 0) (2, 3) (0, 1) */
