////////////////////cnvxHullCol() Test Suite////////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n;  XY v[100], h[100];
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        int m = cnvxHullCol(v, n, h);  cout << m;
        for (int i = 0; i < m; i++)  cout << " " << h[i];
        cout << endl;
    } return 0; }
/*Input: 18  2 9  1 8  2 8  3 7  3 6  4 5  2 4  5 3 0 2  2 2  5 2
6 1  3 0  5 0  6 0  1.5 1  1 1.3333333333  2 0.6666666666
Output: 13 (3, 0) (5, 0) (6, 0) (6, 1) (5, 3) (4, 5) (3, 7) (2, 9)
(1, 8) (0, 2) (1, 1.33333) (1.5, 1) (2, 0.666667) */
