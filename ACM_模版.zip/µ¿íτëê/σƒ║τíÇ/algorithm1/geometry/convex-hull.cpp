////////////////////cnvxHull() Test Suite////////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n;  XY v[100], h[100];
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        int m = cnvxHull(v, n, h);  cout << m;
        for (int i = 0; i < m; i++)  cout << " " << h[i];
        cout << endl;
    } return 0; }
/*Input: 10  2 2  5 3  2 9  1 4  0 3  3 0  6 0  6 1  5 0  1 2
 Output: 5 (3, 0) (6, 0) (6, 1) (2, 9) (0, 3)*/
