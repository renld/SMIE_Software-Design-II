/////////isLineIntrPlgn() and isSegIntrPlgn() test suite.////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n, m;  XY v[100], a, b;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        cin >> m;
        for (int i = 0; i < m; i++)
            { cin >> a >> b;
              cout << isLineIntrPlgn(a, b, v, n) << " ";
              cout << isLineIntrPlgn(a, b, v, n, false) << " ";
              cout << isSegIntrPlgn(a, b, v, n) << " ";
              cout << isSegIntrPlgn(a, b, v, n, false) << " "; }
        cout << endl;  } return 0; }
/*Input: 5  0 2  2 2  5 3  2 9  2 4
9    1 8  2 8    1 8  2 9    2 4  5 3    0 2  2 2    5 2  3 0
     2 8  3 7    3 6  4 5    3 6  6 1    2 9  2 2
Output: 1 1 1 0  1 0 1 0  1 1 1 1  1 0 1 0  0 0 0 0
        1 1 1 1  1 1 1 1  1 1 1 1  1 1 1 1 */
