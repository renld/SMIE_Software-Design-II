#include "geometry.h"
//Find circle (o, r)'s tangent lines which go through point p. Write
//the two tangent points to array tg and p-->tg[1] is on left of
//p-->tg[0]. p MUST NOT be inside or on border of the circle.
void tngnt(CXY o, Real r, CXY p, XY* tg) {
    XY op = p - o;
    Real d2 = op.normSqr(), r2 = r * r;
    XY v1 = op * r2, v2 = op.perp() * ( r * sqrt(d2-r2) );
    tg[0] = o + (v1 + v2) / d2;  tg[1] = o + (v1 - v2) / d2;
}
