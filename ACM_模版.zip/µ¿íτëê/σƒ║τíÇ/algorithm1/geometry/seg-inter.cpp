////////////////////isSegIntr() Test Suite./////////////////////
#include "geometry.h"
int main() {
    XY a, b, c, d;  int e;
    while (cin>>a>>b>>c>>d>>e) cout<<isSegIntr(a,b,c,d,e)<<endl;
    return 0; }/*Input:
2 1 1 3 1 1 4 2 1    1 1 4 2 2 2 4 2 0    1 1 4 2 2 2 4 2 1
1 4 2 4 4 4 3 4 1    3 4 2 4 3 4 4 4 1    2 1 1 3 2 2 5 3 1
2 1 1 3 3 1 4 3 1    Output: 1 0 1 0 0 0 0*/
