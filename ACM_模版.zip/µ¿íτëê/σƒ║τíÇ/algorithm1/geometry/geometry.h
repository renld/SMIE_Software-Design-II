/////////////////////////////////////////////////////////////////////
//Geometry algorithms.
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <cmath>//fabs, sqrt

using namespace std;

typedef double Real;

const Real DELTA = 1e-8;

struct XY;
typedef const XY& CXY;

inline bool eq(Real a, Real b) { return fabs(a - b) < DELTA; }
inline bool lt(Real a, Real b) { return a < b && !eq(a, b); }
inline bool le(Real a, Real b) { return a < b || eq(a, b); }
inline bool gt(Real a, Real b) { return a > b && !eq(a, b); }
inline bool ge(Real a, Real b) { return a > b || eq(a, b); }

inline char sign(Real r) { return eq(r,0.0)? 0: (r<0.0)? -1: 1; }

inline Real crsProd(CXY, CXY);
inline Real dotProd(CXY, CXY);
Real disLine(CXY, CXY, CXY, CXY);
Real dSeg2Seg(CXY, CXY, CXY, CXY);
Real dSeg2Line(CXY, CXY, CXY, CXY);
XY intrLine(CXY, CXY, CXY, CXY);
int intrCollSeg(CXY, CXY, CXY, CXY, XY*);
int intrLineCrcl(CXY, CXY, CXY, Real, XY*);
int intrCrcl(CXY, Real, CXY, Real, XY*);
bool isLineIntr(CXY, CXY, CXY, CXY);
bool isLineIntrSeg(CXY, CXY, CXY, CXY, bool bnd = true);
bool isSegIntr(CXY, CXY, CXY, CXY, bool bnd = true);
Real triArea(Real, Real, Real);

//A 2-dimensional point or vector.
struct XY {
    Real x, y;

    XY(Real _x = 0.0, Real _y = 0.0): x(_x), y(_y) {}

    XY operator - (CXY p) const { return XY(x - p.x, y - p.y); }
    XY operator + (CXY p) const { return XY(x + p.x, y + p.y); }
    XY operator * (Real d) const { return XY(x * d, y * d); }
    XY operator / (Real d) const { return XY(x / d, y / d); }

    bool operator == (CXY p) const 
        { return eq(x, p.x) && eq(y, p.y); }
    bool operator != (CXY p) const { return !(p == *this); }

    //The distance from this point to line (a, b).
    Real d2Line(CXY a, CXY b) const
        { //Triangle area divided by the base length.
          return fabs( crsProd(a-*this, b-*this) ) / (b-a).norm(); }

    //The shortest distance from this point to segment ab.
    Real d2Seg(CXY a, CXY b) const {//a == b is also OK.
        if ( le( dotProd(b - a, *this - a), 0.0 ) )
            return (*this - a).norm();
        if ( le( dotProd(a - b, *this - b), 0.0 ) )
            return (*this - b).norm();
        return d2Line(a, b);
    }

    //Whether this point is on the line (a, b).
    bool isOnLine(CXY a, CXY b) const
        { return eq(crsProd(a - *this, b - *this), 0.0); }

    //Whether this point is on the segment ab. a==b is valid.
    bool isOnSeg(CXY a, CXY b) const {
        if ( !isOnLine(a, b) )  return false;
        Real minX, maxX, minY, maxY;
        lt(a.x, b.x)? (minX = a.x, maxX = b.x): (minX = b.x, maxX = a.x);
        lt(a.y, b.y)? (minY = a.y, maxY = b.y): (minY = b.y, maxY = a.y);
        return ge(x, minX) && le(x, maxX) && ge(y, minY) && le(y, maxY);
    }

    //Square of the length of a vector.
    //Sometimes you just want to compare the lengths of two vectors,
    //so you needn't calculate their square roots.
    Real normSqr() const { return x * x + y * y; }

    //Length of a vector.
    Real norm() const { return sqrt( normSqr() ); }

    //This vector rotated by 90 degrees COUNTERCLOCKWISE.
    XY perp() const { return XY(-y, x); }

    //Find the symmetric point about line (a, b).
    XY symPoint(CXY a, CXY b)
        { XY intr = intrLine(*this, *this + (b - a).perp(), a, b);
          return intr + (intr - *this); }
};

//Input a point as "x y" by "cin".
istream& operator >> (istream& is, XY& p) { return is>>p.x>>p.y; }
//Print a point as "(x, y)" by "cout".
ostream& operator << (ostream& os, CXY p)
    { return os << "(" << p.x << ", " << p.y << ")"; }

//Cross product of vector a and b
inline Real crsProd(CXY a, CXY b) { return a.x * b.y - b.x * a.y; }
//Dot product of vector a and b
inline Real dotProd(CXY a, CXY b) { return a.x * b.x + a.y * b.y; }

//Distance between line (a, b) and line (c, d).
//Returns 0.0 if they are not parallel.
Real disLine(CXY a, CXY b, CXY c, CXY d) {
    if ( eq(crsProd(b - a, d - c), 0.0) )  return a.d2Line(c, d);
    return 0.0;
}

//The shortest distance between points in segment (a, b) and (c, d).
Real dSeg2Seg(CXY a, CXY b, CXY c, CXY d) {
    if ( isSegIntr(a, b, c, d) )  return 0.0;
    Real d1 = a.d2Seg(c, d), d2 = b.d2Seg(c, d);
    if (d2 < d1)  d1 = d2;
    d2 = c.d2Seg(a, b);  if (d2 < d1)  d1 = d2;
    d2 = d.d2Seg(a, b);  if (d2 < d1)  d1 = d2;
    return d1;
}

//The shortest distance between points in segment (a, b) and line (c, d).
Real dSeg2Line(CXY a, CXY b, CXY c, CXY d) {
    //If they intersect, we need not calculate any more.
    if ( isLineIntrSeg(c, d, a, b) )  return 0.0;
    Real d1 = a.d2Line(c, d), d2 = b.d2Line(c, d);
    if (d2 < d1)  d1 = d2;
    return d1;
}

//Intersection of line (a, b) and line (c, d).
//!!!!!!!!!!Don't input two PARALLEL or OVERLAPPED lines!!!!!!!!!!
XY intrLine(CXY a, CXY b, CXY c, CXY d) {
    Real A1 = a.y - b.y, B1 = b.x - a.x, C1 = a.x * b.y - b.x * a.y,
         A2 = c.y - d.y, B2 = d.x - c.x, C2 = c.x * d.y - d.x * c.y;
    if ( eq(B1, 0.0) )  return XY(a.x, (A2 * a.x + C2) / -B2);
    if ( eq(B2, 0.0) )  return XY(c.x, (A1 * c.x + C1) / -B1);
    return XY( (B1 * C2 - B2 * C1) / (A1 * B2 - A2 * B1),
               (C1 * A2 - C2 * A1) / (A1 * B2 - A2 * B1) );
}

//Intersection of two COLLINEAR SEGMENTS ab and cd. (Unknown result
//for two non-collinear segments). Three possible return values:
//0: No intersection.
//1: One common end point. Write it to p[0].
//2: An overlapped segment. Write its two end points to p[0], p[1].
//a==b or c==d are valid. p[1] may change even not return 2.
int intrCollSeg(CXY a, CXY b, CXY c, CXY d, XY* p) {
    int n1 = 0, n2 = 0;  XY p1[2], p2[2];
    if ( a.isOnSeg(c, d) )  p1[n1++] = a;
    if ( b.isOnSeg(c, d) )  p1[n1++] = b;
    if ( 2 == n1 && p1[0] == p1[1] )  n1--;
    if ( c.isOnSeg(a, b) )  p2[n2++] = c;
    if ( d.isOnSeg(a, b) )  p2[n2++] = d;
    if ( 2 == n2 && p2[0] == p2[1] )  n2--;
    if ( 1 == n1 && 1 == n2 && p1[0] != p2[0] )
        { p[0] = p1[0];  p[1] = p2[0];  return 2; }
    if (n1 > n2) { p[0] = p1[0];  p[1] = p1[1];  return n1; }
    else         { p[0] = p2[0];  p[1] = p2[1];  return n2; }
}

//Find the intersection of line ab and circle (o, r).
//Write the intersections to array p. Returns the number of
//intersections (may be 0, 1 or 2).
int intrLineCrcl(CXY a, CXY b, CXY o, Real r, XY* p) {
    Real d = o.d2Line(a, b);
    if ( gt(d, r) )  return 0;
    int n = 0;
    XY ab = (b - a) / (b - a).norm(),
       mid = intrLine(o, o + ab.perp(), a, b);
    if ( eq(d, r) )  p[n++] = mid;
    else { Real len = sqrt(r * r - d * d);
           p[n++] = mid + ab * len;
           p[n++] = mid - ab * len; }
    return n;
}

//Find the intersections of two circles (a, r) and (b, R).
//Stores the intersections to array p.
//Returns the number of intersections (May be 0, 1 or 2).
int intrCrcl(CXY a, Real r, CXY b, Real R, XY* p) {
    Real dAB = (b - a).norm();
    if ( gt(dAB, r + R) )  return 0;
    int n = 0;
    XY vAB = (b - a) / dAB;
    //Distance from "a" to the mid-point of two intersecions.
    //Using the cosine theorem: cos = (a^2 + b^2 - c^2) / 2ab.
    Real dAM = (r * r + dAB * dAB - R * R) / (2.0 * dAB);
    XY mid = a + vAB * dAM;
    Real len = sqrt(r * r - dAM * dAM);
    if ( eq(len, 0) )  p[n++] = mid;
    else { p[n++] = mid + vAB.perp() * len;
           p[n++] = mid - vAB.perp() * len; }
    return n;
}

//Whether two lines intersect.
//Parallel or overlapped lines are not intersected.
bool isLineIntr(CXY a, CXY b, CXY c, CXY d)
    { return !eq( crsProd(b - a, d - c), 0.0 ); }

//Whether line ab intersect with segment cd. Return FALSE if they
//OVERLAP. Return bnd when the intersection is exactly c or d.
bool isLineIntrSeg(CXY a, CXY b, CXY c, CXY d, bool bnd) {
    char cp1 = sign( crsProd(c-a, b-a) ),
         cp2 = sign( crsProd(b-a, d-a) );
    if (!cp1 && !cp2)  return false;
    if (!cp1 || !cp2)  return bnd;
    return cp1 * cp2 > 0;
}

//Whether segment ab and cd intersect. Return FALSE if they are
//COLLINEAR. Return bnd when the intersection is exactly a,b,c or d.
bool isSegIntr(CXY a, CXY b, CXY c, CXY d, bool bnd)
    { return    isLineIntrSeg(a, b, c, d, bnd)
             && isLineIntrSeg(c, d, a, b, bnd); }

//Use Heron's formula to get the area of a triangle, with it's three edges'
//lengths given.
Real triArea(Real a, Real b, Real c)
    { Real s = (a + b + c) / 2.0;
      return sqrt( s * (s-a) * (s-b) * (s-c) ); }
