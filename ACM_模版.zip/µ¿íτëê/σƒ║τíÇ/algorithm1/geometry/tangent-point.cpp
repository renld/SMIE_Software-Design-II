//////////////Test Suite for tngnt()/////////////////////////////
#include "tangent-point.h"
int main() {
    XY o, p, tg[2];  Real r;
    while (cin >> o >> r >> p)
        { tngnt(o, r, p, tg);
          cout << tg[0] << " " << tg[1] << endl; }
    return 0; } //Input: 1 1 1 2 2    1 1 1 3 1
//Output: (1, 2) (2, 1)    (1.5, 1.86603) (1.5, 0.133975)
