/////////////////////////////////////////////////////////////////
//Algorithms about Polygon.
/////////////////////////////////////////////////////////////////
#include <algorithm>//sort, swap, copy, copy_backward
#include <vector>

const int MAX_VERTEX = 100;
const Real MIN_X = -1000.0;

//A polygon whose points must be in COUNTERCLOCKWISE order.
class Polygon {
public:
    Polygon() { clear(); }

    void add(CXY p) { m_v[m_vN++] = p; }
    void add(const XY* v, int n)
        { for (int i = 0; i < n; i++)  m_v[m_vN++] = v[i]; }
    
    //Make this polygon be the convex hull of points "p". Vertices
    //are sorted in counter clockwise order. All colinear points on
    //one edge will remain.
    void beCnvxHullCo(const XY* p, int n) {
        clear();
        bool used[MAX_VERTEX] = {false};
        vector<TempV> tempV;
        int lowLeft = findLowLeft(p, n), next = lowLeft;
        do {
            add( p[next] );
            used[next] = true;
            int curr = next;
            next = lowLeft;
            tempV = vector<TempV>( 1, TempV(0.0, next) );
            for (int i = 0; i < n; i++) {
                if ( used[i] )  continue;
                Real crs = crsProd( p[i]-p[curr], p[next]-p[curr] ),
                     l = ( p[i] - p[curr] ).normSqr();
                if ( gt(crs, 0.0) )
                    { next = i;
                      tempV = vector<TempV>(1, TempV(l, i)); }
                else if ( eq(crs, 0.0) ) {
                    if ( tempV[0].i == lowLeft )  tempV.clear();
                    next = i;
                    tempV.push_back( TempV(l, i) );
                }
            }
            sort( tempV.begin(), tempV.end() );
            for (int i = 0; i < tempV.size() - 1; i++)
                { add( p[ tempV[i].i ] );
                  used[ tempV[i].i ] = true; }
            next = tempV[ tempV.size() - 1 ].i;
        } while( next != lowLeft );
    }

    void clear() { m_vN = 0; }
    
    void print() const {
        for (int i = 0; i < m_vN; i++) {
            cout << "(" << m_v[i].x << ", " << m_v[i].y << ")";
            if (i < m_vN - 1)  cout << ", ";
            else  cout << endl; 
        }
    }

private:
    struct TempV {//For the function beCnvxHullCo().
        Real l; int i;
        TempV(Real L, int I): l(L), i(I) {}
        bool operator < (const TempV& t) const { return lt(l, t.l); }
    };

    //Find the lowest and leftest point. Return its index in the array.
    int findLowLeft(const XY* p, int n) {
        int r = 0;
        for (int i = 1; i < n; i++)
            if (   lt( p[i].y, p[r].y )
                || eq( p[i].y, p[r].y ) && lt( p[i].x, p[r].x )
               )  r = i;
        return r;
    }

    XY m_v[MAX_VERTEX];//Vertices
    int m_vN;//Number of vertices
};
 
//Area of a simple polygon in COUNTERCLOCKWISE order.
Real areaPlgn(const XY* v, int n) {
    if (n < 3)  return 0.0;
    Real a = 0.0;  XY e, e0 = v[1] - v[0];
    for (int i = 2; i < n; i++, e0 = e)
        a += crsProd( e0, e = v[i] - v[0] );
    return a / 2.0;
}

//Whether point p is inside CONVEX polygon (v, n). Vertices should
//be in COUNTERCLOCKWISE order. Return bnd if p is on border.
//n = 1, 2, 3 and > 3 are all OK.
bool isPInCnvx(CXY p, const XY* v, int n, bool bnd = true) {
    XY v0 = v[n - 1], v1;
    for (int i = 0; i < n; i++, v0 = v1)
        { v1 = v[i];
          if ( p.isOnSeg(v0, v1) )  return bnd;
          if ( sign ( crsProd(v1-v0, p-v0) ) <= 0 )  return false; }
    return true;
}

//Whether point p is inside polygon (v, n). Vertices should be in
//COUNTERCLOCKWISE order. Return bnd if p is on border.
bool isPInPlgn(CXY p, const XY* v, int n, bool bnd = true) {
    XY far(-20000.0, p.y);
    int m = 0;
    for (int i = 0; i < n; i++) {
        CXY a = v[i], b = v[ (i + 1) % n ];
        if ( p.isOnSeg(a, b) )  return bnd;
        if ( !eq(a.y, b.y) )
            if      ( a.isOnSeg(far, p) ) { if (a.y > b.y)  m++; }
            else if ( b.isOnSeg(far, p) ) { if (b.y > a.y)  m++; }
            else if ( isSegIntr(a, b, far, p) )  m++;
    }
    return m % 2 != 0;
}

//Whether line ab intersects polygon (v, n). Return bnd if they only
//intersect on border. Vertices must be in COUNTERCLOCKWISE order.
bool isLineIntrPlgn(CXY a, CXY b, const XY* v, const int n,
                bool bnd = true) {
    XY it[n];  int itN = 0;
    for (int i = 0; i < n; i++) {
        CXY p1 = v[i], p2 = v[ (i + 1) % n ];
        if ( isLineIntrSeg(a, b, p1, p2) ) {
            if (bnd)  return true;
            it[itN++] = intrLine(a, b, p1, p2);
        }
    }
    for (int i = 0; i < itN; i++)
        for (int j = i + 1; j < itN; j++)
            if ( isPInPlgn( ( it[i]+it[j] )/2.0, v, n, false ) )
                return true;
    return false;
}

//Whether segment ab intersects polygon (v, n). i.e. is there any
//point of the segment INSIDE the polygon. Vertices must be in
//COUNTERCLOCKWISE order. Return bnd if they intersect only on
//border.
bool isSegIntrPlgn(CXY a, CXY b, const XY* v, const int n,
               bool bnd = true) {
    if (    isPInPlgn(a, v, n, bnd)
         || isPInPlgn(b, v, n, bnd) ) return true;
    XY it[n];  int itN = 0;
    for (int i = 0; i < n; i++) {
        CXY p1 = v[i], p2 = v[ (i + 1) % n ];
        if ( isSegIntr(a, b, p1, p2) ) {
            if (bnd)  return true;
            it[itN++] = intrLine(a, b, p1, p2);
        }
    }
    for (int i = 0; i < itN; i++)
        for (int j = i + 1; j < itN; j++)
            if ( isPInPlgn( ( it[i]+it[j] )/2.0, v, n, false ) )
                return true;
    return false;
}

//Whether segment ab intersects polygon (v, n). i.e. is there any
//point of the segment INSIDE the polygon. Vertices must be in
//COUNTERCLOCKWISE order. Return bnd if they intersect only on
//border. DON'T input a NON-CONVEX polygon.
bool isSegIntrCnvx(CXY a, CXY b, const XY* v, const int n,
                   bool bnd = true) {
    if (   isPInCnvx(a, v, n, bnd)
        || isPInCnvx(b, v, n, bnd) )  return true;
    XY it[n];  int itN = 0;
    for (int i = 0; i < n; i++) {
        CXY v1 = v[i], v2 = v[ (i + 1) % n ];
        if ( isSegIntr(a, b, v1, v2) )
            { if (bnd)  return true;
              it[itN++] = intrLine(a, b, v1, v2); }
    }
    if (itN >= 3)  return true;
    if (itN <= 1)  return false;
    return isPInCnvx( (it[0]+it[1]) / 2.0, v, n, false );
}

//Remove the elements a[s] ~ a[t - 1] in array "a" of length n.
void arrayRm(XY* a, int& n, int s, int t)
    { int d = t-s;  if (d>0)  copy(a+t, a+n, a+s);  n -= d; }
//Insert an element v before a[i].
void arrayIns(XY* a, int& n, int i, CXY v)
    { copy_backward(a+i, a+n, a+n+1);  n++;  a[i] = v; }

//Find the intersection of the CONVEX polygon (v, n) and the LEFT
//HALF PLANE of line a-->b. Points on edges are also regarded as
//parts of polygons. Write the result into (v, n). Both input and
//output polygon are in COUNTERCLOCKWISE order. Polygon with only
//one or two vertices is also valid. But DON'T input polygon with
//repeating vetices or collinear edges!
void leftLine(CXY a, CXY b, XY* v, int& n) {
    int rS, rT;//The first and last vertex to be removed.
    bool isNewRT = false, isNewRS = false,
         isL = false, isR = false, isOn = false;
    XY newRT, newRS;
    char sv, sv0 = sign( crsProd( b-a, v[n-1]-a ) );
    for (int i = 0, i0 = n-1; i < n; i0 = i, sv0 = sv, i++) {
        sv = sign( crsProd( b-a, v[i]-a ) );
        if (sv > 0) { isL = true;
            if (sv0 < 0) { rT = i0;  isNewRT = true;
                newRT = intrLine( v[i], v[i0], a, b ); } }
        else if (!sv) { isOn = true;  if (sv0 < 0)  rT = i0; }
        else { isR = true;
            if (sv0 > 0) { rS = i;  isNewRS = true;
                           newRS = intrLine( v[i], v[i0], a, b ); }
            else if (!sv0)  rS = i; }
    }
    if (!isR)  return;
    if (!isL && !isOn) { n = 0;  return; }
    if (isNewRS && isNewRT && newRS == newRT)  isNewRT = false;
    if (isNewRS && isNewRT && rS == rT)
        { v[rS] = newRS;  arrayIns(v, n, rS+1, newRT); }
    else{ if (isNewRS)  v[rS++] = newRS;
          if (isNewRT) { v[rT] = newRT;  rT = (rT + n - 1) % n; }
          if (rS <= rT + 1)  arrayRm(v, n, rS, rT + 1);
          else { arrayRm(v, n, rS, n);  arrayRm(v, n, 0, rT + 1); } }
}

//Find the FARTHEST PAIR of vertices in a CONVEX polygon with
//ROTATING CALIPER algorithm. The polygon is represented by (v, n)
//in COUNTERCLOCKWISE order. Write the answers in to "a" and "b".
void farthest(XY* v, int n, XY*& a, XY*& b) {
    if (n <= 2) { a = &v[0];  b = &v[n - 1];  return; }
    XY s = v[1] - v[0], clp1 = s, clp2, ci, cj;
    int i = 1, j = 2;
    Real d = v[j].d2Line( v[0], v[1] ), d2;
    for (j = 3; j < n; j++) { d2 = v[j].d2Line( v[0], v[1] );
                              if ( lt(d2, d) )  break;
                              d = d2; }  j--;
    a = &v[i];  b = &v[j];  d = (*b - *a).normSqr();
    while ( le( crsProd(clp1, s), 0.0 ) ) {
        ci = v[ (i+1) % n ] - v[i];  cj = v[ (j+1) % n ] - v[j];
        if ( lt( crsProd(ci, cj), 0.0 ) )
             { clp1 = ci;  i = (i + 1) % n;  clp2 = clp1 * -1.0; }
        else { clp2 = cj;  j = (j + 1) % n;  clp1 = clp2 * -1.0; }
        d2 = ( v[i] - v[j] ).normSqr();
        if ( gt(d2, d) )  { d = d2;  a = &v[i];  b = &v[j]; }
    }
}

void psSub(const XY* v, int n, CXY o, XY* out) {
    if (n <= 0)  return;
    if (1 == n) { out[0] = v[0];  return; }
    const int lN = n / 2, rN = n - lN;
    int i = 0, l = 0, r = 0;
    XY lA[lN], rA[rN];
    psSub(v, lN, o, lA);  psSub(v + lN, rN, o, rA);
    while (l < lN && r < rN) {
        CXY a = lA[l] - o,  b = rA[r] - o;
        char s = sign( crsProd(a, b) );
        if (    !s && lt( a.normSqr(), b.normSqr() )
             || s > 0 )  out[i++] = lA[l++];
        else             out[i++] = rA[r++];
    }
    while (l < lN)  out[i++] = lA[l++];
    while (r < rN)  out[i++] = rA[r++];
}

//MERGE Sort the point set by COUNTERCLOCKWISE POLAR ANGLE order
//based on the LOWEST and LEFTMOST point O. Points with same polar
//angles are sort by the distances from O in ascending order.
//Time: O(n * log n)
void polarSort(XY* p, const int n) {
    int o = 0;
    for (int i = 1; i < n; i++)
        if (    eq( p[i].y, p[o].y ) && lt( p[i].x, p[o].x )
             || lt( p[i].y, p[o].y ) )  o = i;
    if (0 != o)  swap( p[0], p[o] );
    XY out[n - 1];
    psSub(p + 1, n - 1, p[0], out);
    copy(out, out + n - 1, p + 1);
}

//Find the CONVEX HULL of the point set (v, n), and write the answer
//into "out", return the number of vertices. The vertices of the hull
//are in COUNTERCLOCKWISE order. The original point set will be sorted
//by POLAR ANGLEs.
int cnvxHull(XY* v, int n, XY* out) {
    if (1 == n) { out[0] = v[0];  return 1; }
    polarSort(v, n);
    out[0] = v[0];  out[1] = v[1];
    int m = 2;
    for (int i = 2; i < n; i++)
        { while ( m > 1 && sign(crsProd( v[i] - out[m-1],
                                out[m-1] - out[m-2] )) >= 0 )  m--;
          out[m++] = v[i]; }
    return m;
}

//Find the CONVEX HULL of the point set (v, n). All colinear points
//on edges will remain. Write the answer into "out", return the
//number of vertices. The vertices of the hull are in
//COUNTERCLOCKWISE order. The original point set will be sorted
//by POLAR ANGLEs.
int cnvxHullCol(XY* v, int n, XY* out) {
    if (1 == n) { out[0] = v[0];  return 1; }
    polarSort(v, n);
    for (int i = 0; i < n; i++)  cout << v[i] << " ";
    cout << endl;
    int i = n - 2;
    while ( i > 0 && v[i].isOnSeg(v[0], v[n - 1]) )  i--;
    reverse(v + i + 1, v + n);
    out[0] = v[0];  out[1] = v[1];
    int m = 2;
    for (i = 2; i < n; i++)
        { while ( m > 1 && sign(crsProd( v[i] - out[m-1],
                                out[m-1] - out[m-2] )) > 0 )  m--;
          out[m++] = v[i]; }

    return m;
}
