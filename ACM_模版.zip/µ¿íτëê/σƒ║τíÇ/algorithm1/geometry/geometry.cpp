////////////////////Geometry Test Suite.////////////////////////
#include "geometry.h"
#include "polygon.h"
//Test suite and usage examples. Choose to type the parts you
//want to use, which are separated by comments.
int main() {
    //Initialization part, which you must type.
    //Index:      0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
    Real x[15] = {2, 1, 2, 3, 3, 4, 2, 5, 0, 2, 5, 6, 3, 5, 6};
    Real y[15] = {9, 8, 8, 7, 6, 5, 4, 3, 2, 2, 2, 1, 0, 0, 0};
    XY p[15];
    for (int i = 0; i < 15; i++)  p[i] = XY(x[i], y[i]);
    XY intr[2];
    int cnt;
    Polygon hull;

    //Whether a point is on a segment.
    cout << p[5].isOnSeg(p[3], p[11]) << " ";
    cout << p[0].isOnSeg(p[0], p[1]) << " ";
    cout << p[0].isOnSeg(p[0], p[0]) << " ";
    cout << p[0].isOnSeg(p[1], p[2]) << endl;//correct: 1 1 1 0

    //Intersection of lines.
    cout << intrLine(p[0],p[2], p[1], p[2]) << " ";
    cout << intrLine(p[5],p[9], p[6], p[7]) << endl;
    //correct: (2, 8) (3.09091, 3.63636)
    
    //Distance from point to line.
    cout << p[0].d2Line(p[3], p[5]) << " ";
    cout << p[6].d2Line(p[8], p[9]) << endl;//correct: 0 2

    //Intersections of line and circle.
    cnt = intrLineCrcl(p[0], p[1], p[9], 1, intr);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) { cout << intr[i] << " "; }
    cnt = intrLineCrcl(p[2], p[9], p[5], 2, intr);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) { cout << intr[i] << " "; }
    cnt = intrLineCrcl(p[6], p[9], p[7], 4, intr);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) { cout << intr[i] << " "; }
    cout << endl;//correct: 0 1 (2, 5) 2 (2, 0.354249) (2, 5.64575)

    //Intersections of two circles.
    cnt = intrCrcl(p[0], 1, p[9], 1, intr);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) { cout << intr[i] << " "; }
    cnt = intrCrcl(p[0], 3, p[6], 2, intr);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) { cout << intr[i] << " "; }
    cnt = intrCrcl(p[0], 1, p[2], 1, intr);
    cout << cnt << " ";
    for (int i = 0; i < cnt; i++) { cout << intr[i] << " "; }
    cout << endl;//correct: 0 1 (2, 6) 2 (2.86603, 8.5) (1.13397, 8.5)

    //Shortest distance of two segments.
    cout << dSeg2Seg(p[0], p[1], p[1], p[2]) << " ";
    cout << dSeg2Seg(p[3], p[4], p[5], p[7]) << " ";
    cout << dSeg2Seg(p[6], p[9], p[5], p[7]) << endl;
    //correct: 0 1.41421 2.23607

    //Shorest distance of a segment and a line.
    cout << dSeg2Line(p[0], p[1], p[1], p[2]) << " ";
    cout << dSeg2Line(p[6], p[9], p[5], p[7]) << endl;//correct: 0 2.23607

    //Distance of two lines.
    cout << disLine(p[0], p[1], p[1], p[2]) << " ";
    cout << disLine(p[0], p[3], p[2], p[4]) << " ";
    cout << disLine(p[0], p[3], p[5], p[7]) << endl;//corrent: 0 0.447214 0

    //Triangle area.
    cout << triArea(1, 2, 3) << " " << triArea(3, 4, 5) << " ";
    cout << triArea(2, 3, 2) << endl;//correct: 0 6 1.98431

    //Symmetric point about a line.
    cout << p[6].symPoint(p[7], p[9]) << " ";
    cout << p[1].symPoint(p[6], p[0]) << " ";
    cout << p[3].symPoint(p[0], p[5]) << endl;
    //correct: (3.2, 0.4) (3, 8) (3, 7)
    return 0;
}
