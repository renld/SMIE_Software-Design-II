////////////////////polarSort() Test Suite////////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n;  XY v[100], *a, *b;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        polarSort(v, n);
        for (int i = 0; i < n; i++)  cout << v[i] << " ";
        cout << endl;
    } return 0; }
/*Input: 9  2 2  5 3  2 9  1 4  0 2  3 0  6 0  6 1  5 0
Out: (3, 0) (5, 0) (6, 0) (6, 1) (5, 3) (2, 9) (2, 2) (1, 4) (0, 2)*/
