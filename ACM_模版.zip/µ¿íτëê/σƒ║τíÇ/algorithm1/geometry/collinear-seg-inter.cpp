////////////////////IntrCollSeg() Test Suite/////////////////////
#include "geometry.h"
int main() {
    XY a, b, c, d, p[2];
    while (cin >> a >> b >> c >> d) {
        int n = intrCollSeg(a, b, c, d, p);
        cout << n << " ";
        for (int i = 0; i < n; i++)  cout << p[i] << " ";
        cout << endl;
    }  return 0; }/*Input: 6 5 4 4 0 2 2 3    0 1 4 1 1 1 3 1
      0 1 3 1 5 1 1 1    4 4 6 5 4 4 0 2    1 1 5 1 3 1 5 1
      0 1 5 1 5 1 0 1    4 4 2 3 0 2 6 5    1 1 1 1 1 1 1 1
      Output: 0     2 (1, 1) (3, 1)    2 (3, 1) (1, 1) 
       1 (4, 4)     2 (3, 1) (5, 1)    2 (5, 1) (0, 1)
       2 (4, 4) (2, 3)    1 (1, 1)*/
