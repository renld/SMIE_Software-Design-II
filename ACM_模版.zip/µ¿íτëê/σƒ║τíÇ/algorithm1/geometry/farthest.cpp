////////////////////farthest() Test Suite////////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n;  XY v[100], *a, *b;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        farthest(v, n, a, b);
        cout << *a << " " << *b << endl;
    } return 0; }
/*Input: 5  0 3  3 0  10 0  12 3  5 8
  Output: (12, 3) (0, 3)*/
