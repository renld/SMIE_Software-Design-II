/////////////////////////////////////////////////////////////////
//Intersection of a CIRCLE and a CONVEX POLYGON.
/////////////////////////////////////////////////////////////////
#include "geometry.h"//XY, intrCollSeg, intrLineCrcl
#include "polygon.h"//areaPlgn, <algorithm> (swap, copy)
                    //<cmath> (acos)

const Real PI = acos(-1.0);

inline void addV(XY* v, bool* arc, int& n, CXY p, bool flag)
    { if ( n && p == v[n - 1] )  n--;
      if ( !n || p != v[0] && ( !flag || !arc[n-1] ) )
          { v[n]=p;  arc[n++]=flag; } }

//Get the intersection of CIRCLE (o, r) and CONVEX POLYGON (v, n).
//Write vertices of the answer (a CIRCULAR polygon) to array p.
//Write to array arc whether edge p[i]-->p[i+1] is an ARC. Return
//the number of vertices in answer. The input polygon and answer are
//both in COUNTERCLOCKWISE order. DON'T input r <= 0 or n < 3.
int intrCrclCnvx(CXY o, Real r, const XY* v, int n,
                 XY* p, bool* arc) {
    int m = 0;  XY temp[2], intr[2], &c = intr[0], &d = intr[1];
    bool oIn = true;
    for (int i = 0; i < n; i++) {
        CXY a = v[i], b = v[ (i + 1) % n ];
        if ( sign( crsProd(o - a, b - a) ) > 0 )  oIn = false;
        int iN = intrLineCrcl(a, b, o, r, intr);
        if (!iN)  continue;
        if (1 == iN)  d = c;
        if ( sign( dotProd(b - a, d - c) ) < 0 )  swap(c, d);
        if ( !intrCollSeg(a, b, c, d, temp) )  continue;
        addV(p, arc, m, c.isOnSeg(a, b)? c: a, false);
        if ( d != b && d.isOnSeg(a, b) )  addV(p, arc, m, d, true);
    }
    if (!m && oIn)  addV(p, arc, m, o + XY(r, 0), true);
    if ( m > 1 && arc[0] && arc[m - 1] )
        { copy(p + 1, p + m, p);  copy(arc + 1, arc + m--, arc); }
    return m;
}

Real areaArc(CXY o, Real r, CXY a, CXY b) {
    Real ang = acos( dotProd(a-o, b-o) / (r*r) ),
         as = ang * r * r / 2.0,//sector area
         at = crsProd(a - o, b - o) / 2.0;//triangle area
    return ( sign(at) >= 0 )? (as - at): (PI*r*r - as - at);
}

//Area of the intersection of a CIRCLE (o, r) and CONVEX POLYGON.
//oIn indicates wether o is inside the origin polygon. (v, arc, n)
//is an answer from intrCrclCnvx().
Real areaCrclCnvx(CXY o, Real r, bool oIn,
                  const XY* v, const bool* arc, int n) {
    if (n < 2)  return (1==n && oIn) ? PI*r*r : 0.0;
    Real a = areaPlgn(v, n);
    for (int i = 0; i < n; i++)
        if ( arc[i] )  a += areaArc( o, r, v[i], v[ (i+1)%n ] );
    return a;
}
