/////////////////////////////////////////////////////////////////
//Intersection of two CONVEX POLYGONs.
/////////////////////////////////////////////////////////////////
//Need these things from geometry.h: XY, isSegIntr, intrCollSeg,
//intrLine, <<, >>
#include "geometry.h"
#include "polygon.h"//isPInCnvx, <algorithm>(copy)

using namespace std;

inline void addV(XY* v, int& n, CXY a)
    { if ( !n || a != v[n - 1] && a != v[0] )  v[n++] = a; }

inline char whichIn(char ori, char si1, char si2)
    { return si1 > 0? 1: (si2 > 0? 2: ori); }

//Get intersection of two CONVEX POLYGONs. Write the answer into
//array "v" and return the number of vertices. The two polygons,
//(v1, n1) and (v2, n2), and the answer are all in COUNTERCLOCKWISE
//order. Don't input n1, n2 < 2!!! But the return value may be 0
//(no intersection), 1(single point), 2(segment) or >2 (polygon).
int intrCnvx(const XY* v1, int n1, const XY* v2, int n2, XY* v) {
    int i1 = 0, i2 = 0, d1 = 0, d2 = 0, n = 0;
    bool first = true;//Whether this is the fisrt vertex of answer.
    char inside = 0;//Which edge is inside, 1 or 2. 0 for UNKNOWN.
    do {
        const XY &a1 = v1[ (i1 + n1 - 1) % n1 ], &b1 = v1[i1],
                 &a2 = v2[ (i2 + n2 - 1) % n2 ], &b2 = v2[i2];
        XY e1 = b1 - a1, e2 = b2 - a2;//Two edges: a1b1 and a2b2.
        char se = sign( crsProd(e1,e2) ),//Whether e2 is left to e1.
             si1 = sign( crsProd(e2, b1-a2) ),//Whether i1 is left to
             si2 = sign( crsProd(e1, b2-a1) );//e2, i2 is left to e1.
        if ( isSegIntr(a1, b1, a2, b2) ) {
            if (!inside && first) { d1 = d2 = 0;  first = false; }
            addV(v, n, intrLine(a1, b1, a2, b2) );
            inside = whichIn(inside, si1, si2);
        }
        if (!se && !si1 && lt( dotProd(e1, e2), 0.0 ) ) {
            XY p[2];  int pn = intrCollSeg(a1, b1, a2, b2, p);
            if (pn) { for (int i=0; i<pn; i++)  addV( v, n, p[i] );
                      return n; }
            else  return n;
        }
        if (!se && si1 < 0 && si2 < 0)  return n;
        if (!se && !si1)  if (1==inside) { i2=(i2+1) % n2;  d2++; }
                          else           { i1=(i1+1) % n1;  d1++; }
        else if (se >= 0)
             if (si2 > 0) { i1 = (i1 + 1) % n1;  d1++;
                            if (1 == inside)  addV(v, n, b1); }
             else         { i2 = (i2 + 1) % n2;  d2++;
                            if (2 == inside)  addV(v, n, b2); }
        else if (si1 > 0) { i2 = (i2 + 1) % n2;  d2++;
                            if (2 == inside)  addV(v, n, b2); }
             else         { i1 = (i1 + 1) % n1;  d1++;
                            if (1 == inside)  addV(v, n, b1); }
    } while ( (d1 < n1 || d2 < n2) && d1 < 2*n1 && d2 < 2*n2 );
    if (!n)  if      ( isPInCnvx( v1[0], v2, n2 ) )
                 { copy(v1, v1 + n1, v);  n = n1; }
             else if ( isPInCnvx( v2[0], v1, n1 ) )
                 { copy(v2, v2 + n2, v);  n = n2; }
    return n;
}

//Test suite and usage example.
int main() {
    int n1, n2, n;  XY v1[100], v2[100], v[100];
    while (cin >> n1) {
        for (int i = 0; i < n1; i++)  cin >> v1[i];
        cin >> n2;
        for (int i = 0; i < n2; i++)  cin >> v2[i];
        n = intrCnvx(v1, n1, v2, n2, v);
        cout << n;  for (int i=0; i<n; i++)  cout << " " << v[i];
        cout << endl;
    } return 0; } /* Input:
10  0 16  5 8  13 0  19 2  24 10  24 26  19 29  13 32  7 32  3 29
5  16 -3  28 16  16 32  0 22  3 10

6  3 0  6 0  8 2  6 4  3 4  1 2    5  2 0  6 0  9 1  6 4  0 4
4  1 0  3 0  3 4  1 4    4  0 5  0 1  3 1  3 5
4  0 0  1 0  1 1  0 1    4  1 1  0 1  0 0  1 0
4  0 0  3 0  3 3  0 3    4  1 1  2 1  2 2  1 2
4  0 0  1 0  1 1  0 1    4  2 2  3 2  3 3  2 3
3  0 0  1 1  0 1    2  1 0  0 1
2  0 0  2 0    2  2 0  1 0

Output: 10 (5, 8) (13, -0) (19, 2) (24, 10) (24, 21.3333)
           (17.8, 29.6) (14.6667, 31.1667) (1.61798, 23.0112)
           (0.72, 19.12) (2.5, 12)
        6 (1, 2) (3, -0) (6, -0) (8, 2) (6, 4) (3, 4)
        4 (1, 1) (3, 1) (3, 4) (1, 4)
        4 (1, -0) (1, 1) (0, 1) (0, -0)
        4 (1, 1) (2, 1) (2, 2) (1, 2)
        0
        2 (0, 1) (0.5, 0.5)
        2 (1, 0) (2, 0) */
