////////////////////isSegIntrCnvx() test suite.//////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n, m;  XY v[100], a, b;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        cin >> m;
        for (int i = 0; i < m; i++)
            { cin >> a >> b;
              cout << isSegIntrCnvx(a, b, v, n) << " ";
              cout << isSegIntrCnvx(a, b, v, n, false) << " "; }
        cout << endl;  } return 0; }
//Input: 5  3 0  5 2  5 3  2 9  2 2
//9  2 9  5 2    2 4  5 2    5 0  5 2    5 3  5 2    5 0  1 8
//   3 6  2 9    1 8  3 6    1 8  2 8    5 0  6 0
//Output: 1 1 1 1 1 0 1 0 1 1 1 1 1 1 1 0 0 0
