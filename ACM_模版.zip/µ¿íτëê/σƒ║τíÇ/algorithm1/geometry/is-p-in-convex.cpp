////////////////////isPInCnvx() test suite.//////////////////////
#include "geometry.h"
#include "polygon.h"
int main() {
    int n, m;  XY v[100], p;
    while (cin >> n) {
        for (int i = 0; i < n; i++)  cin >> v[i];
        cin >> m;
        for (int i = 0; i < m; i++)
            { cin >> p;
              cout << isPInCnvx(p, v, n) << " ";
              cout << isPInCnvx(p, v, n, false) << " "; }
        cout << endl;  } return 0; }
/*Input: 5  2 9  2 2  3 0  5 2  5 3    4  0 2  3 6  4 5  2 9
         1  0 0    3  0 0  1 1  1 0
         2  0 0  2 2    7  1 1  3 3  -1 -1  1 0  0 1  0 0  2 2
Output:  0 0  1 1  1 0  1 0
         1 0  0 0  0 0
         1 0  0 0  0 0  0 0  0 0  1 0  1 0 */
