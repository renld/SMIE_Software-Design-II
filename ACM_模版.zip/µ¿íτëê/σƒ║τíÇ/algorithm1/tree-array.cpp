/////////////////////////////////////////////////////////////////////
//Tree Array.
/////////////////////////////////////////////////////////////////////
using namespace std;

const int BOUND = 1000;

//Array for the tree array. Too big to define in the class.
int m_tree[BOUND + 1];
int m_range[BOUND + 1];

class TreeArray {
public:
    TreeArray(int bound = BOUND) {
        for (int i = 0; i <= BOUND; i++)
            { m_range[i] = (i + 1) & ((i + 1) ^ i); }
        init(bound);
    }

    //Initialize a tree array of range [0, bound].
    void init(int bound) {
        m_bound = bound;
        for (int i = 0; i <= m_bound; i++) { m_tree[i] = 0; }
    }
    
    //Add value v at index i.
    void add(int i, int v) {
        if (i < 0) { return; }
        while (i <= m_bound) { m_tree[i] += v;  i += m_range[i]; }
    }

    //Get the value in the range[0, i].
    int getValue(int i) {
        int v = 0;
        i = i <= m_bound? i: m_bound;
        while (i >= 0) { v += m_tree[i];  i -= m_range[i]; }
        return v;
    }

private:
    int m_bound;
};

//Test suite.
#include <iostream>

int main() {
    TreeArray tree(20);
    int add[8][2] = {{6, 1}, {8, 5}, {16, 2}, {20, 7},
                     {13, 4}, {14, 6}, {10, 2}, {11, 3}};
    int del[4][2] = {{5, 0}, {11, -3}, {14, -5}, {20, -7}};
    for (int i = 0; i < 8; i++) tree.add(add[i][0], add[i][1]);
    for (int i = 0; i <= 20; i++) cout << tree.getValue(i) << " ";
    cout << endl;
    for (int i = 0; i < 4; i++) tree.add(del[i][0], del[i][1]);
    for (int i = 0; i <= 20; i++) cout << tree.getValue(i) << " ";
    cout << endl;
    //output: 0 0 0 0 0 0 1 1 6 6 8 11 11 15 21 21 23 23 23 23 30 
    //        0 0 0 0 0 0 1 1 6 6 8 8 8 12 13 13 15 15 15 15 15
    return 0;
}
