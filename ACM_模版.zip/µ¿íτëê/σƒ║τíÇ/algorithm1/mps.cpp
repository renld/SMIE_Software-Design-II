/////////////////////////////////////////////////////////////////////
//Find k shortest paths (cycle allowed) by MPS algorithm.
//Multiple edges between same pair of vertices are allowed.
/////////////////////////////////////////////////////////////////////
#include <cstring>//memset().
#include <queue>//priority_queue in the A*. <vector> also included.
#include <functional>//greater().
#include <algorithm>//sort().
#include <list>//As a queue in the BFS.

using namespace std;

typedef short VT;//The type of vertex numbers.
typedef int LT;//The type of lengths of edges.

const VT MAX_VER = 1000 + 50;
const LT MAX_LEN = 99999999;

struct Edge;
typedef const Edge* CEP;

struct Edge {
    VT to;
    LT len;
    Edge* next;
    CEP rev;//The corresponding edge in the reversed graph.

    Edge(VT t = 0, LT l = 0, Edge* n = NULL, CEP r = NULL)
        : to(t), len(l), next(n), rev(r) {}
};

struct AState {//state of A*.
    VT commV;//The last vertex on the K shortest paths' tree.
    LT commL;//Length of subpath on the K shortest paths' tree.
    LT len;//The estimated length of the path.
    CEP dev;//Deviation edge.

    AState(VT v = 0, LT cl = 0, LT l = 0, CEP d = NULL)
        : commV(v), commL(cl), len(l), dev(d) {}

    bool operator > (const AState& s) const { return len > s.len; }
};

struct Path : public AState {
    vector<CEP> edge;

    Path(VT v = 0, LT cl = 0, LT l = 0, CEP d = NULL)
        : AState(v, cl, l, d), edge() {}

    Path concat(const Path& p, CEP conn) {
        Path r;  r.edge = edge;
        r.edge.push_back(conn);
        r.edge.insert( r.edge.end(), p.edge.begin(), p.edge.end() );
        r.len = len + conn->len + p.len;
        return r;
    }
};

class Graph {
public:
    Graph() { memset(m_adj, 0, sizeof(m_adj)); }
    ~Graph() { init(); }

    void addEdge(VT from, VT to, LT len, CEP rev = NULL)
        { m_adj[from] = new Edge(to, len, m_adj[from], rev); }

    //Get single source shortest paths with BFS.
    //Fall into INFINITE LOOP when the graph has NEGATIVE CIRCLE!!!
    void bfsShortest(VT source) {
        initSingleSrc(source);
        bool inQue[MAX_VER] = {false};
        list<VT> que(1, source);  inQue[source] = true;
        while (!que.empty()) {
            VT v = que.front();
            for (Edge* e = m_adj[v]; e; e = e->next) {
                VT to = e->to;
                if ( relax(v, e) && !inQue[to] ) {
                    que.push_back(to);  inQue[to] = true;
                }
            }
            que.pop_front();  inQue[v] = false;
        }
    }

    //Initialize a graph with "verCnt" vertices and no edge.
    void init(VT verCnt = MAX_VER) {
        m_verCnt = verCnt;
        Edge* p, *temp;
        for (VT i = 0; i < m_verCnt; i++) {
            p = m_adj[i];
            while (p) { temp = p;  p = p->next;  delete temp; }
            m_adj[i] = NULL;
        }
    }

    //Just get the LENGTHs of the k shortest paths with MPS algorithm.
    vector<LT> mpsLen(VT source, VT sink, int k, Graph& rev) {
        vector<LT> result;
        makeReverse(rev);
        rev.bfsShortest(sink);
        sortEdges(rev);
        priority_queue< AState, vector<AState>, greater<AState> > pq;
        if (rev.m_sh[source] < MAX_LEN) {
            pq.push( AState(
                source, 0, rev.m_sh[source],
                rev.m_pre[source]? rev.m_pre[source]->rev : NULL) );
        }
        while ( result.size() < k && !pq.empty() ) {
            AState s = pq.top();  pq.pop();
            result.push_back(s.len);
            VT v = s.commV;
            LT l = s.commL;
            CEP dev = s.dev;
            while (dev) {
                CEP e = dev->next;
                if (e) {
                    pq.push(
                        AState(v, l, l + e->len + rev.m_sh[e->to], e) );
                }
                v = dev->to;  l += dev->len;
                dev = rev.m_pre[v]? rev.m_pre[v]->rev: NULL;
            }
            dev = m_adj[sink];
            if (dev) {
                pq.push( AState(
                    sink, s.len,
                    s.len + dev->len + rev.m_sh[dev->to], dev) );
            }
        }
        return result;
    }

    //Get the k shortest paths with MPS algorithm.
    vector<Path> mpsPath(VT source, VT sink, int k, Graph& rev) {
        vector<Path> result;
        makeReverse(rev);
        rev.bfsShortest(sink);
        sortEdges(rev);
        priority_queue< Path, vector<Path>, greater<Path> > pq;
        if (rev.m_sh[source] < MAX_LEN) {
            Path sh = rev.revShPath(source);
            sh.dev = rev.m_pre[source]? rev.m_pre[source]->rev: NULL;
            sh.commV = source;  sh.commL = 0;
            pq.push(sh);
        }
        while ( result.size() < k && !pq.empty() ) {
            Path p = pq.top();  pq.pop();
            result.push_back(p);
            VT curV = p.commV;
            LT curL = p.commL;
            CEP dev = p.dev;
            Path lead = subpath(p, p.commL);
            while (dev) {
                CEP e = dev->next;
                if (e) {
                    Path newP = lead.concat( rev.revShPath(e->to), e );
                    newP.dev = e;  newP.commV = curV;  newP.commL = curL;
                    pq.push(newP);
                }
                curV = dev->to;  curL += dev->len;
                lead.edge.push_back(dev);  lead.len += dev->len;
                dev = rev.m_pre[curV]? rev.m_pre[curV]->rev: NULL;
            }
            dev = m_adj[sink];
            if (dev) {
                Path newP = p.concat( rev.revShPath(dev->to), dev );
                newP.dev = dev;  newP.commV = sink;  newP.commL = p.len;
                pq.push(newP);
            }
        }
        return result;
    }

    Path revShPath(VT v) const {
        Path p;  p.len = m_sh[v];
        CEP e = m_pre[v]? m_pre[v]->rev: NULL;
        while (e) {
            p.edge.push_back(e);
            v = e->to;
            e = m_pre[v]? m_pre[v]->rev: NULL;
        }
        return p;
    }

private:
    struct TempEdge {//Help the sortEdges().
        Edge* e;  LT sh;

        TempEdge(Edge* _e = NULL, LT s = 0): e(_e), sh(s) {}

        bool operator < (const TempEdge& te) const
            { return sh < te.sh || sh == te.sh && e == m_shPre; }
    };

    //Initialize the single source shortest path algorithms.
    void initSingleSrc(VT source) {
        for (VT i = 0; i < m_verCnt; i++)
            { m_sh[i] = MAX_LEN;  m_pre[i] = NULL; }
        m_sh[source] = 0;
    }

    void makeReverse(Graph& rev) {
        rev.init(m_verCnt);
        for (int v = 0; v < m_verCnt; v++) {
            for (Edge* e = m_adj[v]; e; e = e->next) {
                rev.addEdge(e->to, v, e->len, e);
            }
        }
    }

    //Help the shortest path algorithms.
    bool relax(VT from, CEP e) {
        VT to = e->to;
        if (m_sh[to] > m_sh[from] + e->len) {
            m_sh[to] = m_sh[from] + e->len;
            m_pre[to] = e;
            return true;
        }
        return false;
    }

    //Sort the edges in increasing order of their
    //leading shortest paths to the sink.
    void sortEdges(const Graph& rev) {
        vector<TempEdge> temp;
        for (int v = 0; v < m_verCnt; v++) {
            temp.clear();
            m_shPre = rev.m_pre[v]? rev.m_pre[v]->rev: NULL;
            for (Edge* e = m_adj[v]; e; e = e->next) {
                temp.push_back( TempEdge(e, e->len + rev.m_sh[e->to]) );
            }
            if ( 0 == temp.size() ) { continue; }
            sort( temp.begin(), temp.end() );
            temp[temp.size() - 1].e->next = NULL;
            for (int i = temp.size() - 2; i >= 0; i--) {
                temp[i].e->next = temp[i + 1].e;
            }
            m_adj[v] = temp[0].e;
        }
    }

    Path subpath(const Path& p, LT until) {
        Path r;
        for (int i = 0; r.len < until; i++) {
            r.edge.push_back( p.edge[i] );
            r.len += p.edge[i]->len;
        }
        return r;
    }

    VT m_verCnt;//Number of vertices.
    Edge* m_adj[MAX_VER];//Adjacent list.
    LT m_sh[MAX_VER];//Every vertex's shortest distance from the source.
    CEP m_pre[MAX_VER];//The previous edge in the shortest path.
    static CEP m_shPre;//Help the Graph::sortEdges().
};

CEP Graph::m_shPre;//Help the Graph::sortEdges().

//Test suite.
#include <iostream>

ostream& operator << (ostream& os, const Path& p) {
    for (int i = 0; i < p.edge.size() ; i++)
        { os << "-" << p.edge[i]->to + 1; }
    os << ": " << p.len;  return os;
}

int main() {
    int e [20][3] = { {2, 1, 1}, {3, 1, 2}, {4, 1, 1}, {5, 1, 3},
                      {1, 2, 1}, {3, 2, 1}, {4, 2, 2}, {5, 2, 2},
                      {1, 3, 1}, {2, 3, 2}, {4, 3, 1}, {5, 3, 1},
                      {1, 4, 1}, {2, 4, 1}, {3, 4, 1}, {5, 4, 2},
                      {1, 5, 1}, {2, 5, 1}, {3, 5, 1}, {4, 5, 1} };
    Graph g, rev;  g.init(5);
    for (int i = 0; i < 20; i++)
        { g.addEdge( e[i][0] - 1, e[i][1] - 1, e[i][2]); }
    //Test 1: K shortest paths.
    vector<Path> v = g.mpsPath(4, 0, 16, rev);
    for (int i = 0; i < v.size(); i++) { cout << 5 << v[i] << endl; }
    //Test 2: only lengths K shortest path.
    vector<LT> l = g.mpsLen(4 , 0, 16, rev);
    for (int i = 0; i < l.size(); i++) { cout << l[i] << " "; }
    cout << endl;
    //Output of Test 1:
    //5-1: 3
    //5-4-1: 3
    //5-3-1: 3
    //5-2-1: 3
    //5-3-4-1: 3
    //5-3-2-1: 3
    //5-2-4-1: 4
    //5-3-2-4-1: 4
    //5-4-1-4-1: 5
    //5-3-4-1-4-1: 5
    //5-2-1-4-1: 5
    //5-4-1-2-1: 5
    //5-4-3-1: 5
    //5-3-1-4-1: 5
    //5-4-3-4-1: 5
    //5-3-1-2-1: 5
    //Output of Test 2: 3 3 3 3 3 3 4 4 5 5 5 5 5 5 5 5
    return 0;
}
