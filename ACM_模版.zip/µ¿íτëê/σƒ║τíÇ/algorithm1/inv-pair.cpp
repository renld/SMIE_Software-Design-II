//Count the inversion pairs during a Merge Sort,
//storing the sorted array in the memory 'sorted'.
//n < 1 is not accepted.
//NOTICE sometimes the return type INT is not enough, need LONG LONG
int invPair(const int* a, int n, int* sorted) {
    if (1 == n) { sorted[0] = a[0];  return 0; }
    int lN = n / 2, rN = n - lN,
        *lA = new int[lN], *rA = new int[rN],
        i = 0, l = 0, r = 0;
    int cnt = invPair(a, lN, lA) + invPair(a + lN, rN, rA);
    while (l < lN && r < rN)
        if ( lA[l] <= rA[r] )  sorted[i++] = lA[l++];
        else { sorted[i++] = rA[r++];  cnt += lN - l; }
    while (l < lN)  sorted[i++] = lA[l++];
    while (r < rN)  sorted[i++] = rA[r++];
    delete[] lA;  delete[] rA;
    return cnt;
}

//Test suite and usage example.
#include <iostream>
using namespace std;

int main() {
    //int a[] = {5, 2, 4, 9, 1, 3, 2, 6, 7}, b[9];
    int a[] = {1, 2, 4, 3, 5}, b[9];
    int c = invPair(a, 9, b);
    cout << c << endl;//Output: 15
    return 0;
}
